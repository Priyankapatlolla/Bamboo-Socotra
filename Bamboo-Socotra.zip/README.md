# bamboo_employees_app
Bamboo Socotra Configuration Staging