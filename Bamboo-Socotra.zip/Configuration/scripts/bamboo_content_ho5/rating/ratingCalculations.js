let lib = require("../libraries/lib.js");
let dwellingCoverages1 = require("./exposures/dwelling/dwellingCoverages1.js");
let dwellingCoverages2 = require("./exposures/dwelling/dwellingCoverages2.js");
let constantValues = require("./ratingConstants.js");
let flatPremiumComputations1 = require("./exposures/dwelling/flatPremiumComputations1.js")
let flatPremiumComputations2 = require("./exposures/dwelling/flatPremiumComputations2.js")
let plcPremiumComputations1 = require("./exposures/policylevelcoverages/plcPremiumComputations1.js")
let plcPremiumComputations2 = require("./exposures/policylevelcoverages/plcPremiumComputations2.js")
let adjustedBasePremium = require("../rating/exposures/dwelling/adjustedBasePremium.js");
let factorsForPremium = require("../rating/exposures/dwelling/coverageSupportingFactors.js");
let dates = require("../../bamboo_content_ho5/libraries/dates.js");
let factors;
let adjustedBasePremiums;
let FactorForPremium = {
    water_credits_on_abp: constantValues.numberConstants.zero,
    fire_credits_on_abp: constantValues.numberConstants.zero,
    theft_credits_on_abp: constantValues.numberConstants.zero,
    wind_secondary_home_charge: constantValues.numberConstants.zero,
    water_secondary_home_charge: constantValues.numberConstants.zero,
    fire_secondary_home_charge: constantValues.numberConstants.zero,
    theft_secondary_home_charge: constantValues.numberConstants.zero,
    liability_secondary_home_charge: constantValues.numberConstants.zero,
    other_secondary_home_charge: constantValues.numberConstants.zero,
    wind_age_of_home_remoulded_premium: constantValues.numberConstants.zero,
    fire_age_of_home_remoulded_premium: constantValues.numberConstants.zero,
    theft_age_of_home_remoulded_premium: constantValues.numberConstants.zero,
    liability_age_of_home_remoulded_premium: constantValues.numberConstants.zero,
    other_age_of_home_remoulded_premium: constantValues.numberConstants.zero,
    water_age_of_home_remoulded_premium: constantValues.numberConstants.zero,
    wind_replace_cost_nonbldg_struct_premium: constantValues.numberConstants.zero,
    water_replace_cost_nonbldg_struct_premium: constantValues.numberConstants.zero,
    fire_replace_cost_nonbldg_struct_premium: constantValues.numberConstants.zero,
    theft_replace_cost_nonbldg_struct_premium: constantValues.numberConstants.zero,
    other_replace_cost_nonbldg_struct_premium: constantValues.numberConstants.zero,
    wind_personal_prop_rcv_premium: constantValues.numberConstants.zero,
    water_personal_prop_rcv_premium: constantValues.numberConstants.zero,
    fire_personal_prop_rcv_premium: constantValues.numberConstants.zero,
    theft_personal_prop_rcv_premium: constantValues.numberConstants.zero,
    other_personal_prop_rcv_premium: constantValues.numberConstants.zero,
    wind_sub_total: constantValues.numberConstants.zero,
    water_sub_total: constantValues.numberConstants.zero,
    fire_sub_total: constantValues.numberConstants.zero,
    theft_sub_total: constantValues.numberConstants.zero,
    liability_sub_total: constantValues.numberConstants.zero,
    other_sub_total: constantValues.numberConstants.zero,
    misc_sub_total: constantValues.numberConstants.zero,
    total_annual_basic_premium: constantValues.numberConstants.zero
}
let Premiums = {
    animal_liability_premium: constantValues.numberConstants.zero,
    residence_held_in_trust_premium: constantValues.numberConstants.zero,
    student_away_from_home_premium: constantValues.numberConstants.zero,
    other_locations_occupied_by_insured_premium: constantValues.numberConstants.zero,
    liability_home_day_care_premium: constantValues.numberConstants.zero,
    personal_injury_premium: constantValues.numberConstants.zero,
    service_line_coverage_premium: constantValues.numberConstants.zero,
    equipment_breakdown_coverage_premium: constantValues.numberConstants.zero,
    business_property_premium: constantValues.numberConstants.zero,
    loss_assessment_premium: constantValues.numberConstants.zero,
    specific_other_structure_premium: constantValues.numberConstants.zero,
    unscheduled_fridge_property_premium: constantValues.numberConstants.zero,
    limited_special_computer_equipment_premium: constantValues.numberConstants.zero,
    landlord_furnishings_premium: constantValues.numberConstants.zero,
    assisted_living_care_premium: constantValues.numberConstants.zero,
    scheduled_golf_cart_premium: constantValues.numberConstants.zero,
    green_upgrades_premium: constantValues.numberConstants.zero,
    misc_home_day_care_premium: constantValues.numberConstants.zero,
    gold_package_credit: constantValues.numberConstants.zero,
    platinum_package_credit: constantValues.numberConstants.zero,
    device_protection_premium: constantValues.numberConstants.zero,
    family_cyber_protection_premium: constantValues.numberConstants.zero,
    age_of_home_remoulded_premium: constantValues.numberConstants.zero,
    wind_hail_roof_loss_premium: constantValues.numberConstants.zero,
    actual_cash_value_roof_premium: constantValues.numberConstants.zero,
    increase_decrease_coverage_C_premium: constantValues.numberConstants.zero,
    increase_decrease_coverage_D_premium: constantValues.numberConstants.zero,
    increase_decrease_coverage_B_Premium: constantValues.numberConstants.zero,
    limited_fungi_microbes_coverage_premium: constantValues.numberConstants.zero,
    townhouse_row_house_premium: constantValues.numberConstants.zero,
    water_backup_sump_discharge_premium: constantValues.numberConstants.zero,
    inc_limits_of_liability_premium: constantValues.numberConstants.zero,
    personal_property_scheduled_premium: constantValues.numberConstants.zero
};
let total_adjusted_based_premium;

function getPerilRates(data) {
    if (!data.tenantTimeZone)
        throw "Missing tenantTimeZone";
    const tenantTimeZone = data.tenantTimeZone;
    let policyLocator = data.policy.locator;
    let transactionLocator;
    let transactionType = data.operation;
    if(transactionType == "endorsement")
    {
        transactionLocator = data.endorsementLocator;
    }
    else if(transactionType == "renewal")
    {
        transactionLocator = data.renewalLocator;
    }
    console.log("🚀 ~ file: ratingCalculations.js ~ line 91 ~ getPerilRates ~ transactionType", transactionType)
    lib.polyfill();
    let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
    let policy_start_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;
    let pricedPerilCharacteristics = {};
    let exposures = data.policy.exposures;
    let perils = exposures.flatMap((e) => e.perils);
    let policyExposurePerils = data.policyExposurePerils;
    setAdjustedPremium(data);
    for (let policy_exposure_peril of policyExposurePerils) {
        let pcl = policy_exposure_peril.perilCharacteristicsLocator;
        let peril = perils.find((p) =>
            p.characteristics.some((ch) =>
                ch.locator == policy_exposure_peril.perilCharacteristicsLocator));

        if (peril.name == constantValues.perilNameConstants.ordinance_law_coverage) {
            let ordinance_law_coverage_premium = constantValues.numberConstants.zero;
            ordinance_law_coverage_premium = getPremiumAdjustedForDayAccrual(ordinance_law_coverage_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(ordinance_law_coverage_premium) ? ordinance_law_coverage_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.credits_on_abp) {
            let creditsOnABP = plcPremiumComputations1.getPremiumForCreditsOnABP(peril, exposures, adjustedBasePremiums, policyLocator, transactionType, transactionLocator);
            let credits_on_abp_premium = creditsOnABP.credits_on_abp_premium;
            credits_on_abp_premium = getPremiumAdjustedForDayAccrual(credits_on_abp_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            FactorForPremium.water_credits_on_abp = creditsOnABP.water_credits_on_abp;
            FactorForPremium.fire_credits_on_abp = creditsOnABP.fire_credits_on_abp;
            FactorForPremium.theft_credits_on_abp = creditsOnABP.theft_credits_on_abp;

            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(credits_on_abp_premium) ? credits_on_abp_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.age_of_home_rem) {
            let ageOfHomeRemoulded = dwellingCoverages1.getPremiumForAgeOfHomeRemoulded(peril, exposures, adjustedBasePremiums, policy_start_timestamp);
            let age_of_home_remoulded_premium = ageOfHomeRemoulded.total_age_of_home_remoulded_premium;
            age_of_home_remoulded_premium = getPremiumAdjustedForDayAccrual(age_of_home_remoulded_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
            FactorForPremium.wind_age_of_home_remoulded_premium = ageOfHomeRemoulded.wind_age_of_home_remoulded_premium;
            FactorForPremium.water_age_of_home_remoulded_premium = ageOfHomeRemoulded.water_age_of_home_remoulded_premium;
            FactorForPremium.fire_age_of_home_remoulded_premium = ageOfHomeRemoulded.fire_age_of_home_remoulded_premium;
            FactorForPremium.theft_age_of_home_remoulded_premium = ageOfHomeRemoulded.theft_age_of_home_remoulded_premium;
            FactorForPremium.liability_age_of_home_remoulded_premium = ageOfHomeRemoulded.liability_age_of_home_remoulded_premium;
            FactorForPremium.other_age_of_home_remoulded_premium = ageOfHomeRemoulded.other_age_of_home_remoulded_premium;

            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(age_of_home_remoulded_premium) ? age_of_home_remoulded_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.acv_wind_hail_roof_loss) {
            let wind_hail_roof_loss_premium = dwellingCoverages1.getPremiumForACVWindHailRoofLoss(peril, exposures, adjustedBasePremiums);
            wind_hail_roof_loss_premium = getPremiumAdjustedForDayAccrual(wind_hail_roof_loss_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.wind_hail_roof_loss_premium = wind_hail_roof_loss_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(wind_hail_roof_loss_premium) ? wind_hail_roof_loss_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.secondary_home_charge) {
            let secondaryHomeCharge = dwellingCoverages1.getPremiumForSecondaryHomeCharge(peril, exposures, adjustedBasePremiums);
            let secondary_home_charge_premium = secondaryHomeCharge.total_secondary_home_charge_premium;
            secondary_home_charge_premium = getPremiumAdjustedForDayAccrual(secondary_home_charge_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            FactorForPremium.water_secondary_home_charge = secondaryHomeCharge.water_secondary_home_charge;
            FactorForPremium.wind_secondary_home_charge = secondaryHomeCharge.wind_secondary_home_charge;
            FactorForPremium.fire_secondary_home_charge = secondaryHomeCharge.fire_secondary_home_charge;
            FactorForPremium.theft_secondary_home_charge = secondaryHomeCharge.theft_secondary_home_charge;
            FactorForPremium.liability_secondary_home_charge = secondaryHomeCharge.liability_secondary_home_charge;
            FactorForPremium.other_secondary_home_charge = secondaryHomeCharge.other_secondary_home_charge;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(secondary_home_charge_premium) ? secondary_home_charge_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.personal_propety_replacement_cost) {
            let PersonalPropertyRCV = dwellingCoverages1.getPremiumForPersonalPropertyRCV(perils, peril, exposures, policyExposurePerils, adjustedBasePremiums);
            let personal_propety_replacement_cost_premium = PersonalPropertyRCV.personal_prop_replacement_cost_premium;
            personal_propety_replacement_cost_premium = getPremiumAdjustedForDayAccrual(personal_propety_replacement_cost_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            FactorForPremium.wind_personal_prop_rcv_premium = PersonalPropertyRCV.wind_personal_prop_rcv_premium;
            FactorForPremium.water_personal_prop_rcv_premium = PersonalPropertyRCV.water_personal_prop_rcv_premium;
            FactorForPremium.fire_personal_prop_rcv_premium = PersonalPropertyRCV.fire_personal_prop_rcv_premium;
            FactorForPremium.theft_personal_prop_rcv_premium = PersonalPropertyRCV.theft_personal_prop_rcv_premium;
            FactorForPremium.other_personal_prop_rcv_premium = PersonalPropertyRCV.other_personal_prop_rcv_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(personal_propety_replacement_cost_premium) ? personal_propety_replacement_cost_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.rcv_ls_certain_non_building) {
            let certainNonBuilding = dwellingCoverages2.getPremiumForCertainNonBuilding(peril, exposures, adjustedBasePremiums);
            let certain_non_building_premium = certainNonBuilding.replace_cost_nonbldg_struct_premium;
            certain_non_building_premium = getPremiumAdjustedForDayAccrual(certain_non_building_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            FactorForPremium.wind_replace_cost_nonbldg_struct_premium = certainNonBuilding.wind_replace_cost_nonbldg_struct_premium;
            FactorForPremium.water_replace_cost_nonbldg_struct_premium = certainNonBuilding.water_replace_cost_nonbldg_struct_premium;
            FactorForPremium.fire_replace_cost_nonbldg_struct_premium = certainNonBuilding.fire_replace_cost_nonbldg_struct_premium;
            FactorForPremium.theft_replace_cost_nonbldg_struct_premium = certainNonBuilding.theft_replace_cost_nonbldg_struct_premium;
            FactorForPremium.other_replace_cost_nonbldg_struct_premium = certainNonBuilding.other_replace_cost_nonbldg_struct_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(certain_non_building_premium) ? certain_non_building_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.gold_package_credit) {
            let gold_package_credit_premium = plcPremiumComputations1.getPremiumForGoldPackageCredit(perils, peril, exposures, policyExposurePerils, adjustedBasePremiums);
            gold_package_credit_premium = getPremiumAdjustedForDayAccrual(gold_package_credit_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.gold_package_credit = gold_package_credit_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(gold_package_credit_premium) ? gold_package_credit_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.Platinum_package_credit) {
            let platinum_package_credit = plcPremiumComputations1.getPremiumForPlatinumPackageCredit(perils, peril, exposures, policyExposurePerils, adjustedBasePremiums);
            platinum_package_credit = getPremiumAdjustedForDayAccrual(platinum_package_credit, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.platinum_package_credit = platinum_package_credit;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(platinum_package_credit) ? platinum_package_credit : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.other_structures_increased_limit) {
            let other_structures_increased_limit_premium = dwellingCoverages2.getPremiumForOtherStructuresIncreasedLimit(perils, peril, exposures, policyExposurePerils, factors);
            other_structures_increased_limit_premium = getPremiumAdjustedForDayAccrual(other_structures_increased_limit_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.increase_decrease_coverage_B_Premium = other_structures_increased_limit_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(other_structures_increased_limit_premium) ? other_structures_increased_limit_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.increase_decrease_coverage_C) {
            let inc_dec_cov_c_premium = dwellingCoverages2.getPremiumForIncreaseDecreaseCovC(perils, peril, exposures, policyExposurePerils, factors);
            inc_dec_cov_c_premium = getPremiumAdjustedForDayAccrual(inc_dec_cov_c_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.increase_decrease_coverage_C_premium = inc_dec_cov_c_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(inc_dec_cov_c_premium) ? inc_dec_cov_c_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.increase_decrease_coverage_D) {
            let inc_dec_cov_d_premium = flatPremiumComputations2.getPremiumForIncreaseCovD(perils, peril, exposures, policyExposurePerils, factors);
            inc_dec_cov_d_premium = getPremiumAdjustedForDayAccrual(inc_dec_cov_d_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.increase_decrease_coverage_D_premium = inc_dec_cov_d_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(inc_dec_cov_d_premium) ? inc_dec_cov_d_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.device_protection) {
            let device_protection_premium = flatPremiumComputations1.getPremiumForDeviceProtection()
            device_protection_premium = getPremiumAdjustedForDayAccrual(device_protection_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.device_protection_premium = device_protection_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(device_protection_premium) ? device_protection_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.personal_injury_coverage) {
            let personal_injury_coverage_premium = flatPremiumComputations1.getPremiumPersonalInjuryCoverage(peril, exposures)
            personal_injury_coverage_premium = getPremiumAdjustedForDayAccrual(personal_injury_coverage_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.personal_injury_premium = personal_injury_coverage_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(personal_injury_coverage_premium) ? personal_injury_coverage_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.other_locations_occupied_by_insured) {
            let other_locations_occupied_by_insured_premium = flatPremiumComputations1.getPremiumForOtherLocationsOccupiedbyInsured(exposures, peril)
            other_locations_occupied_by_insured_premium = getPremiumAdjustedForDayAccrual(other_locations_occupied_by_insured_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.other_locations_occupied_by_insured_premium = other_locations_occupied_by_insured_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(other_locations_occupied_by_insured_premium) ? other_locations_occupied_by_insured_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.student_away_from_home) {
            let student_away_from_home_premium = flatPremiumComputations1.getPremiumForStudentAwayFromHome(perils, peril, exposures, policyExposurePerils)
            student_away_from_home_premium = getPremiumAdjustedForDayAccrual(student_away_from_home_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.student_away_from_home_premium = student_away_from_home_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(student_away_from_home_premium) ? student_away_from_home_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.residence_held_in_trust) {
            let residence_held_in_trust_premium = flatPremiumComputations1.getPremiumForResidenceHeldinTrust(perils, peril, exposures, policyExposurePerils);
            residence_held_in_trust_premium = getPremiumAdjustedForDayAccrual(residence_held_in_trust_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.residence_held_in_trust_premium = residence_held_in_trust_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(residence_held_in_trust_premium) ? residence_held_in_trust_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.golf_cart_physical_loss) {
            let golf_cart_physical_loss_premium = flatPremiumComputations1.getPremiumForGolfCartPhysicalLossCoverage(peril, exposures);
            golf_cart_physical_loss_premium = getPremiumAdjustedForDayAccrual(golf_cart_physical_loss_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.scheduled_golf_cart_premium = golf_cart_physical_loss_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(golf_cart_physical_loss_premium) ? golf_cart_physical_loss_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.assisted_living_care_coverage) {
            let assisted_living_care_coverage_premium = flatPremiumComputations1.getPremiumForAssistedLivingCareCoverage(peril, exposures)
            assisted_living_care_coverage_premium = getPremiumAdjustedForDayAccrual(assisted_living_care_coverage_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.assisted_living_care_premium = assisted_living_care_coverage_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(assisted_living_care_coverage_premium) ? assisted_living_care_coverage_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.landlord_furnishings) {
            let landlord_furnishings_premium = flatPremiumComputations1.getPremiumForLandlordsFurnishingsIncreasedLimits(peril, exposures)
            landlord_furnishings_premium = getPremiumAdjustedForDayAccrual(landlord_furnishings_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.landlord_furnishings_premium = landlord_furnishings_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(landlord_furnishings_premium) ? landlord_furnishings_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.water_backup_sump_discharge) {
            let water_backup_sump_discharge_premium = flatPremiumComputations1.getPremiumForWaterBackupAndSumpOverflow(perils, peril, exposures, policyExposurePerils)
            water_backup_sump_discharge_premium = getPremiumAdjustedForDayAccrual(water_backup_sump_discharge_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.water_backup_sump_discharge_premium = water_backup_sump_discharge_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(water_backup_sump_discharge_premium) ? water_backup_sump_discharge_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.limited_special_computer_equipment_coverage) {
            let limited_special_computer_equipment_coverage_premium = flatPremiumComputations1.getPremiumForLimitedSpecialComputerEquipmentCoverage(peril, exposures)
            limited_special_computer_equipment_coverage_premium = getPremiumAdjustedForDayAccrual(limited_special_computer_equipment_coverage_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.limited_special_computer_equipment_premium = limited_special_computer_equipment_coverage_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(limited_special_computer_equipment_coverage_premium) ? limited_special_computer_equipment_coverage_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.refrigerated_Personal_property) {
            let refrigerated_Personal_property_premium = flatPremiumComputations2.getPremiumForRefridgeratedPersonalProperty(peril, exposures)
            refrigerated_Personal_property_premium = getPremiumAdjustedForDayAccrual(refrigerated_Personal_property_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.unscheduled_fridge_property_premium = refrigerated_Personal_property_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(refrigerated_Personal_property_premium) ? refrigerated_Personal_property_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.specific_other_structures_coverage) {
            let specific_other_structures_coverage_premium = flatPremiumComputations2.getPremiumForSpecificOtherStructureCover(peril, exposures);
            specific_other_structures_coverage_premium = getPremiumAdjustedForDayAccrual(specific_other_structures_coverage_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.specific_other_structure_premium = specific_other_structures_coverage_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(specific_other_structures_coverage_premium) ? specific_other_structures_coverage_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.business_property_increased_limits) {
            let business_property_increased_limits_premium = flatPremiumComputations2.getPremiumForBusinessPropertyIncLimits(peril, exposures);
            business_property_increased_limits_premium = getPremiumAdjustedForDayAccrual(business_property_increased_limits_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.business_property_premium = business_property_increased_limits_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(business_property_increased_limits_premium) ? business_property_increased_limits_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.limited_animal_liability_coverage) {
            let limited_animal_liability_coverage_premium = flatPremiumComputations2.getPremiumForLimitedLiabilityCoverage(perils, peril, exposures, policyExposurePerils)
            limited_animal_liability_coverage_premium = getPremiumAdjustedForDayAccrual(limited_animal_liability_coverage_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)

            Premiums.animal_liability_premium = limited_animal_liability_coverage_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(limited_animal_liability_coverage_premium) ? limited_animal_liability_coverage_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.equipment_breakdown_coverage) {
            let equipment_breakdown_coverage_premium = flatPremiumComputations2.getPremiumForEquipmentBreakdowncoverage(peril, exposures)
            equipment_breakdown_coverage_premium = getPremiumAdjustedForDayAccrual(equipment_breakdown_coverage_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.equipment_breakdown_coverage_premium = equipment_breakdown_coverage_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(equipment_breakdown_coverage_premium) ? equipment_breakdown_coverage_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.service_line_coverage) {
            let service_line_coverage_premium = flatPremiumComputations2.getPremiumForServiceLineCoverage(peril, exposures)
            service_line_coverage_premium = getPremiumAdjustedForDayAccrual(service_line_coverage_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.service_line_coverage_premium = service_line_coverage_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(service_line_coverage_premium) ? service_line_coverage_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.actual_cash_value_roof) {
            let actual_cash_value_roof_premium = dwellingCoverages2.getPremiumForACVRoof(peril, exposures, adjustedBasePremiums)
            actual_cash_value_roof_premium = getPremiumAdjustedForDayAccrual(actual_cash_value_roof_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.actual_cash_value_roof_premium = actual_cash_value_roof_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(actual_cash_value_roof_premium) ? actual_cash_value_roof_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.townhouse_row_house) {
            let townhouse_row_house_premium = dwellingCoverages2.getPremiumForTownhouseOrRowHouse(peril, exposures, adjustedBasePremiums)
            townhouse_row_house_premium = getPremiumAdjustedForDayAccrual(townhouse_row_house_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.townhouse_row_house_premium = townhouse_row_house_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(townhouse_row_house_premium) ? townhouse_row_house_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.limited_fungi_microbes_coverage) {
            let limited_fungi_microbes_coverage_premium = flatPremiumComputations2.getPremiumForLimitedfungi(peril, exposures)
            limited_fungi_microbes_coverage_premium = getPremiumAdjustedForDayAccrual(limited_fungi_microbes_coverage_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.limited_fungi_microbes_coverage_premium = limited_fungi_microbes_coverage_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(limited_fungi_microbes_coverage_premium) ? limited_fungi_microbes_coverage_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.family_cyber_protection) {
            let family_cyber_protection_premium = flatPremiumComputations1.getPremiumForFamilyCyberProtection()
            family_cyber_protection_premium = getPremiumAdjustedForDayAccrual(family_cyber_protection_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.family_cyber_protection_premium = family_cyber_protection_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(family_cyber_protection_premium) ? family_cyber_protection_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.personal_property_scheduled) {
            let personal_property_scheduled_premium = plcPremiumComputations1.getPremiumForSchedulePersonalProperty(peril, exposures, policyLocator, transactionType, transactionLocator)
            personal_property_scheduled_premium = getPremiumAdjustedForDayAccrual(personal_property_scheduled_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.personal_property_scheduled_premium = personal_property_scheduled_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(personal_property_scheduled_premium) ? personal_property_scheduled_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.home_day_care_coverage) {

            let homeDayCareCoverage = flatPremiumComputations1.getPremiumForHomeDayCareCoverage(perils, peril, exposures, policyExposurePerils)
            let liability_home_day_care_premium = homeDayCareCoverage.liability_home_day_care_premium;
            let misc_home_day_care_premium = homeDayCareCoverage.misc_home_day_care_premium;
            let home_day_care_coverage_premium = homeDayCareCoverage.home_day_care_premium;
            home_day_care_coverage_premium = getPremiumAdjustedForDayAccrual(home_day_care_coverage_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.home_day_care_coverage = home_day_care_coverage_premium;
            Premiums.liability_home_day_care_premium = liability_home_day_care_premium;
            Premiums.misc_home_day_care_premium =  misc_home_day_care_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(home_day_care_coverage_premium) ? home_day_care_coverage_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.supplement_loss_assessment_cov) {
            let supplement_loss_assessment_cov_premium = flatPremiumComputations2.getPremiumForSupplementLossAssessmentCoverage(peril, exposures)
            supplement_loss_assessment_cov_premium = getPremiumAdjustedForDayAccrual(supplement_loss_assessment_cov_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.loss_assessment_premium = supplement_loss_assessment_cov_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(supplement_loss_assessment_cov_premium) ? supplement_loss_assessment_cov_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.increased_special_limits) {
            let inc_limits_of_liability_premium = flatPremiumComputations2.getPremiumForIncreaseSpecialLimits(peril, exposures)
            inc_limits_of_liability_premium = getPremiumAdjustedForDayAccrual(inc_limits_of_liability_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.inc_limits_of_liability_premium = inc_limits_of_liability_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(inc_limits_of_liability_premium) ? inc_limits_of_liability_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.coverage_a) {
            let coverage_a_premium = constantValues.numberConstants.zero;
            coverage_a_premium = getPremiumAdjustedForDayAccrual(coverage_a_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(coverage_a_premium) ? coverage_a_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.coverage_b) {
            let coverage_b_premium = constantValues.numberConstants.zero;
            coverage_b_premium = getPremiumAdjustedForDayAccrual(coverage_b_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(coverage_b_premium) ? coverage_b_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.coverage_c) {
            let coverage_c_premium = constantValues.numberConstants.zero;
            coverage_c_premium = getPremiumAdjustedForDayAccrual(coverage_c_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(coverage_c_premium) ? coverage_c_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.coverage_d) {
            let coverage_d_premium = constantValues.numberConstants.zero;
            coverage_d_premium = getPremiumAdjustedForDayAccrual(coverage_d_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(coverage_d_premium) ? coverage_d_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.coverage_e) {
            let coverage_e_premium = constantValues.numberConstants.zero;
            coverage_e_premium = getPremiumAdjustedForDayAccrual(coverage_e_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(coverage_e_premium) ? coverage_e_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.coverage_f) {
            let coverage_f_premium = constantValues.numberConstants.zero;
            coverage_f_premium = getPremiumAdjustedForDayAccrual(coverage_f_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(coverage_f_premium) ? coverage_f_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.deductibles) {
            let deductibles_premium = constantValues.numberConstants.zero;
            deductibles_premium = getPremiumAdjustedForDayAccrual(deductibles_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(deductibles_premium) ? deductibles_premium : 0,
                technicalPremium: 0
            };
        }
        else if (peril.name == constantValues.perilNameConstants.adjusted_base_premium) {
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(total_adjusted_based_premium) ? total_adjusted_based_premium : 0,
                technicalPremium: 0
            };
        }
        else {
            pricedPerilCharacteristics[pcl] = {
                premium: 0,
                technicalPremium: 0
            };
        }
    }

    for (let policy_exposure_peril of policyExposurePerils) {
        let pcl = policy_exposure_peril.perilCharacteristicsLocator;
        let peril = perils.find((p) =>
            p.characteristics.some((ch) =>
                ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
        if (peril.name == constantValues.perilNameConstants.discounts_and_min_prem) {
            let discountsAndMinPrem = plcPremiumComputations2.getPremiumForDiscountsAndMinPremium(peril, exposures, policy_fv, Premiums, FactorForPremium, adjustedBasePremiums,policyLocator,transactionType,transactionLocator);
            let discounts_and_min_prem = discountsAndMinPrem.total_min_prem_adjustment;
            console.log("🚀 ~ file: ratingCalculations.js ~ line 532 ~ getPerilRates ~ discounts_and_min_prem", discounts_and_min_prem)
            FactorForPremium.wind_sub_total = discountsAndMinPrem.wind_sub_total;
            FactorForPremium.water_sub_total = discountsAndMinPrem.water_sub_total;
            FactorForPremium.fire_sub_total = discountsAndMinPrem.fire_sub_total;
            FactorForPremium.theft_sub_total = discountsAndMinPrem.theft_sub_total;
            FactorForPremium.liability_sub_total = discountsAndMinPrem.liability_sub_total;
            FactorForPremium.other_sub_total = discountsAndMinPrem.other_sub_total;
            FactorForPremium.misc_sub_total = discountsAndMinPrem.misc_sub_total;
            FactorForPremium.total_annual_basic_premium = discountsAndMinPrem.total_annual_basic_premium
            discounts_and_min_prem = getPremiumAdjustedForDayAccrual(discounts_and_min_prem, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(discounts_and_min_prem) ? discounts_and_min_prem : 0,
                technicalPremium: 0
            };
        }
    }

    for (let policy_exposure_peril of policyExposurePerils) {
        let pcl = policy_exposure_peril.perilCharacteristicsLocator;
        let peril = perils.find((p) =>
            p.characteristics.some((ch) =>
                ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
        if (peril.name == constantValues.perilNameConstants.green_home_additional_coverage) {
            let green_home_additional_coverage_premium = flatPremiumComputations1.getPremiumForGreenHomeAdditionalCoverage(FactorForPremium.total_annual_basic_premium);
            green_home_additional_coverage_premium = getPremiumAdjustedForDayAccrual(green_home_additional_coverage_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
            Premiums.green_upgrades_premium = green_home_additional_coverage_premium;
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(green_home_additional_coverage_premium) ? green_home_additional_coverage_premium : 0,
                technicalPremium: 0
            };
        }
    }

    for (let policy_exposure_peril of policyExposurePerils) {
        let pcl = policy_exposure_peril.perilCharacteristicsLocator;
        let peril = perils.find((p) =>
            p.characteristics.some((ch) =>
                ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
        if (peril.name == constantValues.perilNameConstants.policy_transition_credit) {
            let policy_transition_credit_premium = plcPremiumComputations2.getPremiumForPolicyTransitionCredit(policy_fv, peril, exposures, Premiums, FactorForPremium);
            policy_transition_credit_premium = getPremiumAdjustedForDayAccrual(policy_transition_credit_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
            pricedPerilCharacteristics[pcl] = {
                yearlyPremium: !isNaN(policy_transition_credit_premium) ? policy_transition_credit_premium : 0,
                technicalPremium: 0
            };
        }
    }
    return {
        pricedPerilCharacteristics
    };
}


function setAdjustedPremium(data) {
    if (!data.tenantTimeZone)
        throw "Missing tenantTimeZone";
    const tenantTimeZone = data.tenantTimeZone;
    lib.polyfill();  ///remove
    let policyLocator = data.policy.locator;
    let exposures = data.policy.exposures;
    let perils = exposures.flatMap((e) => e.perils);
    let policyExposurePerils = data.policyExposurePerils;
    for (let policy_exposure_peril of policyExposurePerils) {
        let pcl = policy_exposure_peril.perilCharacteristicsLocator;
        let peril = perils.find((p) =>
            p.characteristics.some((ch) =>
                ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
        if (peril.name == constantValues.perilNameConstants.adjusted_base_premium) {
            factors = factorsForPremium.getFactorsForPremium(data);
            adjustedBasePremiums = adjustedBasePremium.getAdjustedBasePremium(data, factors,policyLocator);
            total_adjusted_based_premium = adjustedBasePremiums.total_adjusted_based_premium;
            total_adjusted_based_premium = getPremiumAdjustedForDayAccrual(total_adjusted_based_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp)
        }
    }
}

function getPremiumAdjustedForDayAccrual(unadjustedPremium, peril, pcl, tenantTimeZone, policyStartTimestamp) {
    let pricedPerilCharacteristic;
    for (let char of peril.characteristics) {
        if (char.locator == pcl) {
            pricedPerilCharacteristic = char;
        }
    }
    let coverageStartTimestamp = parseInt(pricedPerilCharacteristic.coverageStartTimestamp);
    let coverageEndTimestamp = parseInt(pricedPerilCharacteristic.coverageEndTimestamp);
    policyStartTimestamp = parseInt(policyStartTimestamp);
    let unadjustedRate = unadjustedPremium;
    let daysRated = dates.dayCountByTimestamp(coverageStartTimestamp,
        coverageEndTimestamp,
        tenantTimeZone);
    let targetPremium = (unadjustedRate * daysRated / 365);
    let monthsForChar = dates.monthCountByTimestamp(coverageStartTimestamp,
        coverageEndTimestamp,
        tenantTimeZone,
        policyStartTimestamp);
    let returnPremium = targetPremium * 12 / monthsForChar;
    return unadjustedPremium;
}
exports.getPerilRates = getPerilRates;