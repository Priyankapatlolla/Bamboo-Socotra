let ratingConstants = require('../../ratingConstants.js')
let Helpers = require('../../helpersRating.js')
Helpers.roundToDecimalPlaces();

function getPremiumForDeviceProtection() {
   return 0;
}

function getPremiumForFamilyCyberProtection() {
   return 0;
}

function getPremiumForLandlordsFurnishingsIncreasedLimits(peril, exposures) {
   let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
   let peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;
   let landlord_furnishings_groups = peril_fv.landlords_furnishing_details;
   let landlord_furnishings_increased_limit = ratingConstants.numberConstants.zero;
   let exposure_fv = Helpers.getExposureFieldValues(peril,exposures);
   let state = exposure_fv.property_state;
   let tableName = ratingConstants.tableNameConsts.landlord_furnishings_rate_table;
   tableName = Helpers.getTableName(state, tableName);
   for(let landlord_furnishings_group of  landlord_furnishings_groups)
   {
      let landlord_furnishings_increased_limits = peril_fgv[landlord_furnishings_group].landlords_furnishings_increased_limits;
      landlord_furnishings_increased_limit += parseFloat(Helpers.removeSpecialCharacters(landlord_furnishings_increased_limits));
   }
   let landlord_furnishings_rate = parseFloat(socotraApi.tableLookup(tableName, ratingConstants.tableKeyConstants.rate));
   let landlord_furnishings_premium = (((landlord_furnishings_increased_limit - ratingConstants.numberConstants.twenty_five_hundred) / ratingConstants.numberConstants.five_hundred) * landlord_furnishings_rate);
   landlord_furnishings_premium = landlord_furnishings_premium.round(ratingConstants.numberConstants.two)
   return landlord_furnishings_premium;
}


function getPremiumPersonalInjuryCoverage(peril,exposures) {
   let exposure_fv = Helpers.getExposureFieldValues(peril,exposures);
   let state = exposure_fv.property_state;
   let tableName = ratingConstants.tableNameConsts.personal_injury_rate_table;
   tableName = Helpers.getTableName(state, tableName);
   let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
   let personal_injury_limit = peril_fv.personal_injury_limit;
   personal_injury_limit = Helpers.removeSpecialCharacters(personal_injury_limit);
   let personal_injury_premium = parseFloat(socotraApi.tableLookup(tableName, personal_injury_limit))
   return personal_injury_premium;
}

function getPremiumForOtherLocationsOccupiedbyInsured(exposures, peril) {
   let exposure_fv = Helpers.getExposureFieldValues(peril,exposures);
   let no_of_families = exposure_fv.no_of_families;
   let state = exposure_fv.property_state;
   let tableName = ratingConstants.tableNameConsts.other_loc_rate_table;
   tableName = Helpers.getTableName(state, tableName);
   let insured_premium = parseFloat(socotraApi.tableLookup(tableName, no_of_families));
   return insured_premium;
}

function getPremiumForGreenHomeAdditionalCoverage(total_annual_basic_premium) {
   let misc_annual_basic_premium = parseFloat(total_annual_basic_premium); //Need to update the dependent method(Misc Annual Basic Premium) from discounts
   let green_upgrades_premium = (ratingConstants.numberConstants.point_zero_four_five * misc_annual_basic_premium).round(ratingConstants.numberConstants.two);
   return green_upgrades_premium;
}

function getPremiumForStudentAwayFromHome(perils, peril, exposures, policyExposurePerils) {
   let exposure_fv = Helpers.getExposureFieldValues(peril,exposures);
   let state = exposure_fv.property_state;
   let tableName = ratingConstants.tableNameConsts.student_away_from_home_rate_table;
   tableName = Helpers.getTableName(state, tableName);
   let student_away_from_home_cov_e_rate;
   let student_away_from_home_cov_f_rate;
   for (let policy_exposure_peril of policyExposurePerils) {
      let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
      let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;  
      if (otherPeril.name == ratingConstants.perilNameConstants.coverage_e) {
         let coverage_e_personal_liability_limit = otherPeril_fv.coverage_e_personal_liability_limit;
         coverage_e_personal_liability_limit = Helpers.removeSpecialCharacters(coverage_e_personal_liability_limit);
         let coverage_e_personal_liability_limit_key = ratingConstants.tableKeyConstants.cov_e + ratingConstants.tableKeyConstants.pipe + coverage_e_personal_liability_limit;
         student_away_from_home_cov_e_rate = parseFloat(socotraApi.tableLookup(tableName, coverage_e_personal_liability_limit_key));
      }
      if (otherPeril.name == ratingConstants.perilNameConstants.coverage_f) {
         let medical_payments_limit = otherPeril_fv.medical_payments_limit;
         medical_payments_limit = Helpers.removeSpecialCharacters(medical_payments_limit);
         let coverage_f_medical_payment_limit_key = ratingConstants.tableKeyConstants.cov_f + ratingConstants.tableKeyConstants.pipe + medical_payments_limit;
         student_away_from_home_cov_f_rate = parseFloat(socotraApi.tableLookup(tableName, coverage_f_medical_payment_limit_key));
      }
   }
   let student_away_from_home_premium = student_away_from_home_cov_e_rate + student_away_from_home_cov_f_rate;
   student_away_from_home_premium = student_away_from_home_premium.round(ratingConstants.numberConstants.two);

   return student_away_from_home_premium;
}

function getPremiumForResidenceHeldinTrust(perils, peril,exposures, policyExposurePerils) {
   let exposure_fv = Helpers.getExposureFieldValues(peril,exposures);
   let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
   let state = exposure_fv.property_state;
   let tableName = ratingConstants.tableNameConsts.residence_held_in_trust_rate_table;
   tableName = Helpers.getTableName(state, tableName);
   let residence_held_in_trust_cov_e_rate;
   let residence_held_in_trust_cov_f_rate;
   for (let policy_exposure_peril of policyExposurePerils) {
      let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
      let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;  
      if (otherPeril.name == ratingConstants.perilNameConstants.coverage_e) {
         let coverage_e_personal_liability_limit = otherPeril_fv.coverage_e_personal_liability_limit;
         coverage_e_personal_liability_limit = Helpers.removeSpecialCharacters(coverage_e_personal_liability_limit);
         let coverage_e_personal_liability_limit_key = ratingConstants.tableKeyConstants.cov_e + ratingConstants.tableKeyConstants.pipe + coverage_e_personal_liability_limit;
         residence_held_in_trust_cov_e_rate = parseFloat(socotraApi.tableLookup(tableName, coverage_e_personal_liability_limit_key));
      }
      if (otherPeril.name == ratingConstants.perilNameConstants.coverage_f) {
         let medical_payments_limit = otherPeril_fv.medical_payments_limit
         medical_payments_limit = Helpers.removeSpecialCharacters(medical_payments_limit);
         let coverage_f_medical_payment_limit_key = ratingConstants.tableKeyConstants.cov_f + ratingConstants.tableKeyConstants.pipe + medical_payments_limit;
         residence_held_in_trust_cov_f_rate = parseFloat(socotraApi.tableLookup(tableName, coverage_f_medical_payment_limit_key));
      }
   }
   let residence_held_in_trust_premium = residence_held_in_trust_cov_e_rate + residence_held_in_trust_cov_f_rate;
   residence_held_in_trust_premium = residence_held_in_trust_premium.round(ratingConstants.numberConstants.two);
   return residence_held_in_trust_premium;
}

function getPremiumForAssistedLivingCareCoverage(peril,exposures) {
   let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
   let peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;
   let assisted_coverage_details_groups = peril_fv.assisted_coverage_details;
   let assisted_living_increase_cov_e_rate = ratingConstants.numberConstants.zero;
   let assisted_c_limit = ratingConstants.numberConstants.zero;
   
   let exposure_fv = Helpers.getExposureFieldValues(peril,exposures);
   let state = exposure_fv.property_state;
   
   let living_care_rate_table = ratingConstants.tableNameConsts.assisted_living_care_rate_table;
   living_care_rate_table = Helpers.getTableName(state, living_care_rate_table);
   
   let living_care_inc_cov_c_rate_table = ratingConstants.tableNameConsts.assisted_living_increase__cov_c_rate_table;
   living_care_inc_cov_c_rate_table = Helpers.getTableName(state, living_care_inc_cov_c_rate_table);
   
   let living_care_inc_cov_e_rate_table = ratingConstants.tableNameConsts.assisted_living_increase_cov_e_rate_table;
   living_care_inc_cov_e_rate_table = Helpers.getTableName(state, living_care_inc_cov_e_rate_table);
   let assisted_living_c_limit = ratingConstants.numberConstants.zero;
   for(let assisted_coverage_details_group of assisted_coverage_details_groups)
   {
      let name_of_relative = peril_fgv[assisted_coverage_details_group].name_of_relative;
      let assisted_e_limit = peril_fgv[assisted_coverage_details_group].assisted_e_limit;
      if(assisted_e_limit != undefined)
      assisted_e_limit = Helpers.removeSpecialCharacters(assisted_e_limit);
      assisted_c_limit = peril_fgv[assisted_coverage_details_group].assisted_c_limit;
      if(assisted_c_limit != undefined)
      assisted_c_limit = parseFloat(Helpers.removeSpecialCharacters(assisted_c_limit));
      if(assisted_e_limit != undefined)
      {
         assisted_living_increase_cov_e_rate += parseFloat(socotraApi.tableLookup(living_care_inc_cov_e_rate_table, assisted_e_limit));
      }
      else
      {
         assisted_living_increase_cov_e_rate = 0;
      }
      if(assisted_c_limit != undefined)
      {
         assisted_living_c_limit += assisted_c_limit;
      }
      else
      {
         assisted_living_c_limit = 0;
      }
   }

   
   let assisted_living_care_rate = parseFloat(socotraApi.tableLookup(living_care_rate_table, ratingConstants.tableKeyConstants.rate));
   let assisted_living_increase_cov_c_rate = parseFloat(socotraApi.tableLookup(living_care_inc_cov_c_rate_table, ratingConstants.tableKeyConstants.rate));
   let assisted_living_care_Premium = assisted_living_care_rate + (assisted_living_c_limit / ratingConstants.numberConstants.one_thousand) * assisted_living_increase_cov_c_rate + assisted_living_increase_cov_e_rate;
   assisted_living_care_Premium = assisted_living_care_Premium.round(2)
   return assisted_living_care_Premium;
}

function getPremiumForLimitedSpecialComputerEquipmentCoverage(peril,exposures) {
   let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
   let exposure_fv = Helpers.getExposureFieldValues(peril,exposures);
   let state = exposure_fv.property_state;
   let tableName = ratingConstants.tableNameConsts.limited_special_computer_equipment_table;
   tableName = Helpers.getTableName(state, tableName);
   let computer_equipment_limit = peril_fv.computer_equipment_limit;
   computer_equipment_limit = Helpers.removeSpecialCharacters(computer_equipment_limit);
   let computer_equipment_deductible = peril_fv.computer_equipment_deductible;
   computer_equipment_deductible = Helpers.removeSpecialCharacters(computer_equipment_deductible);
   let limited_special_computer_equipment_key = computer_equipment_limit + ratingConstants.tableKeyConstants.pipe + computer_equipment_deductible + ratingConstants.tableKeyConstants.pipe + ratingConstants.tableKeyConstants.HO5
   let limited_special_computer_equipment_premium = parseFloat(socotraApi.tableLookup(tableName,limited_special_computer_equipment_key));
   return limited_special_computer_equipment_premium;
}

function getPremiumForGolfCartPhysicalLossCoverage(peril,exposures)
{
   let exposure_fv = Helpers.getExposureFieldValues(peril,exposures);
   let state = exposure_fv.property_state;
   let tableName = ratingConstants.tableNameConsts.scheduled_golf_cart_rate_table;
   tableName = Helpers.getTableName(state, tableName);
   let scheduled_golf_cart_total_premium = ratingConstants.numberConstants.zero;
   let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
   let peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;
   let golf_cart_groups = peril_fv.golf_cart_details;
   let scheduled_golf_cart_rate = ratingConstants.numberConstants.zero;
   let golfcart_limit;
   if(golf_cart_groups != undefined)
   {
      for(let golf_cart_group of golf_cart_groups)
      {
         let golfcart_collision_cover = peril_fgv[golf_cart_group].golfcart_collision_cover;
         scheduled_golf_cart_rate += parseFloat(socotraApi.tableLookup(tableName, golfcart_collision_cover));
         golfcart_limit = parseFloat(Helpers.removeSpecialCharacters(peril_fgv[golf_cart_group].golfcart_limit));
      }
   }

   let scheduled_golf_cart_premium = ((Math.round(parseFloat(golfcart_limit/ratingConstants.numberConstants.five_hundred)) * scheduled_golf_cart_rate)).round(ratingConstants.numberConstants.two);
   scheduled_golf_cart_total_premium = scheduled_golf_cart_total_premium + scheduled_golf_cart_premium;
   return scheduled_golf_cart_total_premium;
}

function getPremiumForWaterBackupAndSumpOverflow(perils, peril, exposures, policyExposurePerils)
{
   let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
   let exposure_fv = Helpers.getExposureFieldValues(peril,exposures);
   let state = exposure_fv.property_state;
   let electrical_power_backup = exposure_fv.electrical_power_backup;
   let tableName = ratingConstants.tableNameConsts.water_backup_rate_table;
   tableName = Helpers.getTableName(state, tableName);
   let water_backup_limit = peril_fv.water_backup_limit;
   water_backup_limit = Helpers.removeSpecialCharacters(water_backup_limit);
   let water_backup_deductible = peril_fv.water_backup_deductible;
   water_backup_deductible = Helpers.removeSpecialCharacters(water_backup_deductible);
   let water_backup_premium;
   let pprc;
   let coverage_c_settlement_option;
   for (let policy_exposure_peril of policyExposurePerils) {
      let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
      let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;
      if (otherPeril.name == ratingConstants.perilNameConstants.coverage_c) {
          coverage_c_settlement_option = otherPeril_fv.coverage_c_settlement_option;
      }
  }
  if(coverage_c_settlement_option == ratingConstants.perilValueConstansts.replacement_cost)
  {
     pprc = ratingConstants.binaryConstants.yes;
  }
  else
  {
     pprc = ratingConstants.binaryConstants.no;
  }
  let tableKey = ratingConstants.tableKeyConstants.HO3 + ratingConstants.tableKeyConstants.pipe + pprc + ratingConstants.tableKeyConstants.pipe +
  water_backup_limit + ratingConstants.tableKeyConstants.pipe + water_backup_deductible;
  let water_back_up_rate = parseFloat(socotraApi.tableLookup(tableName,tableKey))
  if(electrical_power_backup == ratingConstants.binaryConstants.yes)
  {
      water_backup_premium = water_back_up_rate * ratingConstants.numberConstants.point_eight;
  }
  else
  {
      water_backup_premium = water_back_up_rate * ratingConstants.numberConstants.one;
  }
  water_backup_premium = water_backup_premium.round(ratingConstants.numberConstants.two);
  return water_backup_premium;

}

function getPremiumForHomeDayCareCoverage(perils, peril, exposures, policyExposurePerils)
{
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    let peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;

    let exposure_fv = Helpers.getExposureFieldValues(peril,exposures);
    let state = exposure_fv.property_state;
    let tableName = ratingConstants.tableNameConsts.home_day_care_rate_table;
    tableName = Helpers.getTableName(state, tableName);
    let home_day_care_cov_e_rate;
    let home_day_care_cov_f_rate;
    let misc_home_day_care_premium = ratingConstants.numberConstants.zero;
    let home_day_care_business_location = peril_fv.home_day_care_business_location;
    let home_day_details_groups = peril_fv.home_day_details;
    let home_day_care_structure_limit = ratingConstants.numberConstants.zero;
    let liability_home_day_care_premium =  ratingConstants.numberConstants.zero;
    
    for(let home_day_details_group of home_day_details_groups)
    {
        home_day_care_structure_limit += parseFloat(Helpers.removeSpecialCharacters(peril_fgv[home_day_details_group].home_day_care_structure_limit));
    }

   if(home_day_care_business_location == "In the dwelling building or unit in which the insured resides and shown as residence premises")
   {
    for (let policy_exposure_peril of policyExposurePerils) {
       let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
       let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;
       if (otherPeril.name == ratingConstants.perilNameConstants.coverage_e) {
          let coverage_e_personal_liability_limit = otherPeril_fv.coverage_e_personal_liability_limit;
          coverage_e_personal_liability_limit = Helpers.removeSpecialCharacters(coverage_e_personal_liability_limit);
          let coverage_e_personal_liability_limit_key = ratingConstants.tableKeyConstants.cov_e + ratingConstants.tableKeyConstants.pipe + coverage_e_personal_liability_limit;
          home_day_care_cov_e_rate = parseFloat(socotraApi.tableLookup(tableName, coverage_e_personal_liability_limit_key));
 
       }
       if (otherPeril.name == ratingConstants.perilNameConstants.coverage_f) {
          let medical_payments_limit = otherPeril_fv.medical_payments_limit;
          medical_payments_limit = Helpers.removeSpecialCharacters(medical_payments_limit);
          let coverage_f_medical_payment_limit_key = ratingConstants.tableKeyConstants.cov_f + ratingConstants.tableKeyConstants.pipe + medical_payments_limit;
          home_day_care_cov_f_rate = parseFloat(socotraApi.tableLookup(tableName, coverage_f_medical_payment_limit_key));
       }
    }
    
    liability_home_day_care_premium =  home_day_care_cov_e_rate + home_day_care_cov_f_rate;
    liability_home_day_care_premium = liability_home_day_care_premium.round(ratingConstants.numberConstants.two);
   }
    
    if(home_day_care_business_location == "In an other structure on or at the location of the residence premises")
    {
        let miscTableName = ratingConstants.tableNameConsts.home_day_misc_care_rate_table;
        miscTableName = Helpers.getTableName(state, miscTableName);
        let misc_home_day_care_rate = parseFloat(socotraApi.tableLookup(miscTableName, ratingConstants.tableKeyConstants.rate));
        misc_home_day_care_premium = (home_day_care_structure_limit/ratingConstants.numberConstants.one_thousand) * misc_home_day_care_rate;
        misc_home_day_care_premium = misc_home_day_care_premium.round(ratingConstants.numberConstants.two);
    }
    
    let home_day_care_premium = parseFloat(liability_home_day_care_premium) + parseFloat(misc_home_day_care_premium);
    return{
       liability_home_day_care_premium,
       misc_home_day_care_premium,
       home_day_care_premium
    }
}



exports.getPremiumForDeviceProtection = getPremiumForDeviceProtection;
exports.getPremiumForFamilyCyberProtection = getPremiumForFamilyCyberProtection;
exports.getPremiumForLandlordsFurnishingsIncreasedLimits = getPremiumForLandlordsFurnishingsIncreasedLimits;
exports.getPremiumPersonalInjuryCoverage = getPremiumPersonalInjuryCoverage;
exports.getPremiumForOtherLocationsOccupiedbyInsured = getPremiumForOtherLocationsOccupiedbyInsured;
exports.getPremiumForGreenHomeAdditionalCoverage = getPremiumForGreenHomeAdditionalCoverage;
exports.getPremiumForStudentAwayFromHome = getPremiumForStudentAwayFromHome;
exports.getPremiumForResidenceHeldinTrust = getPremiumForResidenceHeldinTrust;
exports.getPremiumForAssistedLivingCareCoverage = getPremiumForAssistedLivingCareCoverage;
exports.getPremiumForLimitedSpecialComputerEquipmentCoverage = getPremiumForLimitedSpecialComputerEquipmentCoverage;
exports.getPremiumForGolfCartPhysicalLossCoverage = getPremiumForGolfCartPhysicalLossCoverage;
exports.getPremiumForWaterBackupAndSumpOverflow = getPremiumForWaterBackupAndSumpOverflow;
exports.getPremiumForHomeDayCareCoverage = getPremiumForHomeDayCareCoverage;
