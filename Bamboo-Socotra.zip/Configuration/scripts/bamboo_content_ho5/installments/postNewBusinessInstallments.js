let arrays = require("../libraries/arrays.js");
let dates = require('../libraries/dates.js');
let installmentConstants = require("../constants/constants.js");
let moment = require("../libraries/moment-with-locales.js");
let helpers = require("./installmentHelpers.js");
const {
    addDays
} = require("../underwriting/helpersUW.js");

function createPostNewBusinessInstallments(data, installments) {

    let billTo = data.policy.characteristics.last().fieldValues.bill_to;
    let paymentScheduleName;
    if(billTo == "Mortgagee" && data.paymentScheduleName == installmentConstants.paymentScheduleConstants.full_pay)
    paymentScheduleName = installmentConstants.paymentScheduleConstants.mortgage;
    else
    paymentScheduleName = data.paymentScheduleName;

    arrays.polyfill();
    switch (paymentScheduleName) {
        case installmentConstants.paymentScheduleConstants.mortgage:
            installments = getUpfrontMortgageEndorsement(data);
            break;
        case installmentConstants.paymentScheduleConstants.full_pay:
            installments = getUpfrontEndorsement(data);
            break;
        case installmentConstants.paymentScheduleConstants.quarterly:
            installments = CreateIntallments(data, installmentConstants.termConstants.ninty_days, installmentConstants.numberConstants.four);
            break;
        case installmentConstants.paymentScheduleConstants.monthly:
            installments = CreateIntallments(data, installmentConstants.termConstants.thirty_days, installmentConstants.numberConstants.twelve);
            break;
        default:
            throw installmentConstants.termConstants.exception;
    }
    return installments;
}

function getUpfrontEndorsement(data) {
    let invoiceItems = data.charges.map(ch => ({
        amount: ch.amount,
        chargeId: ch.chargeId
    }));

    let installmentFees;
    if (data.operation == installmentConstants.operationConstants.endorsement) {
        let paymentMode = data.policy.characteristics.last().fieldValues.payment_mode;
        if (paymentMode === undefined)
            paymentMode = null;
        else 
            paymentMode = paymentMode.last();
        installmentFees = [];
        //   if (paymentMode === "Automatic" && (data.productName === "HO-3" ))
        //   {
        //       installmentFees = [{
        //       feeName: installmentConstants.feeConstants.installment_fee_cards_ach,
        //       description: "Installment Fee- Automatic payment via cards, ACH",
        //       amount: 3
        //      }];
        //      console.log(JSON.stringify(installmentFees));
        //   }
        //   else
        //   {
        //       installmentFees = [{
        //       feeName: installmentConstants.feeConstants.installment_fee_other,
        //       description: "Installment Fee- Other than Automatic payments",
        //       amount: 10
        //     }];
        //   }
    }
    let Today_date = new Date();
    Today_date = moment(Today_date).format(installmentConstants.dateFormat.year_month_date);
    let nowTimestamp = new Date().getTime();
    let endorse_timestamp = data.coverageStartTimestamp;
    let endorse_date = new Date(+endorse_timestamp);
    endorse_date = moment(endorse_date).format(installmentConstants.dateFormat.year_month_date);

    if (endorse_date == Today_date) {
        nowTimestamp = data.coverageStartTimestamp;
    }

    return [{
        dueTimestamp: data.coverageStartTimestamp,
        issueTimestamp: nowTimestamp,
        startTimestamp: data.coverageStartTimestamp,
        endTimestamp: data.coverageEndTimestamp,
        invoiceItems: invoiceItems,
        installmentFees: installmentFees,
        writeOff: false
    }];
}

function getUpfrontMortgageEndorsement(data) {
    let invoiceItems = data.charges.map(ch => ({
        amount: ch.amount,
        chargeId: ch.chargeId
    }));

    let installmentFees;
    if (data.operation == installmentConstants.operationConstants.endorsement) {
        let paymentMode = data.policy.characteristics.last().fieldValues.payment_mode;
        if (paymentMode === undefined)
            paymentMode = null;
        else 
            paymentMode = paymentMode.last();
         installmentFees = [];
         if(paymentMode === "Automatic" && (data.productName === "HO-3" )) {
            installmentFees = [{
                    feeName: installmentConstants.feeConstants.installment_fee_cards_ach,
                    description: "Installment Fee- Automatic payment via cards, ACH",
                    amount: 3
                }
            ];
        }
        else
        {
            installmentFees = [{
                    feeName: installmentConstants.feeConstants.installment_fee_other,
                    description: "Installment Fee- Other than Automatic payments",
                    amount: 10
                }
            ];
        }
    }

    let nowTimestamp = new Date().getTime();
    let duetimestamp = data.coverageStartTimestamp;
    duetimestamp = new Date(+duetimestamp);
    let setdueTimestamp = addDays(duetimestamp, 30);
    setdueTimestamp = new Date(setdueTimestamp).getTime();

    let Today_date = new Date();
    Today_date = moment(Today_date).format(installmentConstants.dateFormat.year_month_date);
    let endorse_timestamp = data.coverageStartTimestamp;
    let endorse_date = new Date(+endorse_timestamp);
    endorse_date = moment(endorse_date).format(installmentConstants.dateFormat.year_month_date);

    if (endorse_date == Today_date) {
        nowTimestamp = data.coverageStartTimestamp;
    }

    return [{
        dueTimestamp: setdueTimestamp,
        issueTimestamp: nowTimestamp,
        startTimestamp: data.coverageStartTimestamp,
        endTimestamp: data.coverageEndTimestamp,
        invoiceItems: invoiceItems,
        installmentFees: installmentFees,
        writeOff: false
    }];
}

function getUpfrontForCancellation(data) {
    let invoiceItems = data.charges.map(ch => ({
        amount: ch.amount,
        chargeId: ch.chargeId
    }));

    let Today_date = new Date();
    Today_date = moment(Today_date).format(installmentConstants.dateFormat.year_month_date);
    let nowTimestamp = new Date().getTime();
    let endorse_timestamp = data.coverageStartTimestamp;
    let endorse_date = new Date(+endorse_timestamp);
    endorse_date = moment(endorse_date).format(installmentConstants.dateFormat.year_month_date);

    if (endorse_date == Today_date) {
        nowTimestamp = data.coverageStartTimestamp;
    }

    return [{
        dueTimestamp: data.coverageStartTimestamp,
        issueTimestamp: nowTimestamp,
        startTimestamp: data.coverageStartTimestamp,
        endTimestamp: data.coverageEndTimestamp,
        invoiceItems: invoiceItems,
        writeOff: false
    }];
}

function CreateIntallments(data, increment, maxInstallments = installmentConstants.numberConstants.thousand) {
    let nowTimestamp = new Date().getTime();
    let policyCharacteristics = data.policy.characteristics;
    let policyStartTimeStamp = policyCharacteristics[policyCharacteristics.length-1].startTimestamp;
    let startTimestamp = data.charges.min(c => parseInt(policyStartTimeStamp));
    console.log("🚀 ~ file: postNewBusinessInstallments.js ~ line 179 ~ CreateIntallments ~ startTimestamp", startTimestamp)
    let endTimestamp = data.charges.max(c => parseInt(data.policy.effectiveContractEndTimestamp));
    console.log("🚀 ~ file: postNewBusinessInstallments.js ~ line 181 ~ CreateIntallments ~ endTimestamp", endTimestamp)
    let startMoment = dates.fromTimestamp(startTimestamp, data.tenantTimeZone);
    console.log("🚀 ~ file: postNewBusinessInstallments.js ~ line 183 ~ CreateIntallments ~ startMoment", startMoment)
    let endMoment = dates.fromTimestamp(endTimestamp, data.tenantTimeZone);
    console.log("🚀 ~ file: postNewBusinessInstallments.js ~ line 185 ~ CreateIntallments ~ endMoment", endMoment)
    let installmentTimestamps = dates.span(startMoment, endMoment, increment)
        .map(m => dates.getTimestamp(m));
    console.log("🚀 ~ file: postNewBusinessInstallments.js ~ line 165 ~ CreateIntallments ~ installmentTimestamps", installmentTimestamps)
    if (installmentTimestamps.length == 0)
        installmentTimestamps = [nowTimestamp];
    else if (installmentTimestamps.length > maxInstallments)
        installmentTimestamps = installmentTimestamps.slice(0, maxInstallments);
        console.log("🚀 ~ file: postNewBusinessInstallments.js ~ line 171 ~ CreateIntallments ~ installmentTimestamps", installmentTimestamps)
    let installments = [];
    let setissuetimestamp;
    let setstarttimestamp;
    let currentInstallment = 0;
    let times_date;
    let cov_date;
    let start_date;
    let isFutureDated = false;
    if (data.operation == installmentConstants.operationConstants.reinstatement) {
        for (let i = 0; i < installmentTimestamps.length; i++) {
            cov_date = new Date(+data.coverageStartTimestamp);
            cov_date = moment(cov_date).format(installmentConstants.dateFormat.year_month_date);
            start_date = new Date(+startTimestamp);
            start_date = moment(start_date).format(installmentConstants.dateFormat.year_month_date);
            times_date = new Date(installmentTimestamps[i]);
            times_date = moment(times_date).format(installmentConstants.dateFormat.year_month_date);
            if (times_date === cov_date) {
                currentInstallment = i;
                break;
            } else if ((installmentTimestamps[i] < data.coverageStartTimestamp) &&
                (data.coverageStartTimestamp < installmentTimestamps[i + 1])) {
                currentInstallment = i;
                break;

            } else if (i == installmentTimestamps.length - 1) {
                if ((installmentTimestamps[i] <= data.coverageStartTimestamp) &&
                    (data.coverageStartTimestamp < endTimestamp)) {
                    currentInstallment = i;
                    break;
                }
            }
        }
    }
    let plannedInvoicesLength = data.plannedInvoices.length;
    console.log("🚀 ~ file: postNewBusinessInstallments.js ~ line 224 ~ CreateIntallments ~ plannedInvoicesLength", plannedInvoicesLength)
    let GeneratedInvoiceslength = maxInstallments - plannedInvoicesLength;
    console.log("🚀 ~ file: postNewBusinessInstallments.js ~ line 226 ~ CreateIntallments ~ GeneratedInvoiceslength", GeneratedInvoiceslength)
    if (data.operation == installmentConstants.operationConstants.endorsement) {
        let i = GeneratedInvoiceslength - 1;
        if ((installmentTimestamps[i] <= data.coverageStartTimestamp) && (data.coverageStartTimestamp < installmentTimestamps[i + 1])) {
            currentInstallment = i;
        } else if (plannedInvoicesLength == 0) {
            if ((installmentTimestamps[i] <= data.coverageStartTimestamp) && (data.coverageStartTimestamp < endTimestamp)) {
                currentInstallment = i;
            }
        } else {
            currentInstallment = i + 1;
            isFutureDated = true;
        }
    }

    for (let i = currentInstallment; i < installmentTimestamps.length; i++) {
        let Today_date = new Date();
        Today_date = moment(Today_date).format(installmentConstants.dateFormat.year_month_date);
        let nowTimestamp = new Date().getTime();
        let endorse_timestamp = data.coverageStartTimestamp;
        let endorse_date = new Date(+endorse_timestamp);
        endorse_date = moment(endorse_date).format(installmentConstants.dateFormat.year_month_date);
        if (endorse_date == Today_date) {
            nowTimestamp = data.coverageStartTimestamp;
            console.log("🚀 ~ file: postNewBusinessInstallments.js ~ line 250 ~ CreateIntallments ~ nowTimestamp", nowTimestamp)
        }
        let installmentTimestamp = installmentTimestamps[i];
        let latestInvoiceStartTimeStamp = data.policy.invoices[data.policy.invoices.length - 1].startTimestamp;
        if (latestInvoiceStartTimeStamp < installmentTimestamp && data.policy.invoices[0] != undefined) {
            setstarttimestamp = installmentTimestamp;
            setissuetimestamp = addDays(installmentTimestamp, -20);
            setissuetimestamp = new Date(+setissuetimestamp).getTime();
        } else if (i >= currentInstallment + 1) {
            setstarttimestamp = installmentTimestamp;
            setissuetimestamp = installmentTimestamp;
        } else if (i == currentInstallment) {
            setstarttimestamp = data.coverageStartTimestamp;
            setissuetimestamp = nowTimestamp;
        }

        installments.push({
            invoiceItems: [],
            dueTimestamp: setstarttimestamp,
            startTimestamp: setstarttimestamp,
            issueTimestamp: setissuetimestamp,
            endTimestamp: i < installmentTimestamps.length - 1 ? installmentTimestamps[i + 1] : endTimestamp,
            writeOff: false
        });
    }

    if (maxInstallments == installmentConstants.numberConstants.four && data.operation == installmentConstants.operationConstants.endorsement) {
        return SetAmountsToInstallments(data, installments, endTimestamp, isFutureDated, installmentTimestamps);
    }
    if (maxInstallments == installmentConstants.numberConstants.twelve && data.operation == installmentConstants.operationConstants.endorsement) {
        return SetAmountsToInstallments(data, installments, endTimestamp, isFutureDated, installmentTimestamps);
    }
    if (maxInstallments == installmentConstants.numberConstants.four && data.operation == installmentConstants.operationConstants.reinstatement) {
        return SetAmountsToInstallmentsRN(data, installments, startTimestamp);
    }
    if (maxInstallments == installmentConstants.numberConstants.twelve && data.operation == installmentConstants.operationConstants.reinstatement) {
        return SetAmountsToInstallmentsRN(data, installments, startTimestamp);
    }
}

function SetAmountsToInstallments(data, installments, endTimestamp, isFutureDated, installmentTimestamps) {
    let policyEffectiveTimeStamp = data.policy.originalContractStartTimestamp;
    for (charge of data.charges) {
        let endorsementStartTimeStamp = data.coverageStartTimestamp;
        charge = helpers.identifyChargeOfEndPeril(endorsementStartTimeStamp, data.charges, charge, policyEffectiveTimeStamp);
        let newItems = [];
        for (let i = 0; i < installments.length; i++) {
            let newItem = {
                chargeId: charge.chargeId
            };
            if (installments.length == 1) {
                newItems.push(newItem);
                installments[i].invoiceItems.push(newItem);
            } else if (((endorsementStartTimeStamp <= installments[i].startTimestamp) ||
                    (installments[i].endTimestamp > endorsementStartTimeStamp)) && (charge.isEnded == true) && (charge.isNew == true)) {
                newItems.push(newItem);
                installments[i].invoiceItems.push(newItem);
                break;
            } else if (((endorsementStartTimeStamp <= installments[i].startTimestamp) ||
                    (installments[i].endTimestamp > endorsementStartTimeStamp)) && (charge.isNew == true)) {
                newItems.push(newItem);
                installments[i].invoiceItems.push(newItem);
            } else if (charge.isNew == false) {
                if (charge.isEnded == true) {
                    if (isFutureDated == true) {
                        newItems.push(newItem);
                        if ((endorsementStartTimeStamp <= installments[i].startTimestamp) ||
                            (installments[i].endTimestamp > endorsementStartTimeStamp)) {
                            installments[i].invoiceItems.push(newItem);
                            break;
                        } else {
                            installments[i].invoiceItems.push(newItem);
                        }
                    } else {
                        if ((endorsementStartTimeStamp <= installments[i].startTimestamp) ||
                            (installments[i].endTimestamp > endorsementStartTimeStamp)) {
                            newItems.push(newItem);
                            installments[i].invoiceItems.push(newItem);
                            break;
                        }
                    }
                } else {
                    if (isFutureDated == true) {
                        newItems.push(newItem);
                        installments[i].invoiceItems.push(newItem);
                    } else if (isFutureDated == false && i < installments.length - 1) {
                        newItems.push(newItem);
                        installments[i + 1].invoiceItems.push(newItem);
                    }
                }
            }
        }
        let amount = parseFloat(charge.amount);
        let prorated_amount;
        let installment;
        if ((charge.isEnded == true && charge.isNew == true) || (installments.length == 1)) {
            prorated_amount = parseFloat(charge.amount);
        } else if (installments.length > 1 && charge.isNew == true) {
                let endorsement_days = helpers.getEndorsementDays(data.coverageStartTimestamp, endTimestamp);
                let prorated_days = helpers.getProratedDays(endorsementStartTimeStamp, installments);
                prorated_amount = helpers.round2(parseFloat(charge.amount) * (prorated_days / endorsement_days));
                let remaining_amount = amount - prorated_amount;
                let length = helpers.getLengthOfInstallments(installmentTimestamps, endorsementStartTimeStamp, endTimestamp)
                installment = helpers.round2(remaining_amount / (length - 1));
        } else if (charge.isNew == false) {
            let rem_amount = 0;
            if (newItems.length == 1) {
                prorated_amount = parseFloat(charge.amount);
            } else {
                if (isFutureDated == true)
                    rem_amount = amount / installments.length;
                else
                    rem_amount = amount / (installments.length - 1);
                prorated_amount = helpers.round2(rem_amount);
                installment = helpers.round2(rem_amount);
            }
        }

        for (let i = 0; i < newItems.length; i++) {
            if (i == 0) {
                newItems[i].amount = prorated_amount;
            } else if (i > 0 && i < newItems.length - 1) {
                newItems[i].amount = installment;
            } else {
                newItems[i].amount = helpers.round2(amount - newItems.slice(0, newItems.length - 1).sum(ni => ni.amount));
            }
        }
    }

    let installmentFees;
    if (data.operation == installmentConstants.operationConstants.endorsement) {
        let paymentMode = data.policy.characteristics.last().fieldValues.payment_mode;
        if (paymentMode == undefined)
            paymentMode = null;
        else 
            paymentMode = paymentMode.last();
        installmentFees = [];
          if (paymentMode == "Automatic" && (data.productName == "HO-3" ))
          {
            installments[0].installmentFees = [{
              feeName: installmentConstants.feeConstants.installment_fee_cards_ach,
              description: "Installment Fee- Automatic payment via cards, ACH",
              amount: 3
             }];
          }
          else
          {
              installments[0].installmentFees = [{
              feeName: installmentConstants.feeConstants.installment_fee_other,
              description: "Installment Fee- Other than Automatic payments",
              amount: 10
            }];
          }
    }
    return installments.filter(inst => inst.invoiceItems.length > 0);
}

function SetAmountsToInstallmentsRN(data, installments, startTimestamp) {
    for (charge of data.charges) {
        let newItems = [];
        for (let i = 0; i < installments.length; i++) {
            let newItem = {
                chargeId: charge.chargeId
            };
            if (charge.coverageEndTimestamp > charge.coverageStartTimestamp) {
                newItems.push(newItem);
                installments[i].invoiceItems.push(newItem);
            }
        }

        let amount = parseFloat(charge.amount);
        let prorated_amount;
        let installment;
        if (installments.length > 1) {
            let cancellationEffectiveDate = data.policy.cancellation.effectiveTimestamp;
            let premium = helpers.getProratdPremiumForRN(charge, cancellationEffectiveDate, startTimestamp, data.paymentScheduleName, installments);
            prorated_amount = premium.reinstatementPremium;
            installment = premium.installment;
        } else {
            prorated_amount = parseFloat(charge.amount);
        }
        for (let i = 0; i < newItems.length; i++) {
            if (i == 0) {
                newItems[i].amount = prorated_amount;
            } else if (i > 0 && i < newItems.length - 1) {
                newItems[i].amount = installment;
            } else {
                newItems[i].amount = helpers.round2(amount - newItems.slice(0, newItems.length - 1).sum(ni => ni.amount));
            }
        }
    }

    return installments.filter(inst => inst.invoiceItems.length > 0);
}

exports.createPostNewBusinessInstallments = createPostNewBusinessInstallments;
exports.getUpfrontForCancellation = getUpfrontForCancellation;