let manualUW = require("./manualUW.js");
let helpers = require("./helpersUW.js");
let constantValues = require("./underwritingConstants.js");
let exposureDwellingUW = require("./dwelling/exposureUW.js")
let perilsPLCUW = require("./policyLevelCoverages/perilUW.js");
let dwellingPerilsUW = require("./dwelling/perilUW.js");
let policyUW = require("./policyUW.js");

function getUWDecision(data) {
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;

  let allExposures = data.policy.exposures;
  let policyStartTimeStamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;
  socotraApi.setAuxData("locator", "key2", JSON.stringify(allExposures), "normal");

  if ((policy_fv.uw_details == undefined) || (policy_fgv[policy_fv.uw_details].manual_decision == undefined)) {
    helpers.uw_result.uw_notes = [];
    helpers.uw_result.uw_decisions = "";

    exposureDwellingUW.getExposureUWDecision(allExposures, policyStartTimeStamp);
    dwellingPerilsUW.getPerilUWDecision(allExposures);
    perilsPLCUW.getPLCPerilUWDecision(allExposures);
    policyUW.getPolicyUWDecision(data);

    let result = helpers.setUWDecision(constantValues.decisions.uw_accept, constantValues.messageConstants.accepted);
    if (result.uw_decisions == constantValues.decisions.uw_accept) {
      helpers.uw_result.uw_notes.push(constantValues.messageConstants.accepted);
    }
    
    return result;
  } else {
    let result = manualUW.getManualUWDecision(policy_fv,policy_fgv);
    return result;
  }
}
exports.getUWDecision = getUWDecision;