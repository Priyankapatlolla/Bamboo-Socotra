let constantValues = require("./underwritingConstants.js")
let helpers = require("./helpersUW.js")
let moment = require("../libraries/moment-with-locales.js")

function getPolicyUWDecision(data)
{
    let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
    let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
    let policyStartTimeStamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;
    let property_state;
    let allExposures = data.policy.exposures;
    for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    if (exposure.name == constantValues.exposureNameConstants.dwelling) {
    property_state = exposure_fv.property_state;
     }
     }
     if (property_state == constantValues.stateConstants.az) {
    getPolicyLevelUWDecision(policy_fv,policy_fgv,policyStartTimeStamp,property_state)
     }
}

function getPolicyLevelUWDecision(policy_fv,policy_fgv,policyStartTimeStamp,property_state)
{ 
    let prior_policy_history_groups = policy_fv.prior_policy_history;
    let loss_history_groups = policy_fv.loss_history;
    let chargeable_claim = constantValues.numberConstants.zero;
    if(prior_policy_history_groups != undefined)
    {
        for(let prior_policy_history_group of prior_policy_history_groups)
        {
            let late_payment = policy_fgv[prior_policy_history_group].late_payment;
            let num_late_cancellations = policy_fgv[prior_policy_history_group].num_late_cancellations;
            
            let prior_cancellation_date = policy_fgv[prior_policy_history_group].prior_cancellation_date;
            prior_cancellation_date = moment(prior_cancellation_date).format(constantValues.dateFormat.year_month_date);
            
            let policy_start_Date = new Date(+policyStartTimeStamp);
            policy_start_Date = moment(policy_start_Date).format(constantValues.dateFormat.year_month_date);
            
            let year_difference = moment(new Date(policy_start_Date)).diff(new Date(prior_cancellation_date), 'year', true);


            if(late_payment == constantValues.binaryConstants.uw_yes)
            {
                helpers.setUWDecision(constantValues.decisions.uw_none,
                    constantValues.messageConstants.message19);
            }
            if(num_late_cancellations > constantValues.numberConstants.two && year_difference >= constantValues.numberConstants.three)
            {
                helpers.setUWDecision(constantValues.decisions.uw_none,
                    constantValues.messageConstants.message20);
            }
        }
    }
    if(loss_history_groups != undefined)
    {
        for(let loss_history_group of loss_history_groups)
        {
            let loss_status = policy_fgv[loss_history_group].loss_status;
            let loss_amount = helpers.removeSpecialCharacters(policy_fgv[loss_history_group].loss_amount);
            let subrogation =policy_fgv[loss_history_group].subrogation;
            let claim_date = policy_fgv[loss_history_group].claim_date;
            claim_date = moment(claim_date).format(constantValues.dateFormat.year_month_date);
            let effective_date = new Date(+policyStartTimeStamp);
            if(loss_status == constantValues.policyValueConstants.disputed)
            {
                helpers.setUWDecision(constantValues.decisions.uw_none,
                    constantValues.messageConstants.message22);
            }
            if(loss_status == constantValues.policyValueConstants.open){
                helpers.setUWDecision(constantValues.decisions.uw_none,
                    constantValues.messageConstants.message25); 
            }
            if(loss_amount > constantValues.numberConstants.one_lakh){
                helpers.setUWDecision(constantValues.decisions.uw_none,
                    constantValues.messageConstants.message26); 
            }
            if(subrogation != undefined){
            let cat_code =socotraApi.tableLookup(helpers.getTableName(property_state,constantValues.tableNameConsts.col_cat_mapping_table),policy_fgv[loss_history_group].cause_of_loss)
            let cat_code_flag = socotraApi.tableLookup(helpers.getTableName(property_state,constantValues.tableNameConsts.Iso_cat_codes_table),cat_code);
            effective_date = moment(effective_date.setFullYear(effective_date.getFullYear()-3)).format("YYYY-MM-DD");
            if((loss_status == constantValues.policyValueConstants.closed) && (loss_amount > constantValues.numberConstants.five_hundred) && ((helpers.dates.compare(claim_date,effective_date) == constantValues.numberConstants.one) || (helpers.dates.compare(claim_date,effective_date) == constantValues.numberConstants.zero)) && (subrogation == constantValues.binaryConstants.uw_no) && (cat_code_flag != constantValues.binaryConstants.uw_yes)){
                chargeable_claim += 1;
            }
        }
        
        }
        if(chargeable_claim >= constantValues.numberConstants.two){
            helpers.setUWDecision(constantValues.decisions.uw_reject,
                constantValues.messageConstants.message23); 
        }
        
    
    }

    let attract_score = policy_fv.attract_score;
    attract_score = attract_score.toString().toLowerCase();
    if(attract_score == undefined || attract_score == constantValues.attractScoreConstants.no_hit || attract_score == constantValues.attractScoreConstants.no_score_or_thin_file || attract_score == constantValues.attractScoreConstants.no_score || attract_score == constantValues.attractScoreConstants.thin_file) 
    {
        helpers.setUWDecision(constantValues.decisions.uw_none,
            constantValues.messageConstants.message17);
    }
    if(attract_score <=constantValues.numberConstants.six_six_nine)
    {
        helpers.setUWDecision(constantValues.decisions.uw_none,
            constantValues.messageConstants.message29);
    }

    let ofac_status = policy_fv.ofac_status;
    if(ofac_status == constantValues.policyValueConstants.match_found){
        helpers.setUWDecision(constantValues.decisions.uw_none,
            constantValues.messageConstants.message27);
    }


}

exports.getPolicyUWDecision = getPolicyUWDecision;