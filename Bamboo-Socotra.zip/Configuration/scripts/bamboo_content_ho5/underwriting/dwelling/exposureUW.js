let constantValues = require("../underwritingConstants.js");
let helpers = require("../helpersUW.js")

function getExposureUWDecision(allExposures, policy_start_timestamp) {
    let property_state;
   for (let exposure of allExposures) {
   let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
   if (exposure.name == constantValues.exposureNameConstants.dwelling) {
   property_state = exposure_fv.property_state;
    }
    }
if (property_state == constantValues.stateConstants.az) {
     getDwelling1UWDecision(allExposures);
     getDwelling2UWDecision(allExposures, policy_start_timestamp);
     }
}

function getDwelling1UWDecision(allExposures)
{
    for (let exposure of allExposures) {
        let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
        if (exposure.name == constantValues.exposureNameConstants.dwelling) {
            let subject_to = exposure_fv.subject_to;
            let fuses = exposure_fv.fuses;
            let foot_traffic = exposure_fv.foot_traffic;
            let undergroundfuel_tanks = exposure_fv.undergroundfuel_tanks;
            //let distance_to_coast = exposure_fv.distance_to_coast;
            let wildfire_tiv = exposure_fv.wildfire_tiv;
            let windhail_tiv = exposure_fv.windhail_tiv;
            let whp_score = exposure_fv.whp_score;
            // let kat_risk_flood_score = exposure_fv.kat_risk_flood_score;
            let year_built = exposure_fv.year_built;

            if (subject_to == constantValues.binaryConstants.uw_yes) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                    constantValues.messageConstants.message1);
                }
            if (fuses == constantValues.binaryConstants.uw_yes) {
                helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.message2);
            }
            if (foot_traffic == constantValues.binaryConstants.uw_yes) {
                helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.message3);
            }
            if (undergroundfuel_tanks == constantValues.binaryConstants.uw_yes) {
                helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.message4);
            }
            // if(distance_to_coast < constantValues.numberConstants.one)
            // {
            //     helpers.setUWDecision(constantValues.decisions.uw_reject,constantValues.messageConstants.message5);
            // }
            if(wildfire_tiv > constantValues.numberConstants.five_crore)
            {
                helpers.setUWDecision(constantValues.decisions.uw_reject,constantValues.messageConstants.message6);
            }
            if((wildfire_tiv >= constantValues.numberConstants.four_crore) && (wildfire_tiv < constantValues.numberConstants.five_crore))
            {
                helpers.setUWDecision(constantValues.decisions.uw_none,constantValues.messageConstants.message8);
            }
            if(windhail_tiv > constantValues.numberConstants.five_crore)
            {
                helpers.setUWDecision(constantValues.decisions.uw_reject,constantValues.messageConstants.message7);
            }
            if((windhail_tiv >= constantValues.numberConstants.four_crore) && (windhail_tiv < constantValues.numberConstants.five_crore))
            {
                helpers.setUWDecision(constantValues.decisions.uw_none,constantValues.messageConstants.message9);
            }
            if((whp_score == constantValues.exposureValueConstants.high) || (whp_score == constantValues.exposureValueConstants.very_high) || (whp_score == constantValues.exposureValueConstants.extreme))
            {
                helpers.setUWDecision(constantValues.decisions.uw_reject,constantValues.messageConstants.message11);
            }
            // if(kat_risk_flood_score == constantValues.numberConstants.seven_to_ten)
            // {
            //     helpers.setUWDecision(constantValues.decisions.uw_reject,constantValues.messageConstants.message12);
            // }
            if (year_built < constantValues.numberConstants.ninteen_hundred){
                helpers.setUWDecision(constantValues.decisions.uw_none,constantValues.messageConstants.message16);  
            }
        }

        }
    }


function getDwelling2UWDecision(allExposures, policy_start_timestamp) {
    for (let exposure of allExposures) {
        let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
        if (exposure.name == constantValues.exposureNameConstants.dwelling) {
            let age_of_roof = helpers.getRoofOrHomeAge(exposure_fv.roof_year, policy_start_timestamp);
            console.log("🚀 ~ file: exposureUW.js ~ line 89 ~ getDwelling2UWDecision ~ age_of_roof", age_of_roof)
            let cape_roof_condition_score = exposure_fv.cape_roof_condition_score;
            let protection_class = exposure_fv.protection_class;
            if(age_of_roof != undefined){
           if((age_of_roof > constantValues.numberConstants.six) &&
             (cape_roof_condition_score == constantValues.numberConstants.empty || cape_roof_condition_score == undefined))
            {
                helpers.setUWDecision(constantValues.decisions.uw_none,
                    constantValues.messageConstants.message21);
            }
        }
            if(protection_class == undefined)
            {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                    constantValues.messageConstants.message24);
            }
        }
    }
}



exports.getExposureUWDecision = getExposureUWDecision;