
const decisions = {
    manual_accept: "Accept",
    manual_reject: "Reject",
    uw_accept: "accept",
    uw_reject: "reject",
    uw_none: "none"
};

const messageConstants = {
    accepted: "Accepted",
    message1: "We are unable to offer coverage at this time because the dwelling is subject to one of the following: unrepaired damage, known potential defects, open or pending claims of any kind, property disputes and/or lawsuits.",
    message2: "We are unable to offer coverage at this time because the dwelling has fuse(s) providing power to the dwelling.",
    message3: "We are unable to offer coverage at this time because the dwelling has business with foot traffic.",
    message4: "We are unable to offer coverage at this time because the dwelling has business with underground fuel tanks",
    message5: "We are unable to offer coverage at this time because the distance to coast is within 1 mile.",
    message6: "We are unable to offer coverage at this time because our concentration of property risks in your area has reached our maximum capacity.",
    message7: "We are unable to offer coverage at this time because our concentration of property risks in your area has reached our maximum capacity.",
    message8: "Coverage requires underwriting team's approval at this time because our concentration of property risks in your area is near our maximum capacity.",
    message9: "Coverage requires underwriting team's approval at this time because our concentration of property risks in your area is near our maximum capacity.",
    message10: "We are unable to offer coverage at this time because the dwelling replacement cost value is greater than $1.5 million.",
    message11: "We are unable to offer coverage at this time because the dwelling exposure to wildfire.",
    message12: "We are unable to offer coverage at this time because the dwelling exposure to flood.",
    message13: "Coverage B limits exceeds 20% of Coverage A.",
    message14: "Schedule Personal Property present",
    message15: "Home Day Care coverage present.",
    message16: "Dwelling built prior to 1900.",
    message17: "External vendor report unable to find Financial Responsibility Insurance Score.",
    message18: "Roofing Installation Information and Certification for Reduction in Residential Insurance Premiums Form needs to be approved by underwriting for Roof Covering Credits.  Please make sure the form is submitted.",
    message19: "Prior Policy has a history of late payments.",
    message20: "Prior Policy has a history of cancellation due to non-payment of premium.",
    message21: "Roof age is greater than 6 and Roof condition score is not available.",
    message22: "The disputed claims require underwriting approval.",
    message23: "We are unable to offer coverage at this time because the dwelling or applicant has had two or more chargeable losses in the past 36 months.",
    message24: "We are unable to offer coverage at this time because the Protection Class (PPC) is X or X.",
    message25: "One or more vendor reported losses are open",
    message26: "One or more reported losses occurred within the past 36 months and was greater than $100,000",
    message27: "OFAC: Potential match on OFAC register",
    message28: "Mitigation Credit Verification Affidavit Form needs to be approved by underwriting for Mitigation Credits. Please make sure the form is submitted.",
    message29: "Financial Responsibility Insurance Score unfavourable."

};

const stateConstants = {
    az: "AZ",
};

const policyBinaryConstants = {
};

const exposureNameConstants = {
    dwelling: "Dwelling",
    policy_level_coverages: "Policy Level Coverage"
};

const binaryConstants = {
    uw_yes: "Yes",
    uw_no: "No"
};

const numberConstants = {
    ten: 10,
    empty: "",
    zero: 0,
    one_lakh: 100000,
    thirty_thousand: 30000,
    seven_five_hundred: 7500,
    fifteen_thousand: 15000,
    twenty_five_hundred: 2500,
    one_thousand: 1000,
    ten_thousand: 10000,
    twenty_thousand: 20000,
    fifty_thousand: 50000,
    five_thousand: 5000,
    two:2,
    one : 1,
    five_crore:50000000,
    four_crore:40000000,
    fifteen_lakh:1500000,
    seven : 7,
    ninteen_hundred : 1900,
    zero : 0,
    point_two : 0.2,
    six:6,
    three:3,
    six_ninty_nine:699,
    five_hundred :500,
    six_six_nine:669,
    seven_to_ten : "7-10"
};

const exposureValueConstants = {
    vc: "Vacant",
    ws: "Wood Shake",
    wsh: "Wood Shingle",
    stoves: "Wood burning stoves",
    heater: "Space heater",
    fire: "Fireplace",
    more: "More than 8",
    high:"High",
    very_high : "Very High",
    extreme :"Extreme"
};

const perilNameConstants = {
    coverage_a: "Coverage A - Dwelling",
    schedule_personal_property: "Personal Property - Scheduled",
    home_day_care_coverage : "Home Day Care Coverage",
    coverage_b_other_structures : "Coverage B - Other Structures"


}

const perilValueContants = {
    replacement_cost: "Replacement Cost",
    cameras: "Cameras",
    coins: "Coins",
    fine_arts: "Fine Arts",
    fine_arts_breakage: "Fine Arts Breakage",
    furs: "Furs",
    golf_equipment: "Golf Equipment",
    jewelry: "Jewelry",
    musical_instruments: "Musical Instruments",
    silverware: "Silverware",
    stamps: "Stamps"
}

const attractScoreConstants = {
    no_hit: "no hit",
    no_score_or_thin_file: "no score/thin file",
    no_score: "no score",
    thin_file: "thin file"
}
const policyValueConstants = {
    disputed:"Disputed",
    match_found :"Match Found",
    open :"Open",
    closed :"Closed"
}

const dateFormat = {
    year_month_date: "YYYY-MM-DD"
};
const tableNameConsts = {
    Iso_cat_codes_table: "ISO_CAT_Codes_Table",
    col_cat_mapping_table:"COL_CAT_Mapping_Table"
}

exports.attractScoreConstants = attractScoreConstants;
exports.decisions = decisions;
exports.stateConstants = stateConstants;
exports.messageConstants = messageConstants;
exports.policyBinaryConstants = policyBinaryConstants;
exports.exposureNameConstants = exposureNameConstants;
exports.binaryConstants = binaryConstants;
exports.numberConstants = numberConstants;
exports.exposureValueConstants = exposureValueConstants;
exports.perilNameConstants = perilNameConstants;
exports.perilValueContants = perilValueContants;
exports.policyValueConstants = policyValueConstants;
exports.dateFormat = dateFormat;
exports.tableNameConsts = tableNameConsts;