//require("./moment-timezone-with-data-1970-2030.js");
require("../libraries/moment-timezone-with-data.js");
const moment = require("../libraries/moment-with-locales.js");

/*
   General utility class for manipulating timestamps based on their actual
   time-zone aware values for dates.

   The functions getTimestamp and getDateInfo use 1-based months, so
   January = 1, Febrary = 2, etc., unlike javascript's zero-based months.

   This class uses moment.js and moment timezone but doesn't expose moments
   outside of the private functions. After we upgrade v8 we can replace moment
   calcs with something better (luxon, perhaps)
*/

class DateCalc
{
    constructor(timeZone = 'UTC')
    {
        this._timeZone = timeZone;
    }
    /* one based months */
    getTimestamp(year = 1970, month = 1, day = 1, hour = 0, minute = 0, second = 0, millisecond = 0)
    {
        if (month < 1 || month > 12)
            throw `getTimestamp: month out of range. Use 1-based month values.`;

        return moment.tz( { year, month: month - 1, day, hour, minute, second, millisecond}, this._timeZone).valueOf();
    }
     /* one based months */
    getDateInfo(timestamp)
    {
        const m = this._toMoment(timestamp);
        return {
            year: m.year(),
            month: m.month() + 1,
            day: m.date(),
            hour: m.hour(),
            minute: m.minute(),
            second: m.second(),
            millisecond: m.millisecond()
        };
    }
    isDateInfoSame(info1, info2)
    {
        return info1.year === info2.year &&
               info1.month === info2.month &&
               info1.day === info2.day &&
               info1.hour === info2.hour &&
               info1.minute === info2.minute &&
               info1.second === info2.second &&
               info1.millisecond === info2.millisecond;
    }
    formatTimestamp(timestamp)
    {
        const di = this.getDateInfo(timestamp);
        return `${di.year}-${this._leadZero(di.month)}-${this._leadZero(di.day)} ${this._leadZero(di.hour)}:${this._leadZero(di.minute)}:${this._leadZero(di.second)}`;
    }
    formatTimestampDate(timestamp)
    {
        const di = this.getDateInfo(timestamp);
        return `${di.year}-${this._leadZero(di.month)}-${this._leadZero(di.day)}`;
    }
    _leadZero(num)
    {
        return ("00" + num.toString()).slice(-2);
    }
    // Return a series of timestamps from start to end incrementing using the increment key
    // Can also pass an array of day offsets like [60, 30]. If offsets run out, the last
    // last will be repeated as needed.
    getDateSpan(startTimestamp, endTimestamp, increment = 'month', maxCount = 1000000)
    {
        const cursor = this._toMoment(startTimestamp);
       
        const baseDay = cursor.date();
        const ret = [];
        
        let count = 0;
        
        if (increment === 'eon')
            maxCount = 1;
        else
            maxCount = maxCount || 1000000;
    
        let incrementArray;
        if (Array.isArray(increment))
        {
            incrementArray = increment;
            increment = 'arrayDays';
        }
        let i = 0;
        while (cursor.valueOf() < endTimestamp)
        {
            ret.push(cursor.valueOf());
            switch (increment)
            {
                case 'eon':
                    break;
                case '30day':
                    cursor.add(30, 'days');
                    break;
                case 'month':
                    this._incrementMomentByMonth(cursor, baseDay);
                    break;
                case 'quarter':
                    this._incrementMomentByMonth(cursor, baseDay, 3);
                    break;
                case 'semiannually':
                    this._incrementMomentByMonth(cursor, baseDay, 6);
                    break;
                case 'year':
                    cursor.add(1, 'years');
                    break;
                case 'week':
                    cursor.add(7, 'days');
                    break;
                case '2week':
                    cursor.add(14, 'days');
                    break;
                case 'arrayDays':
                    if (i < incrementArray.length)
                        cursor.add(incrementArray[i++], 'days');
                    else
                        cursor.add(incrementArray[incrementArray.length - 1], 'days');
                    break;
                default:
                    throw `Span increment '${increment}' not supported!`;
            }
            if (++count >= maxCount)
                break;
        } 
        return ret;
    }
    addToTimestamp(timestamp, count, increment = 'days')
    {
        return this._toMoment(timestamp).add(count, increment)
                                        .valueOf();
    }
    getEndOfDayTimestamp(timestamp)
    {
        return this._toMoment(timestamp).endOf('day')
                                        .valueOf();
    }
    dayCount(startTimestamp, endTimestamp)
    {
        const startM = this._toMoment(startTimestamp);
        const endM = this._toMoment(endTimestamp);

        return endM.diff(startM, 'days', true);
    }
    dayCountRatio(startTimestamp, splitTimestamp, endTimestamp, clampZeroToOne = true)
    {
        if (startTimestamp >= endTimestamp)
            throw "Day Count Ratio: Denominator cannot be zero or negative.";

        if (splitTimestamp > endTimestamp)
            throw "Day Count Ratio: Split cannot be after end.";
        
        if (splitTimestamp <= startTimestamp)
            return 0;

        const startM = this._toMoment(startTimestamp);
        const splitM = this._toMoment(splitTimestamp);
        const endM = this._toMoment(endTimestamp);

        let result = splitM.diff(startM, 'days', true) /
                     endM.diff(startM, 'days', true);
    
        if (clampZeroToOne)
            result = Math.max(0, Math.min(1, result));

        return result;
    }
    linearRatio(startTimestamp, splitTimestamp, endTimestamp, clampZeroToOne = true)
    {
        if (startTimestamp >= endTimestamp)
            throw "Linear Ratio: Denominator cannot be zero or negative.";
        
        if (splitTimestamp > endTimestamp)
            throw "Linear Ratio: Split cannot be after end.";
        
        if (splitTimestamp <= startTimestamp)
            return 0;

        let result = (splitTimestamp - startTimestamp) / (endTimestamp - startTimestamp);

        if (clampZeroToOne)
            result = Math.max(0, Math.min(1, result));

        return result;
    }
    incrementMonth(startTimestamp, numMonths = 1)
    {
        return this._toMoment(startTimestamp).add(numMonths, 'months').valueOf();
    }
    monthCount(startTimestamp, endTimestamp, baseTimestamp = null)
    {
        const curM = this._toMoment(startTimestamp);
       
        if (baseTimestamp)
            startDayOfMonth = this._toMoment(baseTimestamp).date();
        else
            startDayOfMonth = curM.date();

        if (startDayOfMonth < 29)
            startDayOfMonth = null;

        let count = 0;
        while (curM.valueOf < endTimestamp)
        {
            const nextM = this._incrementMomentByMonth(curM.clone(), startDayOfMonth, 1);

            if (nextM.valueOf() > endTimestamp)
                count += (endTimestamp - curM.valueOf()) / (next.valueOf() - curM.valueOf());
            else
                count++;
            curM = nextM;
        }
        return count;
    }
    /* Intended to dupicate the Socotra platform month count algorithm */
    socotraMonthCount(startTimestamp, endTimestamp, baseTimestamp = null)
    {
        baseTimestamp = baseTimestamp || startTimestamp;

        const startM = this._toMoment(startTimestamp);
        const endM = this._toMoment(endTimestamp);
        const baseM = this._toMoment(baseTimestamp);

        const startDate = startM.date();
        const endDate = endM.date();

        // Simple case
        if ((baseTimestamp <= startTimestamp) && (startTimestamp < endTimestamp) && (startDate === endDate) && (startM.hour() === endM.hour()) && ((startTimestamp % 3600000) === (endTimestamp % 3600000)))
        {
            const differenceInYears = endM.year() - startM.year();
            const differenceInMonths = endM.month() - startM.month();
            return differenceInMonths + differenceInYears * 12;
        }
    
        // Normal case
        const baseDate = baseM.date();

        let monthCount = 0;
        let prevMonth = startM.clone();
        let monthCursor = this._socotraIncrementMomentByMonth(startM, baseDate);
        
        while (monthCursor.valueOf() < endTimestamp)
        {
            prevMonth = monthCursor;
            monthCursor = this._socotraIncrementMomentByMonth(monthCursor, baseDate);
            monthCount += 1;
            if (monthCursor.date() !== startDate)
            {
                const daysInMonth = monthCursor.daysInMonth();
                if (baseDate >= daysInMonth) // special case for policies that started on 29/30/31
                {
                    monthCursor.set('date', daysInMonth);
                }
                else
                {
                    monthCursor.set('date', Math.min(startDate, daysInMonth));
                }
            }
        }
        const prevMonthVal = prevMonth.valueOf();
        if (prevMonthVal === endTimestamp)
        {
            return monthCount;
        }
        else
        {
            const remainder = endTimestamp - prevMonthVal;
            const totalNextMonthMillis = monthCursor.valueOf() - prevMonthVal;
            return this._round7(monthCount + remainder / totalNextMonthMillis);
        } 
    }
    /* Computes the ratio of the pre-split numMonths to overall months */
    socotraMonthCountRatio(startTimestamp, splitTimestamp, endTimestamp, clampZeroToOne)
    {
        if (startTimestamp >= endTimestamp)
        throw "Month Count Ratio: Denominator cannot be zero or negative.";
    
        if (splitTimestamp > endTimestamp)
            throw "Month Count Ratio: Split cannot be after end.";
        
        if (splitTimestamp <= startTimestamp)
            return 0;

        let result = this.socotraMonthCount(startTimestamp, splitTimestamp) /
                     this.socotraMonthCount(startTimestamp, endTimestamp);

        if (clampZeroToOne)
            result = Math.max(0, Math.min(1, result));

        return result;
    }
    /* mutates startM */
    _incrementMomentByMonth(startM, anchorToDayOfMonth = null, numMonths = 1)
    {
        startM.add(numMonths, 'months');
        if (anchorToDayOfMonth)
        {
            if (startM.date() < anchorToDayOfMonth)
                startM.set('date', Math.min(startM.daysInMonth(), anchorToDayOfMonth));
            else if (startM.date() > anchorToDayOfMonth)
                startM.set('date', anchorToDayOfMonth);
        }
        return startM;
    }
    /* does not mutate startM */
    _socotraIncrementMomentByMonth(startM, baseDate)
    {
        const startDate = startM.date();
        const startDaysInMonth = startM.daysInMonth();
        const nextMonth = startM.clone().add(1, 'months');
        const startDomBeforeBaseDom = startDate < baseDate;
        const nextMonthBeforeBaseDom = nextMonth.date() < baseDate;
        if (startDate === startDaysInMonth && startDomBeforeBaseDom && nextMonthBeforeBaseDom)
        {
            return nextMonth.set('date', Math.min(nextMonth.daysInMonth(), baseDate));
        }
        else
        {
            return nextMonth;
        }
    }
    _round7(amount)
    {
        return Math.round(amount * 10000000.0) / 10000000.0;
    }
    _toMoment(timestamp)
    {
        return moment(timestamp).tz(this._timeZone);
    }
}
exports.DateCalc = DateCalc;