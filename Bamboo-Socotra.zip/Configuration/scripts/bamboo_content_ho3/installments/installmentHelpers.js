let arrays = require("../libraries/arrays.js");
let dates = require('../libraries/dates.js');
let installmentConstants = require("../constants/constants.js");
let moment = require("../libraries/moment-with-locales.js");

function getMonthlyDownPayment(charge) {
    arrays.polyfill();
    let fraction = 0;
    if (charge.type == installmentConstants.feeConstants.fee || charge.type == installmentConstants.feeConstants.tax) {
        let amount = parseFloat(charge.amount);
        return amount;
    } 
    else {
        let amount = parseFloat(charge.amount);
        fraction = round2(0.1667 * amount);
        return fraction;
    }
}

function getQuarterlyDownPayment(charge) {
    let fraction = 0;
    if (charge.type == installmentConstants.feeConstants.fee || charge.type == installmentConstants.feeConstants.tax) {
        let amount = parseFloat(charge.amount);
        return amount;
    }
    else {
        let amount = parseFloat(charge.amount);
        fraction = round2(0.35 * amount);
        return fraction;
    }
}

function getMonthlyInstallment(charge) {
    let fraction = 0;
    if (charge.type == installmentConstants.feeConstants.fee || charge.type == installmentConstants.feeConstants.tax) {
        let amount = 0;
        return amount;
    } 
    else {
        let amount = parseFloat(charge.amount);
        fraction = round2(0.0758 * amount);
        return fraction;
    }
}

function getQuarterlyInstallment(charge) {
    let fraction = 0;
    if (charge.type == installmentConstants.feeConstants.fee || charge.type == installmentConstants.feeConstants.tax) {
        let amount = 0;
        return amount;
    } 
    else {
        let amount = parseFloat(charge.amount);
        fraction = round2(0.2167 * amount);
        return fraction;
    }
}


function getProratedPremium(data, charge, unprorated_amount, increment, maxInstallments) {
    let nowTimestamp = new Date().getTime();

    let startTimestamp = data.charges.min(c => parseInt(data.policy.originalContractStartTimestamp));
    let endTimestamp = data.charges.max(c => parseInt(data.policy.effectiveContractEndTimestamp));

    let startMoment = dates.fromTimestamp(startTimestamp, data.tenantTimeZone);
    let endMoment = dates.fromTimestamp(endTimestamp, data.tenantTimeZone);

    let installmentTimestamps = dates.span(startMoment, endMoment, increment)
        .map(m => dates.getTimestamp(m));

    if (installmentTimestamps.length == 0)
        installmentTimestamps = [nowTimestamp];
    else if (installmentTimestamps.length > maxInstallments)
        installmentTimestamps = installmentTimestamps.slice(0, maxInstallments);
    let timestamps = [];
    for (let i = 0; i < installmentTimestamps.length; i++) {
        let installmentTimestamp = installmentTimestamps[i];
        timestamps.push({
            startTimestamp: installmentTimestamp,
            endTimestamp: i < installmentTimestamps.length - 1 ? installmentTimestamps[i + 1] : endTimestamp
        });
    }
    let endorsementStartTime = data.coverageStartTimestamp;
    endorsementStartTime = new Date(+endorsementStartTime);
    endorsementStartTime = moment(endorsementStartTime).format(installmentConstants.dateFormat.year_month_date);
    let endorsementEndTime = new Date(+endTimestamp);
    endorsementEndTime = moment(endorsementEndTime).format(installmentConstants.dateFormat.year_month_date);
    let endorsement_days = moment(new Date(endorsementEndTime)).diff(new Date(endorsementStartTime), 'days', true);
    let unearned_installment_days;
    let down_payment;
    for (let i = 0; i < timestamps.length; i++) {
        if ((timestamps[i].startTimestamp <= data.coverageStartTimestamp) &&
            (data.coverageStartTimestamp < timestamps[i].endTimestamp)) {
            endors_length = i;
            let end = timestamps[i].endTimestamp;
            end = new Date(+end);
            end = moment(end).format(installmentConstants.dateFormat.year_month_date);
            unearned_installment_days = moment(new Date(end)).diff(new Date(endorsementStartTime), 'days', true);
            break;
        }
    }
}

function getEndorsementDays(coverageStartTimestamp, endTimestamp) {
    let endorsementStartTime = coverageStartTimestamp;
    endorsementStartTime = new Date(+endorsementStartTime);
    endorsementStartTime = moment(endorsementStartTime).format(installmentConstants.dateFormat.year_month_date);
    let endorsementEndTime = new Date(+endTimestamp);
    endorsementEndTime = moment(endorsementEndTime).format(installmentConstants.dateFormat.year_month_date);
    let endorsement_days = moment(new Date(endorsementEndTime)).diff(new Date(endorsementStartTime), 'days', true);
    return endorsement_days;
}

function getProratedDays(endorsementStartTimeStamp, installments) {
    let prorated_days;
    for (i = 0; i < installments.length; i++) {
        if ((installments[i].startTimestamp <= endorsementStartTimeStamp) && (endorsementStartTimeStamp < installments[i].endTimestamp)) {
            let startTimeStamp = endorsementStartTimeStamp;
            startTimeStamp = new Date(+startTimeStamp);
            startTimeStamp = moment(startTimeStamp).format(installmentConstants.dateFormat.year_month_date);
            let endTimeStamp = installments[i].endTimestamp;
            endTimeStamp = new Date(+endTimeStamp);
            endTimeStamp = moment(endTimeStamp).format(installmentConstants.dateFormat.year_month_date);
            prorated_days = moment(new Date(endTimeStamp)).diff(new Date(startTimeStamp), 'days', true);
            break;
        }
    }
    return prorated_days;
}

function getLengthOfInstallments(installmentTimestamps, endorsementStartTimeStamp, endTimestamp) {
    let length;
    for (i = 0; i < installmentTimestamps.length; i++) {
        if ((installmentTimestamps[i] <= endorsementStartTimeStamp) &&
            (endorsementStartTimeStamp < installmentTimestamps[i + 1])) {
            length = installmentTimestamps.length - i;
        } else if (i == installmentTimestamps.length - 1) {
            if ((installmentTimestamps[i] <= endorsementStartTimeStamp) &&
                (endorsementStartTimeStamp < endTimestamp)) {
                length = installmentTimestamps.length - i;
            }
        }
    }
    return length;
}

function getEndorsementInstallment(down_payment, unprorated_amount, charge, length) {
    let remaining_amount = 0;
    let total_change_amount = parseFloat(charge.amount);
    let prorated_amount;
    if (unprorated_amount < 0) {
        prorated_amount = (unprorated_amount) - (total_change_amount)
    } else {
        prorated_amount = (total_change_amount) - (unprorated_amount);
    }
    remaining_amount = prorated_amount - down_payment;
    remaining_amount = round2(remaining_amount / (length - 1));
    return remaining_amount;
}

function identifyChargeOfEndPeril(endorsementStartTimeStamp, charges, charge, policyEffectiveTimeStamp) {
    let policyEffectiveDate = convertTimestampToDate(policyEffectiveTimeStamp)
    let endorsementDate = convertTimestampToDate(endorsementStartTimeStamp)
    let count = 0;
    let chargesArray = [];
    let chargeAmountsArray = [];
    for (ch of charges) {
        if ((ch.type == charge.type) && (ch.perilLocator == charge.perilLocator)) {
            count++;
            chargesArray.push(JSON.parse(ch.coverageStartTimestamp));
            chargeAmountsArray.push(JSON.parse(ch.amount));
        }
    }
    if ((!(chargesArray.indexOf(JSON.parse(endorsementStartTimeStamp)) > -1)) && (endorsementDate != policyEffectiveDate)) {
        charge.isEnded = true;
    } else if ((endorsementDate == policyEffectiveDate) && (chargeAmountsArray.indexOf(0) > -1)) {
        charge.isEnded = true;
    } else {
        charge.isEnded = false;
    }
    return charge;
}

function getProratdPremiumForRN(charge, cancellationEffectiveDate, nbStartTimeStamp, paymentScheduleName, installments) {
    let reinstatementPremium = charge.amount;
    let rnDays = getDays(charge.coverageStartTimestamp, charge.coverageEndTimestamp);
    let rnPerDayPremium = reinstatementPremium / rnDays;
    let nbDays = getDays(nbStartTimeStamp, charge.coverageEndTimestamp);
    let nbGrossPremium = round2(rnPerDayPremium * nbDays);
    let downPayment;
    let installment = 0;
    if (paymentScheduleName == installmentConstants.paymentScheduleConstants.quarterly) {
        downPayment = round2(nbGrossPremium * 0.35);
    } else if (paymentScheduleName == installmentConstants.paymentScheduleConstants.monthly) {
        downPayment = round2(nbGrossPremium * 0.1667);
    }
    let CnDays = getDays(nbStartTimeStamp, cancellationEffectiveDate);
    let cnEarnedPremium = round2(nbGrossPremium * (CnDays / nbDays))
    if (downPayment > cnEarnedPremium) {
        reinstatementPremium = (downPayment - cnEarnedPremium);
    } else {
            rnRemainingPremium = nbGrossPremium - cnEarnedPremium;
            let reinstatementEffectiveTimeStamp = charge.coverageStartTimestamp;
            let proratedDays = getProratedDays(reinstatementEffectiveTimeStamp, installments);
            reinstatementPremium = round2(rnRemainingPremium * proratedDays / rnDays);
            installment = round2((rnRemainingPremium - reinstatementPremium) / (installments.length - 1))
    }
    return {
        reinstatementPremium,
        installment
    };
}

function getDays(startTimeStamp, EndTimeStamp) {
    let policyStartTimeStamp = startTimeStamp;
    policyStartTimeStamp = new Date(+policyStartTimeStamp);
    let policyEndTimeStamp = EndTimeStamp;
    policyEndTimeStamp = new Date(+policyEndTimeStamp);
    let StartDate = moment(policyStartTimeStamp).format(installmentConstants.dateFormat.year_month_date);
    let EndDate = moment(policyEndTimeStamp).format(installmentConstants.dateFormat.year_month_date);
    let daysDiff = moment(new Date(EndDate)).diff(new Date(StartDate), 'days', true);
    return daysDiff;
}

function convertTimestampToDate(Timestamp) {
    let convertedDate = new Date(+Timestamp);
    convertedDate = moment(convertedDate).format(installmentConstants.dateFormat.year_month_date);
    return convertedDate;
}

function round2(amount) {
    return Math.round(amount * 100.0) / 100.0;
}

exports.getMonthlyDownPayment = getMonthlyDownPayment;
exports.getQuarterlyDownPayment = getQuarterlyDownPayment;
exports.getQuarterlyInstallment = getQuarterlyInstallment;
exports.getMonthlyInstallment = getMonthlyInstallment;
exports.getEndorsementInstallment = getEndorsementInstallment;
exports.getProratedPremium = getProratedPremium;
exports.getEndorsementDays = getEndorsementDays;
exports.getProratedDays = getProratedDays;
exports.round2 = round2;
exports.getLengthOfInstallments = getLengthOfInstallments;
exports.identifyChargeOfEndPeril = identifyChargeOfEndPeril;
exports.getProratdPremiumForRN = getProratdPremiumForRN;