// For flat() and flatMap() see https://github.com/jonathantneal/array-flat-polyfill
if (!Array.prototype.flat)
{
  Object.defineProperty(Array.prototype, 'flat', {
    configurable: true,
    value: function flat() {
      let depth = isNaN(arguments[0]) ? 1 : Number(arguments[0]); 
      return depth ? Array.prototype.reduce.call(this, function (acc, cur) {
        if (Array.isArray(cur))
          acc.push.apply(acc, flat.call(cur, depth - 1));
        else
          acc.push(cur);
        return acc;
      }, []) : Array.prototype.slice.call(this);
    },
    writable: true
  });
}
if (!Array.prototype.flatMap)
{
  Object.defineProperty(Array.prototype, 'flatMap', {
    configurable: true,
    value: function flatMap (mapFn) {
      return Array.prototype.map.apply(this, arguments).flat();
    },
    writable: true
  });
}
if (!Array.prototype.selectMany)
{
  Object.defineProperty(Array.prototype, 'selectMany', {
    configurable: true,
    value: function selectMany (valFn = x => x) {
      return this.flat().map(x => valFn(x));
    },
    writable: true
  });
}
if (!Array.prototype.toMap)
{
  Object.defineProperty(Array.prototype, 'toMap', {
    configurable: true,
    value: function toMap (keyFn, valFn = x => x) {
      return new Map(this.map(obj => [keyFn(obj), valFn(obj)]));
    },
    writable: true
  });
}
/* orderBy and orderByDescending should work with nums and strings for comparators */
if (!Array.prototype.orderBy)
{
  Object.defineProperty(Array.prototype, 'orderBy', {
    configurable: true,
    value: function orderBy (sortKeyFn = x => x) {
      return [...this].sort((a, b) => { let x = sortKeyFn(a); let y = sortKeyFn(b); return x > y ? 1 : x < y ? -1 : 0; });
    },
    writable: true
  });
}
if (!Array.prototype.orderByDescending)
{
  Object.defineProperty(Array.prototype, 'orderByDescending', {
    configurable: true,
    value: function orderByDescending (sortKeyFn = x => x) {
      return [...this].sort((a, b) => { let x = sortKeyFn(a); let y = sortKeyFn(b); return x > y ? -1 : x < y ? 1 : 0; });
    },
    writable: true
  });
}
if (!Array.prototype.groupBy)
{
  Object.defineProperty(Array.prototype, 'groupBy', {
    configurable: true,
    value: function groupBy(keyFn, valFn = x => x) {
      return Array.prototype.reduce.call(this, function (map, item) {
        let key = keyFn(item);
        if (map.has(key))
          map.get(key).push(valFn(item));
        else
          map.set(key, [valFn(item)]);
        return map;
      }, new Map());
    }
  });
}
if (!Array.prototype.sum)
{
  Object.defineProperty(Array.prototype, 'sum', {
    configurable: true,
    value: function sum(valFn = x => x) {
      return this.reduce((sum, x) => sum + valFn(x), 0);
    }
  });
}
if (!Array.prototype.first)
{
  Object.defineProperty(Array.prototype, 'first', {
    configurable: true,
    value: function first(valFn = x => true) {
      for (let x of this)
        if (valFn(x))
          return x;
      return null;
    }
  });
}
if (!Array.prototype.last)
{
  Object.defineProperty(Array.prototype, 'last', {
    configurable: true,
    value: function last(valFn = x => true) {
      for (let i = this.length - 1; i >= 0; i--)
        if (valFn(this[i]))
          return this[i];
      return null;
    }
  });
}
if (!Array.prototype.min)
{
  Object.defineProperty(Array.prototype, 'min', {
    configurable: true,
    value: function min(valFn = x => x) {
      return this.reduce((min, x) => Math.min(valFn(x), min), Infinity);
    }
  });
}
if (!Array.prototype.max)
{
  Object.defineProperty(Array.prototype, 'max', {
    configurable: true,
    value: function max(valFn = x => x) {
      return this.reduce((max, x) => Math.max(valFn(x), max), -Infinity)
    }
  });
}
if (!Array.prototype.distinct)
{
  Object.defineProperty(Array.prototype, 'distinct', {
    configurable: true,
    value: function distinct(valFn = x => x) {
      let vals = this.map(x => valFn(x));
      return this.filter((val, idx) => vals.indexOf(valFn(val)) === idx);
    }
  });
}
if (!Array.prototype.findLastIndex)
{
  Object.defineProperty(Array.prototype, 'findLastIndex', {
    configurable: true,
    value: function findLastIndex(valFn = x => true) {
      let i = this.length;
      while (i--)
      {
        if (valFn(this[i]))
          return i;
      }
      return -1;
    }
  });
}
if (!Array.prototype.count)
{
  Object.defineProperty(Array.prototype, 'count', {
    configurable: true,
    value: function count(valFn = x => true) {
      return this.filter(valFn).length;
    }
  });
}
if (!Array.prototype.count)
{
  Object.defineProperty(Array.prototype, 'count', {
    configurable: true,
    value: function count(evalFn) {
      return (evalFn == null) ? this.length : this.filter(evalFn).length;
    }
  });
}