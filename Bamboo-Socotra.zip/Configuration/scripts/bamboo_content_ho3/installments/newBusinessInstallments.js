let arrays = require("../libraries/arrays.js");
let dates = require('../libraries/dates.js');
let installmentConstants = require("../constants/constants.js");
let helpers = require("./installmentHelpers.js");
const
{
  addDays
} = require("../underwriting/helpersUW.js");

function createNewBusinessInstallments(data, installments)
{

  arrays.polyfill();
  let billTo = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues.bill_to;
  let paymentScheduleName;
  if(billTo == "Mortgagee" && data.paymentScheduleName == installmentConstants.paymentScheduleConstants.full_pay)
  paymentScheduleName = installmentConstants.paymentScheduleConstants.mortgage;
  else
  paymentScheduleName = data.paymentScheduleName;

  console.log("🚀 ~ file: newBusinessInstallments.js ~ line 23 ~ paymentScheduleName", paymentScheduleName)
  switch (paymentScheduleName)
  {
    case installmentConstants.paymentScheduleConstants.full_pay:
      installments = getUpfront(data);
      break;
    case installmentConstants.paymentScheduleConstants.mortgage:
      installments = getUpfrontMortgage(data);
      break;
    case installmentConstants.paymentScheduleConstants.quarterly:
      installments = getInstallments(data, installmentConstants.termConstants.ninty_days, installmentConstants.numberConstants.four);
      break;
    case installmentConstants.paymentScheduleConstants.monthly:
      installments = getInstallments(data, installmentConstants.termConstants.thirty_days, installmentConstants.numberConstants.twelve);
      break;
    default:
      throw installmentConstants.termConstants.exception;
  }
  return installments;
}

function getUpfront(data)
{
  let invoiceItems = data.charges.map(ch => (
  {
    amount: ch.amount,
    chargeId: ch.chargeId
  }));

  let duetimestamp = data.coverageStartTimestamp;
  duetimestamp = new Date(+duetimestamp);
  let setdueTimestamp = addDays(duetimestamp, 10);
  setdueTimestamp = new Date(setdueTimestamp).getTime();

  return [
  {
    dueTimestamp: setdueTimestamp,
    issueTimestamp: data.coverageStartTimestamp,
    startTimestamp: data.coverageStartTimestamp,
    endTimestamp: data.coverageEndTimestamp,
    invoiceItems: invoiceItems,
    writeOff: false
  }];
}

function getUpfrontMortgage(data)
{
  let invoiceItems = data.charges.map(ch => (
  {
    amount: ch.amount,
    chargeId: ch.chargeId
  }));

  let duetimestamp = data.coverageStartTimestamp;
  duetimestamp = new Date(+duetimestamp);
  let setdueTimestamp = addDays(duetimestamp, 30);
  setdueTimestamp = new Date(setdueTimestamp).getTime();

  return [
  {
    dueTimestamp: setdueTimestamp,
    issueTimestamp: data.coverageStartTimestamp,
    startTimestamp: data.coverageStartTimestamp,
    endTimestamp: data.coverageEndTimestamp,
    invoiceItems: invoiceItems,
    writeOff: false
  }];
}

function getInstallments(data, increment, maxInstallments)
{
  let nowTimestamp = new Date().getTime();
  let startTimestamp = data.charges.min(c => parseInt(data.coverageStartTimestamp));
  let endTimestamp = data.charges.max(c => parseInt(data.coverageEndTimestamp));

  let startMoment = dates.fromTimestamp(startTimestamp, data.tenantTimeZone);
  let endMoment = dates.fromTimestamp(endTimestamp, data.tenantTimeZone);

  let installmentTimestamps = dates.span(startMoment, endMoment, increment)
    .map(m => dates.getTimestamp(m));



  if (installmentTimestamps.length == 0)
  {
    installmentTimestamps = [nowTimestamp];
  }
  else if (installmentTimestamps.length > maxInstallments)
  {
    installmentTimestamps = installmentTimestamps.slice(0, maxInstallments);
  }
  let installments = [];
  let setissuetimestamp;
  let setdueTimestamp;
  for (let i = 0; i < installmentTimestamps.length; i++)
  {
    let installmentTimestamp = installmentTimestamps[i];
    if (i == 0)
    {
      setissuetimestamp = installmentTimestamp;
      setdueTimestamp = new Date(+setissuetimestamp);
      setdueTimestamp = addDays(setdueTimestamp, 10);
      setdueTimestamp = new Date(setdueTimestamp).getTime();
    }
  else
    {
      setissuetimestamp = installmentTimestamp//addDays(installmentTimestamp, -20);
      setdueTimestamp = installmentTimestamp
    }
    setissuetimestamp = new Date(setissuetimestamp).getTime();
    installments.push(
    {
      invoiceItems: [],
      dueTimestamp: setdueTimestamp,
      startTimestamp: installmentTimestamp,
      issueTimestamp: setissuetimestamp,
      endTimestamp: i < installmentTimestamps.length - 1 ? installmentTimestamps[i + 1] : endTimestamp,
      writeOff: false
    });
  }

  for (charge of data.charges)
  {
    let newItems = [];
    for (let i = 0; i < installments.length; i++)
    {
      if (charge.coverageStartTimestamp <= installments[i].dueTimestamp &&
        charge.coverageEndTimestamp >= installments[i].dueTimestamp)
      {
        let newItem = {
          chargeId: charge.chargeId
        };
        newItems.push(newItem);
        installments[i].invoiceItems.push(newItem);
      }
    }

    if (newItems.length == 0)
    {
      // No installments fell within the charge coverage time, so find one
      let item = {
        chargeId: charge.chargeId,
        amount: parseFloat(charge.amount)
      };
      let inst;
      for (let i = 0; i < installments.length; i++)
        if (installments[i].dueTimestamp <= charge.coverageStartTimestamp)
        {
          inst = installments[i];
          break;
        }
      if (inst === undefined)
        inst = installments[0];
      inst.invoiceItems.push(item);
    }
    else
    {
      let amount = parseFloat(charge.amount);
      let down_payment;
      let installment;
      if(maxInstallments == installmentConstants.numberConstants.four)
      {
       down_payment = helpers.getQuarterlyDownPayment(charge);
       installment = helpers.getQuarterlyInstallment(charge);
      }
      else
      {
        down_payment = helpers.getMonthlyDownPayment(charge);
        installment = helpers.getMonthlyInstallment(charge);
      }
      for (let i = 0; i < newItems.length; i++)
      {
        if (i == 0)
          newItems[i].amount = down_payment;
        else if (i > 0 && i < newItems.length - 1)
          newItems[i].amount = installment;
        else
          newItems[i].amount = helpers.round2(amount - newItems.slice(0, newItems.length - 1).sum(ni => ni.amount));

      }
    }
  }

  if(data.operation == installmentConstants.operationConstants.new_business ||
    data.operation == installmentConstants.operationConstants.renewal)
  {
    let installmentFees;
    let paymentMode = data.policy.characteristics.last().fieldValues.payment_mode;
    console.log("🚀 ~ file: newBusinessInstallments.js ~ line 181 ~ paymentMode", paymentMode)
    if (paymentMode === undefined)
        paymentMode = null;
    else 
        paymentMode = paymentMode.last();
        installmentFees = [];
    for (let i = 1; i < installments.length; i++)
    {
      if (paymentMode === "Automatic" && (data.productName === "HO-5" ))
      {
        console.log("line 340");
        installments[i].installmentFees = [{
          feeName: installmentConstants.feeConstants.installment_fee_cards_ach,
          description: "Installment Fee- Automatic payment via cards, ACH",
          amount: 3
         }];
         console.log(JSON.stringify(installmentFees));
      }
      else
      {
        console.log("line 349");
        installments[i].installmentFees = [{
          feeName: installmentConstants.feeConstants.installment_fee_other,
          description: "Installment Fee- Other than Automatic payments",
          amount: 10
        }];
      }
    }
  }

  return installments.filter(inst => inst.invoiceItems.length > 0);
}

exports.createNewBusinessInstallments = createNewBusinessInstallments;
exports.getUpfront = getUpfront;
exports.getUpfrontMortgage = getUpfrontMortgage;