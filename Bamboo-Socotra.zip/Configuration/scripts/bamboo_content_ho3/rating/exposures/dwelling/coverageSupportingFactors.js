"use strict";

let moment = require('../../../libraries/moment-with-locales.js');
let ratingHelpers = require('../../helpersRating.js');
let ratingConstants = require('../../ratingConstants.js')
let ratingCalculations = require('../../ratingCalculations.js')
ratingHelpers.roundToDecimalPlaces();


function getFactorsForPremium(data)
{

let exposures = data.policy.exposures;
let perils = exposures.flatMap((ex) => ex.perils);
let exposure = exposures.find((e) => e.name == ratingConstants.exposureFieldValueConstants.dwelling);
let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
let state = exposure_fv.property_state;
let policyExposurePerils = data.policyExposurePerils;
let otherPerilLimits = ratingHelpers.getOtherPerilLimits(policyExposurePerils,perils);

let territory_code;
let payment_history_value = ratingConstants.numberConstants.zero;
let prior_reins = ratingConstants.numberConstants.zero;
let chargeable_claims = ratingConstants.numberConstants.zero;
let years_with_company = ratingConstants.numberConstants.zero;
let nb_homebuyer_factor = ratingConstants.numberConstants.one;
let exp_claims_factor = ratingConstants.numberConstants.one;
let prior_claims_factor = ratingConstants.numberConstants.one;
let city_code = socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.city_code_table),exposure_fv.property_city);
console.log("🚀 ~ file: coverageSupportingFactors.js ~ line 27 ~ city_code", city_code)
let county_code = socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.county_code_table),exposure_fv.property_county);
console.log("🚀 ~ file: coverageSupportingFactors.js ~ line 28 ~ county_code", county_code)
let terr_code_on_zip_code_key = city_code + ratingConstants.tableKeyConstants.pipe + exposure_fv.property_zipcode;
let terr_code_on_zip_code = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.terr_code_on_zip_code_table),terr_code_on_zip_code_key));
console.log("🚀 ~ file: coverageSupportingFactors.js ~ line 30 ~ terr_code_on_zip_code", terr_code_on_zip_code)
  if(city_code == "" || city_code == null)
  {
     territory_code = county_code;
  }
  else if(Number.isInteger(city_code))
  {
     territory_code = city_code;
  }
  else
  {
      territory_code = terr_code_on_zip_code;
  }
let form_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.form_factor_table),policy_fv.form));
let num_of_families_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.number_of_families_factor_table),exposure_fv.no_of_families));
let ext_replacement_cost = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.erc_Table),otherPerilLimits.extended_rcv));
console.log("🚀 ~ file: coverageSupportingFactors.js ~ line 52 ~ ext_replacement_cost", ext_replacement_cost)
ext_replacement_cost = !isNaN(ext_replacement_cost) ? ext_replacement_cost : ratingConstants.numberConstants.one;
let opening_protection_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.opening_protection_factor_table),exposure_fv.opening_protection));
opening_protection_factor = !isNaN(opening_protection_factor) ? opening_protection_factor : ratingConstants.numberConstants.one;
let roof_deck_attachment_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.roof_deck_attachment_factor_table),exposure_fv.roof_deck_attachment));
roof_deck_attachment_factor = !isNaN(roof_deck_attachment_factor) ? roof_deck_attachment_factor : ratingConstants.numberConstants.one;
let roof_to_wall_connection_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.roof_to_wall_connection_factor_table),exposure_fv.roof_to_wall_attachment));
roof_to_wall_connection_factor = !isNaN(roof_to_wall_connection_factor) ? roof_to_wall_connection_factor : ratingConstants.numberConstants.one;
if(roof_deck_attachment_factor < ratingConstants.numberConstants.one && roof_to_wall_connection_factor < ratingConstants.numberConstants.one)
{
   socotraApi.setAuxData("RoofCoveringCreditsAreApplied","flag","Yes","normal");
}
else
{
   socotraApi.setAuxData("RoofCoveringCreditsAreApplied","flag","No","normal");
}
let secondary_water_resistance_factor =  parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.secondary_water_resistance_factor_table),exposure_fv.secondary_water_resistance));
secondary_water_resistance_factor = !isNaN(secondary_water_resistance_factor) ? secondary_water_resistance_factor : ratingConstants.numberConstants.one;
let reinforced_exterior_doors_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.reinforced_exterior_doors_factor_table),exposure_fv.reinforced_exterior_doors));
reinforced_exterior_doors_factor = !isNaN(reinforced_exterior_doors_factor) ? reinforced_exterior_doors_factor : ratingConstants.numberConstants.one;
let fortified_construction_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.fortified_construction_factor_table),exposure_fv.fortified_construction));
fortified_construction_factor = !isNaN(fortified_construction_factor) ? fortified_construction_factor : ratingConstants.numberConstants.one;
let policy_start_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;
if(policy_fv.loss_history != undefined)
{
    for (let each_claim of policy_fv.loss_history)
    {
      let claim_date = policy_fgv[each_claim].claim_date;
      let claim_amount = parseInt(policy_fgv[each_claim].loss_amount)
      let loss_status = policy_fgv[each_claim].loss_status;
      let effective_date = new Date(+policy_start_timestamp);
      let subrogation = policy_fgv[each_claim].subrogation;
      let cat_code =socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.col_cat_mapping_table),policy_fgv[each_claim].cause_of_loss)
      console.log("🚀 ~ file: coverageSupportingFactors.js ~ line 81 ~ cat_code", cat_code)
      let cat_code_flag = socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.Iso_cat_codes_table),cat_code);
      console.log("🚀 ~ file: coverageSupportingFactors.js ~ line 81 ~ cat_code_flag", cat_code_flag)
      effective_date = moment(effective_date.setFullYear(effective_date.getFullYear()-3)).format("YYYY-MM-DD");
      if(loss_status == ratingConstants.claimStatusConstants.closed && claim_amount > ratingConstants.numberConstants.five_hundred && (ratingHelpers.dates.compare(claim_date,effective_date) == ratingConstants.numberConstants.one || ratingHelpers.dates.compare(claim_date,effective_date) == ratingConstants.numberConstants.zero) && subrogation == ratingConstants.binaryConstants.no && cat_code_flag != ratingConstants.binaryConstants.yes)
       {
          chargeable_claims += 1;
       }
    }
    chargeable_claims = (chargeable_claims >= ratingConstants.numberConstants.two) ? ratingConstants.tableKeyConstants.greater_than_equal_two : chargeable_claims;
   }
   if(policy_fv.prior_policy_history != undefined)
   {
    years_with_company = policy_fgv[policy_fv.prior_policy_history[policy_fv.prior_policy_history.length - 1]].years_with_company;
    years_with_company = (years_with_company > ratingConstants.numberConstants.three) ? ratingConstants.tableKeyConstants.greater_than_equal_four : years_with_company;
    prior_claims_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.prior_claims_factor_table),chargeable_claims + ratingConstants.tableKeyConstants.pipe + years_with_company));
    exp_claims_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.exp_claims_factor_table),chargeable_claims + ratingConstants.tableKeyConstants.pipe + years_with_company));
    for (let each_policy of policy_fv.prior_policy_history)
    {
       if(policy_fgv[each_policy].late_payment == ratingConstants.binaryConstants.yes) 
       {
            payment_history_value += 1;
         } 
      }
      if(policy_fv.prior_policy_history != undefined)
      {
        for(let each_policy of policy_fv.prior_policy_history)
        {
         if(policy_fgv[each_policy].reinstatement == ratingConstants.binaryConstants.yes) 
         {
          prior_reins += 1;
         }
        }
      }
   }
      payment_history_value = (payment_history_value > prior_reins) ? payment_history_value : prior_reins;
      payment_history_value = (payment_history_value >= 2) ? ratingConstants.tableKeyConstants.greater_than_equal_two : payment_history_value;  
      let payment_history_key = payment_history_value + ratingConstants.tableKeyConstants.pipe + years_with_company;
      let payment_history_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.payment_history_factor_table),payment_history_key));
      
      let attract_score_key = ratingHelpers.getAttractScoreRange(policy_fv.attract_score);
      let attract_score_factor_key = attract_score_key + ratingConstants.tableKeyConstants.pipe + policy_fv.telematics_score;  
      let attract_score_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.attract_score_factor_table),attract_score_factor_key));
      let Uw_tier_factor = prior_claims_factor * exp_claims_factor * payment_history_factor * attract_score_factor;
     
      Uw_tier_factor = Uw_tier_factor.round(3);  
 
 
    let years_claim_free_array = [];
    let years_claim_free;
    if(policy_fv.loss_history != undefined)
    {
        for (let loss_history of policy_fv.loss_history)
        {
           let claim_date = policy_fgv[loss_history].claim_date;
           let effective_date = new Date(+policy_start_timestamp);
           years_claim_free_array.push(ratingHelpers.getYearsDiff(claim_date,effective_date))
        }
        years_claim_free = Math.min(...years_claim_free_array);
    }
    else
    {
        years_claim_free = ratingConstants.numberConstants.ninty_nine;         
    }
    //years_claim_free = parseInt(years_claim_free)
    console.log("🚀 ~ file: coverageSupportingFactors.js ~ line 124 ~ years_claim_free", years_claim_free)
    let claims_free_discount_key = (years_claim_free <= ratingConstants.numberConstants.five) ? years_claim_free : ratingConstants.tableKeyConstants.greater_than_equal_six;
    console.log("🚀 ~ file: coverageSupportingFactors.js ~ line 127 ~ claims_free_discount_key", claims_free_discount_key)
    let claims_free_discount_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.claims_free_discount_factor_table),claims_free_discount_key));
    let inc_cov_e_f_key =  otherPerilLimits.cov_e_limit + ratingConstants.tableKeyConstants.pipe + otherPerilLimits.cov_f_limit;
    let inc_cov_e_f_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.increase_coverage_e_f_factor),inc_cov_e_f_key));
    let consoleLogArray = [ 
        "nb_homebuyer_factor:" +nb_homebuyer_factor,
        "opening_protection_factor:" +opening_protection_factor,
        "roof_deck_attachment_factor:" +roof_deck_attachment_factor,
        "roof_to_wall_connection_factor:" +roof_to_wall_connection_factor,
        "secondary_water_resistance_factor:" +secondary_water_resistance_factor,
        "reinforced_exterior_doors_factor:" +reinforced_exterior_doors_factor,
        "fortified_construction_factor:" +fortified_construction_factor,
        "prior_claims_factor:" +prior_claims_factor,
        "exp_claims_factor:" +exp_claims_factor,
        "payment_history_factor:" +payment_history_factor,
        "attract_score_factor:" +attract_score_factor,
        "Uw_tier_factor:" +Uw_tier_factor,
        "claims_free_discount_factor:" +claims_free_discount_factor,
        "form_factor:" +form_factor,
        "num_of_families_factor:" +num_of_families_factor,
        "ext_replacement_cost:" +ext_replacement_cost,
        "inc_cov_e_f_factor:" +inc_cov_e_f_factor,
        "territory_code:" +territory_code,
    ]
    console.log("🚀 ~ file: coverageSupportingFactors.js ~ line 146 ~ consoleLogArray", consoleLogArray)
    return  {
        nb_homebuyer_factor,
        opening_protection_factor,
        roof_deck_attachment_factor,
        roof_to_wall_connection_factor,
        secondary_water_resistance_factor,
        reinforced_exterior_doors_factor,
        fortified_construction_factor,
        prior_claims_factor,
        exp_claims_factor,
        payment_history_factor,
        attract_score_factor,
        Uw_tier_factor,
        claims_free_discount_factor,
        form_factor,
        num_of_families_factor,
        ext_replacement_cost,
        inc_cov_e_f_factor,
        territory_code
        
    };

}
exports.getFactorsForPremium = getFactorsForPremium;