let constantValues = require("../../ratingConstants.js");
let ratingHelpers = require("../../helpersRating.js");
ratingHelpers.roundToDecimalPlaces();

function getPremiumForOrdinanceOrLawCoverage(peril, exposures, adjustedBasePremiums) {  //Not needed should remove this method later if there is no use.
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.ordinance_law_coverage_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let ordinance_law_percentage = peril_fv.ordinance_law_percent;
    let ordinance_law_factor = parseFloat(socotraApi.tableLookup(tableName, ordinance_law_percentage));
    let wind_ordinane_law_premium = adjustedBasePremiums.windBasePremium; 
    wind_ordinane_law_premium = (ordinance_law_factor - 1) * wind_ordinane_law_premium;
    wind_ordinane_law_premium = wind_ordinane_law_premium.round(constantValues.numberConstants.two);
    let water_ordinane_law_premium = adjustedBasePremiums.waterBasePremium; 
    water_ordinane_law_premium = (ordinance_law_factor - 1) * water_ordinane_law_premium;
    water_ordinane_law_premium = water_ordinane_law_premium.round(constantValues.numberConstants.two);
    let Fire_ordinane_law_premium = adjustedBasePremiums.fireBasePremium;   
    Fire_ordinane_law_premium = (ordinance_law_factor - 1) * Fire_ordinane_law_premium;
    Fire_ordinane_law_premium = Fire_ordinane_law_premium.round(constantValues.numberConstants.two);
    let Theft_ordinane_law_premium = 0;
    let liablity_ordinane_law_premium = 0;
    let other_ordinane_law_premium = adjustedBasePremiums.otherBasePremium; 
    other_ordinane_law_premium = (ordinance_law_factor - 1) * other_ordinane_law_premium;
    other_ordinane_law_premium = other_ordinane_law_premium.round(constantValues.numberConstants.two);
    let ordinance_law_coverage_premium = parseFloat(wind_ordinane_law_premium + water_ordinane_law_premium + Fire_ordinane_law_premium + Theft_ordinane_law_premium +
        liablity_ordinane_law_premium + other_ordinane_law_premium);
    return ordinance_law_coverage_premium;
}


function getPremiumForAgeOfHomeRemoulded(peril, exposures,adjustedBasePremiums, policy_start_timestamp) {
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.age_of_home_remoulded_factor_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let age_of_home = ratingHelpers.getRoofOrHomeAge(exposure_fv.year_built,policy_start_timestamp);
    console.log("🚀 ~ file: dwellingCoverages1.js ~ line 39 ~ getPremiumForAgeOfHomeRemoulded ~ age_of_home", age_of_home)
    age_of_home = (age_of_home > constantValues.numberConstants.one_hundred) ? constantValues.tableKeyConstants.greater_than_one_hundred_one  : age_of_home
    let key = constantValues.exposureFieldValueConstants.wind + constantValues.tableKeyConstants.pipe + age_of_home;
    let wind_age_of_home_remoulded_factor = parseFloat(socotraApi.tableLookup(tableName, key));
    console.log("🚀 ~ file: dwellingCoverages1.js ~ line 43 ~ getPremiumForAgeOfHomeRemoulded ~ wind_age_of_home_remoulded_factor", wind_age_of_home_remoulded_factor)

    key = constantValues.exposureFieldValueConstants.water + constantValues.tableKeyConstants.pipe + age_of_home;
    let water_age_of_home_remoulded_factor = parseFloat(socotraApi.tableLookup(tableName, key));
    console.log("🚀 ~ file: dwellingCoverages1.js ~ line 47 ~ getPremiumForAgeOfHomeRemoulded ~ water_age_of_home_remoulded_factor", water_age_of_home_remoulded_factor)

    key = constantValues.exposureFieldValueConstants.fire + constantValues.tableKeyConstants.pipe + age_of_home;
    let fire_age_of_home_remoulded_factor = parseFloat(socotraApi.tableLookup(tableName, key));
    console.log("🚀 ~ file: dwellingCoverages1.js ~ line 51 ~ getPremiumForAgeOfHomeRemoulded ~ fire_age_of_home_remoulded_factor", fire_age_of_home_remoulded_factor)

    key = constantValues.exposureFieldValueConstants.theft + constantValues.tableKeyConstants.pipe + age_of_home;
    let theft_age_of_home_remoulded_factor = parseFloat(socotraApi.tableLookup(tableName, key));

    key = constantValues.exposureFieldValueConstants.liability + constantValues.tableKeyConstants.pipe + age_of_home;
    let liability_age_of_home_remoulded_factor = parseFloat(socotraApi.tableLookup(tableName, key));

    key = constantValues.exposureFieldValueConstants.other + constantValues.tableKeyConstants.pipe + age_of_home;
    let other_age_of_home_remoulded_factor = parseFloat(socotraApi.tableLookup(tableName, key));

    let adjusted_wind_based_premium = adjustedBasePremiums.windAdjPremium;
    let wind_age_of_home_remoulded_premium = parseFloat((wind_age_of_home_remoulded_factor - constantValues.numberConstants.one) * adjusted_wind_based_premium);
    wind_age_of_home_remoulded_premium = wind_age_of_home_remoulded_premium.round(constantValues.numberConstants.two);

    let adjusted_water_based_premium = adjustedBasePremiums.waterAdjPremium;
    let water_age_of_home_remoulded_premium = parseFloat((water_age_of_home_remoulded_factor - constantValues.numberConstants.one) * adjusted_water_based_premium);
    water_age_of_home_remoulded_premium = water_age_of_home_remoulded_premium.round(constantValues.numberConstants.two);

    let adjusted_fire_based_premium = adjustedBasePremiums.fireAdjPremium;
    let fire_age_of_home_remoulded_premium = parseFloat((fire_age_of_home_remoulded_factor - constantValues.numberConstants.one) * adjusted_fire_based_premium);
    fire_age_of_home_remoulded_premium = fire_age_of_home_remoulded_premium.round(constantValues.numberConstants.two);

    let adjusted_theft_based_premium = adjustedBasePremiums.theftAdjPremium;
    let theft_age_of_home_remoulded_premium = parseFloat((theft_age_of_home_remoulded_factor - constantValues.numberConstants.one) * adjusted_theft_based_premium);
    theft_age_of_home_remoulded_premium = theft_age_of_home_remoulded_premium.round(constantValues.numberConstants.two);
    console.log("🚀 ~ file: dwellingCoverages1.js ~ line 77 ~ getPremiumForAgeOfHomeRemoulded ~ theft_age_of_home_remoulded_premium", theft_age_of_home_remoulded_premium)

    let adjusted_liability_based_premium = adjustedBasePremiums.liabilityAdjPremium;
    let liability_age_of_home_remoulded_premium = parseFloat((liability_age_of_home_remoulded_factor - constantValues.numberConstants.one) * adjusted_liability_based_premium);
    liability_age_of_home_remoulded_premium = liability_age_of_home_remoulded_premium.round(constantValues.numberConstants.two);
    console.log("🚀 ~ file: dwellingCoverages1.js ~ line 82 ~ getPremiumForAgeOfHomeRemoulded ~ liability_age_of_home_remoulded_premium", liability_age_of_home_remoulded_premium)

    let adjusted_other_based_premium = adjustedBasePremiums.otherAdjPremium;
    console.log("🚀 ~ file: dwellingCoverages1.js ~ line 85 ~ getPremiumForAgeOfHomeRemoulded ~ adjusted_other_based_premium", adjusted_other_based_premium)
    let other_age_of_home_remoulded_premium = parseFloat((other_age_of_home_remoulded_factor - constantValues.numberConstants.one) * adjusted_other_based_premium);
    other_age_of_home_remoulded_premium = other_age_of_home_remoulded_premium.round(constantValues.numberConstants.two);
    console.log("🚀 ~ file: dwellingCoverages1.js ~ line 87 ~ getPremiumForAgeOfHomeRemoulded ~ other_age_of_home_remoulded_premium", other_age_of_home_remoulded_premium)

    let total_age_of_home_remoulded_premium = (+wind_age_of_home_remoulded_premium) + (+water_age_of_home_remoulded_premium) + (+fire_age_of_home_remoulded_premium) +
        (+theft_age_of_home_remoulded_premium) + (+liability_age_of_home_remoulded_premium) + (+other_age_of_home_remoulded_premium);
        console.log("🚀 ~ file: dwellingCoverages1.js ~ line 82 ~ getPremiumForAgeOfHomeRemoulded ~ total_age_of_home_remoulded_premium", total_age_of_home_remoulded_premium)
        return {
            wind_age_of_home_remoulded_premium,
            water_age_of_home_remoulded_premium,
            fire_age_of_home_remoulded_premium,
            theft_age_of_home_remoulded_premium,
            liability_age_of_home_remoulded_premium,
            other_age_of_home_remoulded_premium,
            total_age_of_home_remoulded_premium
        };
}

function getPremiumForACVWindHailRoofLoss(peril, exposures, adjustedBasePremiums) {
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.acv_wind_hail_roof_loss_factor_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let acv_wind_hail_roof_loss_factor = parseFloat(socotraApi.tableLookup(tableName, constantValues.perilValueConstansts.actual_cash_value));
    let adjusted_wind_base_premium = adjustedBasePremiums.windAdjPremium;
    let acv_wind_hail_roof_loss_premium = parseFloat((acv_wind_hail_roof_loss_factor - constantValues.numberConstants.one) * adjusted_wind_base_premium);
    return acv_wind_hail_roof_loss_premium;
}

function getPremiumForSecondaryHomeCharge(peril, exposures, adjustedBasePremiums) {
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.secondary_home_charge_factor_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let secondary_home_charge_factor = parseFloat(socotraApi.tableLookup(tableName, constantValues.tableKeyConstants.rate));
    console.log("🚀 ~ file: dwellingCoverages1.js ~ line 112 ~ getPremiumForSecondaryHomeCharge ~ secondary_home_charge_factor", secondary_home_charge_factor)

    let adjusted_wind_base_premium = adjustedBasePremiums.windAdjPremium;
    let wind_secondary_home_charge = parseFloat((secondary_home_charge_factor) * adjusted_wind_base_premium);
    wind_secondary_home_charge = parseFloat(wind_secondary_home_charge.round(constantValues.numberConstants.two));

    let adjusted_water_base_premium = adjustedBasePremiums.waterAdjPremium;
    let water_secondary_home_charge = parseFloat((secondary_home_charge_factor) * adjusted_water_base_premium);
    water_secondary_home_charge = parseFloat(water_secondary_home_charge.round(constantValues.numberConstants.two));

    let adjusted_fire_base_premium = adjustedBasePremiums.fireAdjPremium;
    let fire_secondary_home_charge = parseFloat((secondary_home_charge_factor) * adjusted_fire_base_premium);
    fire_secondary_home_charge = parseFloat(fire_secondary_home_charge.round(constantValues.numberConstants.two));

    let adjusted_theft_base_premium = adjustedBasePremiums.theftAdjPremium;
    let theft_secondary_home_charge = parseFloat((secondary_home_charge_factor) * adjusted_theft_base_premium);
    theft_secondary_home_charge = parseFloat(theft_secondary_home_charge.round(constantValues.numberConstants.two));

    let adjusted_liability_base_premium = adjustedBasePremiums.liabilityAdjPremium;
    let liability_secondary_home_charge = parseFloat((secondary_home_charge_factor) * adjusted_liability_base_premium);
    liability_secondary_home_charge = parseFloat(liability_secondary_home_charge.round(constantValues.numberConstants.two));

    let adjusted_other_base_premium = adjustedBasePremiums.otherAdjPremium;
    let other_secondary_home_charge = parseFloat((secondary_home_charge_factor) * adjusted_other_base_premium);
    other_secondary_home_charge = parseFloat(other_secondary_home_charge.round(constantValues.numberConstants.two));

    let total_secondary_home_charge_premium = parseFloat(wind_secondary_home_charge + water_secondary_home_charge + fire_secondary_home_charge +
        theft_secondary_home_charge + liability_secondary_home_charge + other_secondary_home_charge);

        return {
            wind_secondary_home_charge,
            water_secondary_home_charge,
            fire_secondary_home_charge,
            theft_secondary_home_charge,
            liability_secondary_home_charge,
            other_secondary_home_charge,
            total_secondary_home_charge_premium
        };
}

function getPremiumForPersonalPropertyRCV(perils, peril, exposures, policyExposurePerils, adjustedBasePremiums) {
    let coverage_c_settlement_option;
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.replacement_cost_factor_table;
    let replacement_cost_factor;
    tableName = ratingHelpers.getTableName(state, tableName);
    for (let policy_exposure_peril of policyExposurePerils) {
        let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
        let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;
        if (otherPeril.name == constantValues.perilNameConstants.coverage_c) {
            coverage_c_settlement_option = otherPeril_fv.coverage_c_settlement_option;
        }
    }
    if (coverage_c_settlement_option == constantValues.perilValueConstansts.replacement_cost) {
        replacement_cost_factor = parseFloat(socotraApi.tableLookup(tableName, constantValues.perilValueConstansts.replacement_cost));
    }
    else {
        replacement_cost_factor = parseFloat(socotraApi.tableLookup(tableName, constantValues.perilValueConstansts.replacement_cost));
        replacement_cost_factor = replacement_cost_factor - constantValues.numberConstants.one;
    }
    replacement_cost_factor = replacement_cost_factor - 1;
    let adjusted_wind_base_premium = adjustedBasePremiums.windAdjPremium;
    let wind_personal_prop_rcv_premium = parseFloat(replacement_cost_factor * adjusted_wind_base_premium);
    wind_personal_prop_rcv_premium = parseFloat(wind_personal_prop_rcv_premium.round(constantValues.numberConstants.two));

    let adjusted_water_base_premium = adjustedBasePremiums.waterAdjPremium;
    let water_personal_prop_rcv_premium = parseFloat(replacement_cost_factor * adjusted_water_base_premium);
    water_personal_prop_rcv_premium = parseFloat(water_personal_prop_rcv_premium.round(constantValues.numberConstants.two));

    let adjusted_fire_base_premium = adjustedBasePremiums.fireAdjPremium;
    let fire_personal_prop_rcv_premium = parseFloat(replacement_cost_factor * adjusted_fire_base_premium);
    fire_personal_prop_rcv_premium = parseFloat(fire_personal_prop_rcv_premium.round(constantValues.numberConstants.two));

    let adjusted_theft_base_premium = adjustedBasePremiums.theftAdjPremium;
    let theft_personal_prop_rcv_premium = parseFloat(replacement_cost_factor * adjusted_theft_base_premium);
    theft_personal_prop_rcv_premium = parseFloat(theft_personal_prop_rcv_premium.round(constantValues.numberConstants.two));

    let adjusted_other_base_premium = adjustedBasePremiums.otherAdjPremium;
    let other_personal_prop_rcv_premium = parseFloat(replacement_cost_factor * adjusted_other_base_premium);
    other_personal_prop_rcv_premium = parseFloat(other_personal_prop_rcv_premium.round(constantValues.numberConstants.two));

    let personal_prop_replacement_cost_premium = wind_personal_prop_rcv_premium + water_personal_prop_rcv_premium + fire_personal_prop_rcv_premium + theft_personal_prop_rcv_premium + other_personal_prop_rcv_premium;
    let consoleLogArray = [
        "wind_personal_prop_rcv_premium:" +wind_personal_prop_rcv_premium,
        "water_personal_prop_rcv_premium:" +water_personal_prop_rcv_premium,
        "fire_personal_prop_rcv_premium:" +fire_personal_prop_rcv_premium,
        "theft_personal_prop_rcv_premium:" +theft_personal_prop_rcv_premium,
        "other_personal_prop_rcv_premium:" +other_personal_prop_rcv_premium,
        "personal_prop_replacement_cost_premium:" +personal_prop_replacement_cost_premium
    ]
    console.log("🚀 ~ file: dwellingCoverages1.js ~ line 209 ~ getPremiumForPersonalPropertyRCV ~ consoleLogArray", consoleLogArray)
    return {
        wind_personal_prop_rcv_premium,
        water_personal_prop_rcv_premium,
        fire_personal_prop_rcv_premium,
        theft_personal_prop_rcv_premium,
        other_personal_prop_rcv_premium,
        personal_prop_replacement_cost_premium
    }
}



exports.getPremiumForOrdinanceOrLawCoverage = getPremiumForOrdinanceOrLawCoverage;
exports.getPremiumForAgeOfHomeRemoulded = getPremiumForAgeOfHomeRemoulded;
exports.getPremiumForACVWindHailRoofLoss = getPremiumForACVWindHailRoofLoss;
exports.getPremiumForSecondaryHomeCharge = getPremiumForSecondaryHomeCharge;
exports.getPremiumForPersonalPropertyRCV = getPremiumForPersonalPropertyRCV;
