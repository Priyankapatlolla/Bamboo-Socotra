let constantValues = require("../../ratingConstants.js");
let ratingHelpers = require("../../helpersRating.js");
let dwellingCoverages1 = require("./dwellingCoverages1.js");
ratingHelpers.roundToDecimalPlaces();


function getPremiumForCertainNonBuilding(peril, exposures,adjustedBasePremiums) {
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.replacement_cost_nonbldg_factor_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let replace_cost_nonbldg_struct_factor = parseFloat(socotraApi.tableLookup(tableName, constantValues.perilValueConstansts.non_bldg));
    let adjusted_wind_base_premium = adjustedBasePremiums.windAdjPremium;
    let wind_replace_cost_nonbldg_struct_premium = parseFloat((replace_cost_nonbldg_struct_factor - 1) * adjusted_wind_base_premium);
    wind_replace_cost_nonbldg_struct_premium = parseFloat(wind_replace_cost_nonbldg_struct_premium.round(constantValues.numberConstants.two));

    let adjusted_water_base_premium = adjustedBasePremiums.waterAdjPremium;
    let water_replace_cost_nonbldg_struct_premium = parseFloat((replace_cost_nonbldg_struct_factor - 1) * adjusted_water_base_premium);
    water_replace_cost_nonbldg_struct_premium = parseFloat(water_replace_cost_nonbldg_struct_premium.round(constantValues.numberConstants.two));

    let adjusted_fire_base_premium = adjustedBasePremiums.fireAdjPremium;
    let fire_replace_cost_nonbldg_struct_premium = parseFloat((replace_cost_nonbldg_struct_factor - 1) * adjusted_fire_base_premium);
    fire_replace_cost_nonbldg_struct_premium = parseFloat(fire_replace_cost_nonbldg_struct_premium.round(constantValues.numberConstants.two));

    let adjusted_theft_base_premium = adjustedBasePremiums.theftAdjPremium;
    let theft_replace_cost_nonbldg_struct_premium = parseFloat((replace_cost_nonbldg_struct_factor - 1) * adjusted_theft_base_premium);
    theft_replace_cost_nonbldg_struct_premium = parseFloat(theft_replace_cost_nonbldg_struct_premium.round(constantValues.numberConstants.two));

    let adjusted_other_base_premium = adjustedBasePremiums.otherAdjPremium;
    let other_replace_cost_nonbldg_struct_premium = parseFloat((replace_cost_nonbldg_struct_factor - 1) * adjusted_other_base_premium);
    other_replace_cost_nonbldg_struct_premium = parseFloat(other_replace_cost_nonbldg_struct_premium.round(constantValues.numberConstants.two));

    let replace_cost_nonbldg_struct_premium = parseFloat(wind_replace_cost_nonbldg_struct_premium + water_replace_cost_nonbldg_struct_premium + fire_replace_cost_nonbldg_struct_premium +
        theft_replace_cost_nonbldg_struct_premium + other_replace_cost_nonbldg_struct_premium);
    
        let consoleLogArray = [
            "wind_replace_cost_nonbldg_struct_premium: "+wind_replace_cost_nonbldg_struct_premium,
            "water_replace_cost_nonbldg_struct_premium: "+water_replace_cost_nonbldg_struct_premium,
            "fire_replace_cost_nonbldg_struct_premium: "+fire_replace_cost_nonbldg_struct_premium,
            "theft_replace_cost_nonbldg_struct_premium: " +theft_replace_cost_nonbldg_struct_premium,
            "other_replace_cost_nonbldg_struct_premium: " +other_replace_cost_nonbldg_struct_premium
     ]
        console.log("🚀 ~ file: dwellingCoverages2.js ~ line 42 ~ getPremiumForCertainNonBuilding ~ consoleLogArray", consoleLogArray)

    return {
        wind_replace_cost_nonbldg_struct_premium,
        water_replace_cost_nonbldg_struct_premium,
        fire_replace_cost_nonbldg_struct_premium,
        theft_replace_cost_nonbldg_struct_premium,
        other_replace_cost_nonbldg_struct_premium,
        replace_cost_nonbldg_struct_premium  
    };

}

function getPremiumForOtherStructuresIncreasedLimit(perils, peril, exposures, policyExposurePerils,factors) {
    let coverage_a_limit;
    let other_b_limit;
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.increase_decrease_cov_b_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let uw_tier_factor = factors.Uw_tier_factor;
    let claims_free_discount_factor = factors.claims_free_discount_factor;
    for (let policy_exposure_peril of policyExposurePerils) {
        let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
        let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;
        if (otherPeril.name == constantValues.perilNameConstants.coverage_a) {
            coverage_a_limit = parseFloat(ratingHelpers.removeSpecialCharacters(otherPeril_fv.coverage_a_limit));
        }
        if (otherPeril.name == constantValues.perilNameConstants.coverage_b) {
            other_b_limit = parseFloat(ratingHelpers.removeSpecialCharacters(otherPeril_fv.other_b_limit));
        }
    }
    let Incr_decr_coverage_b_limit_per_mill_factor = parseFloat(((coverage_a_limit / constantValues.numberConstants.one_thousand) * constantValues.numberConstants.point_one) -
        (other_b_limit / constantValues.numberConstants.one_thousand));
    console.log("🚀 ~ file: dwellingCoverages2.js ~ line 75 ~ getPremiumForOtherStructuresIncreasedLimit ~ Incr_decr_coverage_b_limit_per_mill_factor", Incr_decr_coverage_b_limit_per_mill_factor)
    let increase_decrease_cov_b_premium;
    if(Incr_decr_coverage_b_limit_per_mill_factor < constantValues.numberConstants.zero)
    {
        let decrease_lookup_value = parseFloat(socotraApi.tableLookup(tableName,constantValues.tableKeyConstants.decrease));
        increase_decrease_cov_b_premium = Incr_decr_coverage_b_limit_per_mill_factor * decrease_lookup_value;
        console.log("🚀 ~ file: dwellingCoverages2.js ~ line 81 ~ getPremiumForOtherStructuresIncreasedLimit ~ increase_decrease_cov_b_premium", increase_decrease_cov_b_premium)
    }
    else if(Incr_decr_coverage_b_limit_per_mill_factor > constantValues.numberConstants.zero)
    {
        let increase_lookup_value = parseFloat(socotraApi.tableLookup(tableName,constantValues.tableKeyConstants.increase));
        increase_decrease_cov_b_premium =  Incr_decr_coverage_b_limit_per_mill_factor * increase_lookup_value * uw_tier_factor * claims_free_discount_factor;
        console.log("🚀 ~ file: dwellingCoverages2.js ~ line 87 ~ getPremiumForOtherStructuresIncreasedLimit ~ increase_decrease_cov_b_premium", increase_decrease_cov_b_premium)
    }
    else if(Incr_decr_coverage_b_limit_per_mill_factor == constantValues.numberConstants.zero)
    {
        let includedlookup_value = parseFloat(socotraApi.tableLookup(tableName,constantValues.tableKeyConstants.included));
        increase_decrease_cov_b_premium =  parseFloat(Incr_decr_coverage_b_limit_per_mill_factor * includedlookup_value * uw_tier_factor * claims_free_discount_factor);
        console.log("🚀 ~ file: dwellingCoverages2.js ~ line 93 ~ getPremiumForOtherStructuresIncreasedLimit ~ increase_decrease_cov_b_premium", increase_decrease_cov_b_premium)
    }
    increase_decrease_cov_b_premium = increase_decrease_cov_b_premium.round(constantValues.numberConstants.two)
    console.log("🚀 ~ file: dwellingCoverages2.js ~ line 96 ~ getPremiumForOtherStructuresIncreasedLimit ~ increase_decrease_cov_b_premium", increase_decrease_cov_b_premium)
    return increase_decrease_cov_b_premium;
}

function getPremiumForIncreaseDecreaseCovC(perils, peril, exposures, policyExposurePerils,factors) {

    let coverage_a_limit;
    let personal_property_limit;
    let coverage_c_settlement_option;
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.increase_decrease_cov_c_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let uw_tier_factor = factors.Uw_tier_factor;
    let claims_free_discount_factor = factors.claims_free_discount_factor;
    for (let policy_exposure_peril of policyExposurePerils) {
        let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
        let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;
        if (otherPeril.name == constantValues.perilNameConstants.coverage_a) {
            coverage_a_limit = parseFloat(ratingHelpers.removeSpecialCharacters(otherPeril_fv.coverage_a_limit));
        }
        if (otherPeril.name == constantValues.perilNameConstants.coverage_c) {
            personal_property_limit = parseFloat(ratingHelpers.removeSpecialCharacters(otherPeril_fv.personal_property_limit));
            coverage_c_settlement_option = otherPeril_fv.coverage_c_settlement_option;
        }
    }
    let Incr_decr_coverage_c_limit_per_mill_factor = parseFloat(((coverage_a_limit / constantValues.numberConstants.one_thousand) * constantValues.numberConstants.point_five) -
        (personal_property_limit / constantValues.numberConstants.one_thousand));
    let increase_decrease_cov_c_premium;
    let pp_rc_value;
    if(coverage_c_settlement_option == constantValues.perilValueConstansts.replacement_cost)
    {
        pp_rc_value = constantValues.binaryConstants.yes;
    }
    else
    {
        pp_rc_value = constantValues.binaryConstants.no;
    }
    if(Incr_decr_coverage_c_limit_per_mill_factor < constantValues.numberConstants.zero)
    {
        let inc_dec_cov_key = pp_rc_value + constantValues.tableKeyConstants.pipe + constantValues.tableKeyConstants.decrease + constantValues.tableKeyConstants.pipe + constantValues.tableKeyConstants.HO3
        let increase_decreasecov_c_lookup_value = parseFloat(socotraApi.tableLookup(tableName,inc_dec_cov_key));
        increase_decrease_cov_c_premium = parseFloat(Incr_decr_coverage_c_limit_per_mill_factor * increase_decreasecov_c_lookup_value);
    }
    else if(Incr_decr_coverage_c_limit_per_mill_factor > constantValues.numberConstants.zero)
    {
        let inc_dec_cov_key = pp_rc_value + constantValues.tableKeyConstants.pipe + constantValues.tableKeyConstants.decrease + constantValues.tableKeyConstants.pipe + constantValues.tableKeyConstants.HO3
        let increase_decreasecov_c_lookup_value = parseFloat(socotraApi.tableLookup(tableName,inc_dec_cov_key));
        increase_decrease_cov_c_premium =  parseFloat(Incr_decr_coverage_c_limit_per_mill_factor * increase_decreasecov_c_lookup_value * uw_tier_factor * claims_free_discount_factor);
    }
    else if(Incr_decr_coverage_c_limit_per_mill_factor == constantValues.numberConstants.zero)
    {
        increase_decrease_cov_c_premium =  constantValues.numberConstants.zero;
    }
    increase_decrease_cov_c_premium = increase_decrease_cov_c_premium.round(constantValues.numberConstants.two)
    return increase_decrease_cov_c_premium;
}


function getPremiumForACVRoof(peril, exposures,adjustedBasePremiums)
{
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril,exposures,adjustedBasePremiums);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.acv_roof_factor_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let acv_roof_factor = parseFloat(socotraApi.tableLookup(tableName,constantValues.tableKeyConstants.rate));
    let adjusted_wind_base_premium = adjustedBasePremiums.windAdjPremium;
    let acv_roof_premium = parseFloat(-acv_roof_factor * adjusted_wind_base_premium);
    acv_roof_premium = acv_roof_premium.round(constantValues.numberConstants.two);
    return acv_roof_premium;

}

function getPremiumForTownhouseOrRowHouse(peril, exposures,adjustedBasePremiums)
{
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    let number_of_town_houses = peril_fv.number_of_town_houses;
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril,exposures);
    let protection_class = exposure_fv.protection_class;
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.townhouse_factor_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let protection_class_key;
    let no_of_town_houses_key;
    if(protection_class <= constantValues.numberConstants.eight)
    {
        protection_class_key = constantValues.tableKeyConstants.less_than_equal_eight;
    }
    else
    {
        protection_class_key = constantValues.tableKeyConstants.multiplication;
    }
    if(number_of_town_houses > constantValues.numberConstants.four)
    {
        no_of_town_houses_key = constantValues.tableKeyConstants.greater_than_four
    }
    else
    {
        no_of_town_houses_key = number_of_town_houses
    }
    let town_house_key = no_of_town_houses_key + constantValues.tableKeyConstants.pipe + protection_class_key;
    console.log("🚀 ~ file: dwellingCoverages2.js ~ line 197 ~ town_house_key", town_house_key)
    let adjusted_fire_base_premium = adjustedBasePremiums.fireAdjPremium;
    let town_house_lookup_value = parseFloat(socotraApi.tableLookup(tableName, town_house_key))
    let town_house_premium = (town_house_lookup_value - 1) * adjusted_fire_base_premium;
    town_house_premium = town_house_premium.round(constantValues.numberConstants.two);
    return town_house_premium;
}



exports.getPremiumForCertainNonBuilding = getPremiumForCertainNonBuilding;
exports.getPremiumForOtherStructuresIncreasedLimit = getPremiumForOtherStructuresIncreasedLimit;
exports.getPremiumForIncreaseDecreaseCovC = getPremiumForIncreaseDecreaseCovC;
exports.getPremiumForACVRoof = getPremiumForACVRoof;
exports.getPremiumForTownhouseOrRowHouse = getPremiumForTownhouseOrRowHouse;