let ratingHelpers = require("../../helpersRating.js");
let constantValues = require("../../ratingConstants.js");
ratingHelpers.roundToDecimalPlaces();
function getPremiumForRefridgeratedPersonalProperty(peril,exposures)
{
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril,exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.unscheduled_fridge_property_rate_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let electrical_power_backup = exposure_fv.electrical_power_backup;
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    let refrigerated_property_limit = peril_fv.refrigerated_property_limit;
    refrigerated_property_limit = ratingHelpers.removeSpecialCharacters(refrigerated_property_limit);
    let unscheduled_fridge_property_rate = parseFloat(socotraApi.tableLookup(tableName,refrigerated_property_limit));
    let unscheduled_fridge_property_premium;
    if(electrical_power_backup == constantValues.binaryConstants.yes)
    {
        unscheduled_fridge_property_premium = parseFloat(unscheduled_fridge_property_rate * constantValues.numberConstants.point_eight);
        unscheduled_fridge_property_premium = parseFloat(unscheduled_fridge_property_premium.round(constantValues.numberConstants.two));
    }
    else
    {
        unscheduled_fridge_property_premium = constantValues.numberConstants.zero;
    }
    return unscheduled_fridge_property_premium;
}

function getPremiumForSpecificOtherStructureCover(peril,exposures)
{
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril,exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.specific_other_structure_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    let peril_gfv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;
    let specific_other_details_groups = peril_fv.specific_other_details;
    let specific_other_structure_limit = constantValues.numberConstants.zero;
    if(specific_other_details_groups != undefined)
    {
        for(let specific_other_details_group of specific_other_details_groups)
        {
            specific_other_structure_limit += parseFloat(ratingHelpers.removeSpecialCharacters(peril_gfv[specific_other_details_group].specific_other_structure_limit));
        }
    }

    specific_other_structure_limit = parseFloat(ratingHelpers.removeSpecialCharacters(peril_gfv[peril_fv.specific_other_details].specific_other_structure_limit));
    let specific_other_structures_factor = parseFloat(socotraApi.tableLookup(tableName,constantValues.tableKeyConstants.rate));
    let specific_other_structures_premium = (specific_other_structure_limit/constantValues.numberConstants.one_thousand) * specific_other_structures_factor;
    specific_other_structures_premium = specific_other_structures_premium.round(constantValues.numberConstants.two);
    return specific_other_structures_premium;
}

function getPremiumForSupplementLossAssessmentCoverage(peril,exposures)
{
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril,exposures);
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    let supplemental_loss_assessment_limit = peril_fv.supplemental_loss_assessment_limit; 
    supplemental_loss_assessment_limit = ratingHelpers.removeSpecialCharacters(supplemental_loss_assessment_limit);
    let supplemental_deductible_limit = peril_fv.supplemental_deductible_limit;
    supplemental_deductible_limit = ratingHelpers.removeSpecialCharacters(supplemental_deductible_limit);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.loss_assessment_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let loss_assessment_key = supplemental_loss_assessment_limit + constantValues.tableKeyConstants.pipe + constantValues.tableKeyConstants.HO3
    let loss_assesment_limit_factor = parseFloat(socotraApi.tableLookup(tableName, loss_assessment_key));
    tableName = constantValues.tableNameConsts.loss_assessment_ded_rate;
    tableName = ratingHelpers.getTableName(state, tableName);
    let loss_assessment_ded_rate = parseFloat(socotraApi.tableLookup(tableName,constantValues.tableKeyConstants.rate));
    let loss_assesment_premium = parseFloat(loss_assesment_limit_factor + (((supplemental_deductible_limit - constantValues.numberConstants.one_thousand)/constantValues.numberConstants.one_thousand) * loss_assessment_ded_rate));
    loss_assesment_premium = loss_assesment_premium.round(constantValues.numberConstants.two)
    return loss_assesment_premium; 
}

function getPremiumForBusinessPropertyIncLimits(peril,exposures)
{
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril,exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.business_property_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    let business_prop_incr_limit_on_prem = peril_fv.business_prop_incr_limit_on_prem;
    business_prop_incr_limit_on_prem = ratingHelpers.removeSpecialCharacters(business_prop_incr_limit_on_prem);
    let business_property_premium = parseFloat(socotraApi.tableLookup(tableName,business_prop_incr_limit_on_prem));
    business_property_premium = business_property_premium.round(constantValues.numberConstants.two);
    return business_property_premium;
}

function getPremiumForLimitedLiabilityCoverage(perils, peril, exposures, policyExposurePerils)
{
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril,exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.animal_liability_table;
    let coverage_e_personal_liability_limit;
    tableName = ratingHelpers.getTableName(state, tableName);
    for (let policy_exposure_peril of policyExposurePerils) {
        let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
        let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;
        if (otherPeril.name == constantValues.perilNameConstants.coverage_e) {
            coverage_e_personal_liability_limit = otherPeril_fv.coverage_e_personal_liability_limit;
            coverage_e_personal_liability_limit = ratingHelpers.removeSpecialCharacters(coverage_e_personal_liability_limit);
        }
    }
    
    let animal_liability_premium = parseFloat(socotraApi.tableLookup(tableName, coverage_e_personal_liability_limit));
    return animal_liability_premium;
}

function getPremiumForEquipmentBreakdowncoverage(peril, exposures)
{
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril,exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.equipment_breakdown_coverage_premium_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let equipment_break_down_premium = parseFloat(socotraApi.tableLookup(tableName,constantValues.tableKeyConstants.rate));
    equipment_break_down_premium = Math.round(equipment_break_down_premium);
    return equipment_break_down_premium;

}

function getPremiumForServiceLineCoverage(peril, exposures)
{
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril,exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.service_line_coverage_premium_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let service_line_coverage_premium = parseFloat(socotraApi.tableLookup(tableName,constantValues.tableKeyConstants.rate));
    service_line_coverage_premium = Math.round(service_line_coverage_premium);
    return service_line_coverage_premium;
}

function getPremiumForLimitedfungi(peril, exposures)
{
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    let fungi_microbes_coverage_limit = peril_fv.fungi_microbes_coverage_limit;
    fungi_microbes_coverage_limit = ratingHelpers.removeSpecialCharacters(fungi_microbes_coverage_limit);
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril,exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.limited_fungi_premium_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let limited_fungi_premium = parseFloat(socotraApi.tableLookup(tableName, fungi_microbes_coverage_limit))
    return limited_fungi_premium;
}

function getPremiumForIncreaseCovD(perils, peril, exposures, policyExposurePerils, factors) {

    let coverage_a_limit;
    let coverage_d_loss_of_use_percentage;
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.increase_decrease_cov_d_table;
   
    let Uw_tier_factor = factors.Uw_tier_factor;
    let claims_free_discount_factor = factors.claims_free_discount_factor;
    tableName = ratingHelpers.getTableName(state, tableName);
    for (let policy_exposure_peril of policyExposurePerils) {
        let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
        let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;
        if (otherPeril.name == constantValues.perilNameConstants.coverage_a) {
            coverage_a_limit = parseFloat(ratingHelpers.removeSpecialCharacters(otherPeril_fv.coverage_a_limit));
        }
        if (otherPeril.name == constantValues.perilNameConstants.coverage_d) {
            coverage_d_loss_of_use_percentage = parseFloat(ratingHelpers.removeSpecialCharacters(otherPeril_fv.coverage_d_loss_of_use));
        }
    }
    let Incr_decr_coverage_d_limit_per_mill_factor = (((coverage_a_limit / constantValues.numberConstants.one_thousand) * constantValues.numberConstants.point_three) -
    (coverage_d_loss_of_use_percentage / constantValues.numberConstants.one_thousand));
    let increase_decreasecov_d_lookup_value = parseFloat(socotraApi.tableLookup(tableName,constantValues.tableKeyConstants.rate));
    let increase_decrease_cov_d_premium = Incr_decr_coverage_d_limit_per_mill_factor * increase_decreasecov_d_lookup_value * Uw_tier_factor * claims_free_discount_factor;
    increase_decrease_cov_d_premium = increase_decrease_cov_d_premium.round(constantValues.numberConstants.two);
    return increase_decrease_cov_d_premium;
}

function getPremiumForIncreaseSpecialLimits(peril, exposures)
{
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;

    let increased_special_limits_jewelrywatchfur_limit = peril_fv.increased_special_limits_jewelrywatchfur_limit;
    increased_special_limits_jewelrywatchfur_limit = ratingHelpers.removeSpecialCharacters(increased_special_limits_jewelrywatchfur_limit);

    let increased_special_limits_money_limit = peril_fv.increased_special_limits_money_limit;
    increased_special_limits_money_limit = ratingHelpers.removeSpecialCharacters(increased_special_limits_money_limit);

    let increased_special_limits_securities_limit = peril_fv.increased_special_limits_securities_limit;
    increased_special_limits_securities_limit = ratingHelpers.removeSpecialCharacters(increased_special_limits_securities_limit);

    let increased_special_limits_silver_gold_pewter_limit = peril_fv.increased_special_limits_silver_gold_pewter_limit;
    increased_special_limits_silver_gold_pewter_limit = ratingHelpers.removeSpecialCharacters(increased_special_limits_silver_gold_pewter_limit);

    let increased_special_limits_firearms_limit = peril_fv.increased_special_limits_firearms_limit;
    increased_special_limits_firearms_limit = ratingHelpers.removeSpecialCharacters(increased_special_limits_firearms_limit);

    let increased_special_limits_port_elect_equipment_limit = peril_fv.increased_special_limits_port_elect_equipment_limit;
    increased_special_limits_port_elect_equipment_limit = ratingHelpers.removeSpecialCharacters(increased_special_limits_port_elect_equipment_limit);

    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let maxTableName = constantValues.tableNameConsts.max_limit;
    maxTableName = ratingHelpers.getTableName(state, maxTableName);
    
    let rateTableName = constantValues.tableNameConsts.rate_division;
    rateTableName = ratingHelpers.getTableName(state, rateTableName);
    
    let ppisTableName = constantValues.tableNameConsts.ppis_rate;
    ppisTableName = ratingHelpers.getTableName(state, ppisTableName);

    let jewelery_watches_furs_key = constantValues.perilValueConstansts.jewelery_watches_furs;
    let money_key = constantValues.perilValueConstansts.money;
    let securities_key = constantValues.perilValueConstansts.securites;
    let silverware_key = constantValues.perilValueConstansts.silverware;
    let firearms_key = constantValues.perilValueConstansts.firearms;
    let portable_electronic_equipment_key = constantValues.perilValueConstansts.portable_electronic_equipment;

    let jew_watches_furs_max_limit = parseFloat(socotraApi.tableLookup(maxTableName,jewelery_watches_furs_key));
    let money_max_limit = parseFloat(socotraApi.tableLookup(maxTableName,money_key));
    let securities_max_limit = parseFloat(socotraApi.tableLookup(maxTableName,securities_key));
    let silverware_max_limit = parseFloat(socotraApi.tableLookup(maxTableName,silverware_key));
    let firearms_max_limit = parseFloat(socotraApi.tableLookup(maxTableName,firearms_key));
    let portable_electronic_max_limit = parseFloat(socotraApi.tableLookup(maxTableName,portable_electronic_equipment_key));

    let jewelry_watches_furs_rate_division = parseFloat(socotraApi.tableLookup(rateTableName,jewelery_watches_furs_key));
    let money_rate_division = parseFloat(socotraApi.tableLookup(rateTableName,money_key));
    let securities_rate_division = parseFloat(socotraApi.tableLookup(rateTableName,securities_key));
    let silverware_rate_division = parseFloat(socotraApi.tableLookup(rateTableName,silverware_key));
    let firearms_rate_division = parseFloat(socotraApi.tableLookup(rateTableName,firearms_key));
    let portable_electronic_rate_division = parseFloat(socotraApi.tableLookup(rateTableName,portable_electronic_equipment_key));

    let jewelry_watches_furs_allowed_limit = Math.min(jew_watches_furs_max_limit,increased_special_limits_jewelrywatchfur_limit);
    let money_allowed_limit = Math.min(money_max_limit,increased_special_limits_money_limit);
    let securities_allowed_limit = Math.min(securities_max_limit,increased_special_limits_securities_limit);
    let silverware_allowed_limit = Math.min(silverware_max_limit,increased_special_limits_silver_gold_pewter_limit);
    let firearms_allowed_limit = Math.min(firearms_max_limit,increased_special_limits_firearms_limit);
    let portable_electronic_allowed_limit = Math.min(portable_electronic_max_limit,increased_special_limits_port_elect_equipment_limit);

    let jewelry_watches_furs_rate_multiple = jewelry_watches_furs_allowed_limit/jewelry_watches_furs_rate_division;
    let money_rate_multiple = money_allowed_limit/money_rate_division;
    let securities_rate_multiple = securities_allowed_limit/securities_rate_division;
    let silverware_rate_multiple = silverware_allowed_limit/silverware_rate_division;
    let firearms_rate_multiple = firearms_allowed_limit/firearms_rate_division;
    let portable_rate_multiple = portable_electronic_allowed_limit/portable_electronic_rate_division;

    let jewelry_watches_furs_ppis_rate = parseFloat(socotraApi.tableLookup(ppisTableName,jewelery_watches_furs_key));
    let money_ppis_rate = parseFloat(socotraApi.tableLookup(ppisTableName,money_key));
    let securities_ppis_rate = parseFloat(socotraApi.tableLookup(ppisTableName,securities_key));
    let silverware_ppis_rate = parseFloat(socotraApi.tableLookup(ppisTableName,silverware_key));
    let firearms_ppis_rate = parseFloat(socotraApi.tableLookup(ppisTableName,firearms_key));
    let portable_ppis_rate = parseFloat(socotraApi.tableLookup(ppisTableName,portable_electronic_equipment_key));

    let jewelry_watches_furs_premium = jewelry_watches_furs_ppis_rate * jewelry_watches_furs_rate_multiple;
    let money_furs_premium = money_ppis_rate * money_rate_multiple;
    let securities_furs_premium = securities_ppis_rate * securities_rate_multiple;
    let silverware_furs_premium = silverware_ppis_rate * silverware_rate_multiple;
    let firearms_furs_premium = firearms_ppis_rate * firearms_rate_multiple;
    let portable_premium = portable_ppis_rate * portable_rate_multiple;

    let special_limits_for_pp_premium = parseFloat(jewelry_watches_furs_premium) + parseFloat(money_furs_premium) + parseFloat(securities_furs_premium) + parseFloat(silverware_furs_premium) + parseFloat(firearms_furs_premium) + parseFloat(portable_premium);

    return special_limits_for_pp_premium;
}



exports.getPremiumForRefridgeratedPersonalProperty = getPremiumForRefridgeratedPersonalProperty;
exports.getPremiumForSpecificOtherStructureCover = getPremiumForSpecificOtherStructureCover;
exports.getPremiumForSupplementLossAssessmentCoverage = getPremiumForSupplementLossAssessmentCoverage;
exports.getPremiumForBusinessPropertyIncLimits = getPremiumForBusinessPropertyIncLimits;
exports.getPremiumForLimitedLiabilityCoverage = getPremiumForLimitedLiabilityCoverage;
exports.getPremiumForEquipmentBreakdowncoverage = getPremiumForEquipmentBreakdowncoverage;
exports.getPremiumForServiceLineCoverage = getPremiumForServiceLineCoverage;
exports.getPremiumForLimitedfungi = getPremiumForLimitedfungi;
exports.getPremiumForIncreaseCovD = getPremiumForIncreaseCovD;
exports.getPremiumForIncreaseSpecialLimits = getPremiumForIncreaseSpecialLimits;