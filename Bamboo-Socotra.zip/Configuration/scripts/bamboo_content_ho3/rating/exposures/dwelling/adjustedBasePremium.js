let ratingConstants = require('../../ratingConstants.js');
let ratingHelpers = require('../../helpersRating.js');
ratingHelpers.roundToDecimalPlaces();
function getWindAdjustedPremium(policy_fv,perils,exposure,policyExposurePerils,factors){

    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let type_constant = ratingConstants.tableKeyConstants.wind;
    let state = exposure_fv.property_state;
    let otherPerilLimits = ratingHelpers.getOtherPerilLimits(policyExposurePerils,perils);
    let cov_a_limit = otherPerilLimits.cov_a_limit;
    let deductible_limit = otherPerilLimits.windhail_deductible;
    let ordinance_law_percentage = otherPerilLimits.ordinance_law_percentage;
    let wind_base_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.base_rate_table),ratingConstants.tableKeyConstants.wind));
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 13 ~ getWindAdjustedPremium ~ wind_base_rate", wind_base_rate)
    let wind_territory_key = ratingConstants.tableKeyConstants.wind + ratingConstants.tableKeyConstants.pipe + factors.territory_code;
    let wind_territory_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.territory_factor_table),wind_territory_key));
    wind_territory_factor = !isNaN(wind_territory_factor) ? wind_territory_factor : ratingConstants.numberConstants.one;  // saftey check so that premium will not be zero.
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 16 ~ getWindAdjustedPremium ~ wind_territory_factor", wind_territory_factor)
    let wind_nb_homebuyer_factor = ratingConstants.numberConstants.one;
    if(policy_fv.nb_homebuyer == ratingConstants.binaryConstants.yes)
    {
        wind_nb_homebuyer_factor_key = policy_fv.months_owned + ratingConstants.tableKeyConstants.pipe + ratingConstants.exposureFieldValueConstants.wind;
        wind_nb_homebuyer_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.nb_home_buyer_rate_table),wind_nb_homebuyer_factor_key));
    }
    let wind_base_class_premium = parseFloat(wind_base_rate * wind_territory_factor).round(2);
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 25 ~ getWindAdjustedPremium ~ wind_base_class_premium", wind_base_class_premium)
    let wind_base_premium = wind_base_class_premium * factors.form_factor ; 
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 27 ~ getWindAdjustedPremium ~ wind_base_premium", wind_base_premium)
    let wind_cov_a_ded_factor = ratingHelpers.interpolate(state,cov_a_limit,ratingConstants.tableNameConsts.wind_cov_a_ded_factor_table,deductible_limit,type_constant);
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 29 ~ getWindAdjustedPremium ~ wind_cov_a_ded_factor", wind_cov_a_ded_factor)
    wind_base_premium = parseFloat(wind_base_premium * wind_cov_a_ded_factor).round(2);  
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 31 ~ getWindAdjustedPremium ~ wind_base_premium", wind_base_premium)
    wind_base_premium = parseFloat(wind_base_premium * factors.num_of_families_factor).round(2);
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 33 ~ getWindAdjustedPremium ~ wind_base_premium", wind_base_premium)
    let wind_adj_base_premium = parseFloat(wind_base_premium * factors.ext_replacement_cost).round(2);  
    let wind_extended_replacement_cost_disc = wind_base_premium - wind_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 37 ~ getWindAdjustedPremium ~ wind_extended_replacement_cost_disc", wind_extended_replacement_cost_disc)
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 34 ~ getWindAdjustedPremium ~ wind_adj_base_premium", wind_adj_base_premium)
    wind_adj_base_premium = parseFloat(wind_adj_base_premium * wind_nb_homebuyer_factor).round(2);
    let wind_nb_homebuyer_disc =  parseFloat(wind_base_premium * factors.ext_replacement_cost).round(2) - wind_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 40 ~ getWindAdjustedPremium ~ wind_nb_homebuyer_disc", wind_nb_homebuyer_disc)
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 36 ~ getWindAdjustedPremium ~ wind_adj_base_premium", wind_adj_base_premium)
    let wind_mitigation_credit_factor = Math.max(factors.opening_protection_factor * factors.roof_deck_attachment_factor * 
    factors.roof_to_wall_connection_factor * factors.secondary_water_resistance_factor * factors.reinforced_exterior_doors_factor *
    factors.fortified_construction_factor,ratingConstants.numberConstants.point_eight);
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 40 ~ getWindAdjustedPremium ~ wind_mitigation_credit_factor", wind_mitigation_credit_factor)
    // if(wind_mitigation_credit_factor > ratingConstants.numberConstants.point_eight)
    // {
    //  socotraApi.setAuxData("MitigationCreditFactor","flag","Yes","normal");
    // }
    wind_adj_base_premium = parseFloat(wind_adj_base_premium * wind_mitigation_credit_factor).round(2);
    let premium_with_mitigation_credit = wind_adj_base_premium;
    let wind_mitigation_credit_disc =  parseFloat((wind_base_premium * factors.ext_replacement_cost).round(2) * wind_nb_homebuyer_factor).round(2) - wind_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 50 ~ getWindAdjustedPremium ~ wind_mitigation_credit_disc", wind_mitigation_credit_disc)
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 46 ~ getWindAdjustedPremium ~ wind_adj_base_premium", wind_adj_base_premium)
    wind_adj_base_premium = parseFloat(wind_adj_base_premium * factors.Uw_tier_factor).round(2);
    let premium_with_Uw_tier = wind_adj_base_premium;
    let wind_uwTier =  premium_with_mitigation_credit - premium_with_Uw_tier;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 58 ~ getWindAdjustedPremium ~ wind_uwTier", wind_uwTier)
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 48 ~ getWindAdjustedPremium ~ wind_adj_base_premium", wind_adj_base_premium)
    wind_adj_base_premium = parseFloat(wind_adj_base_premium * factors.claims_free_discount_factor).round(2);
    let wind_claims_free_disc =  premium_with_Uw_tier - wind_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 56 ~ getWindAdjustedPremium ~ wind_claims_free_disc", wind_claims_free_disc)
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 50 ~ getWindAdjustedPremium ~ wind_adj_base_premium", wind_adj_base_premium)
    let wind_ordinane_law_premium = ratingConstants.numberConstants.zero;
    let tableName = ratingConstants.tableNameConsts.ordinance_law_coverage_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let ordinance_law_factor = parseFloat(socotraApi.tableLookup(tableName, ordinance_law_percentage));
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 64 ~ getWindAdjustedPremium ~ ordinance_law_percentage", ordinance_law_percentage)
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 55 ~ getWindAdjustedPremium ~ ordinance_law_factor", ordinance_law_factor)
    wind_ordinane_law_premium = wind_base_premium;
    let wind_ordinane_law_premium_total = parseFloat((ordinance_law_factor - 1) * wind_ordinane_law_premium).round(2); 
    wind_ordinane_law_premium_total = !isNaN(wind_ordinane_law_premium_total) ? wind_ordinane_law_premium_total : ratingConstants.numberConstants.zero;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 59 ~ getWindAdjustedPremium ~ wind_ordinane_law_premium_total", wind_ordinane_law_premium_total)
    wind_adj_base_premium = (+wind_adj_base_premium) + (+wind_ordinane_law_premium_total);
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 59 ~ getWindAdjustedPremium ~ wind_adj_base_premium", wind_adj_base_premium)
    return {
        wind_base_premium,
        wind_adj_base_premium,
        wind_nb_homebuyer_disc,
        wind_mitigation_credit_disc,
        wind_claims_free_disc,
        wind_uwTier,
        wind_extended_replacement_cost_disc
    }
}
function getwaterAdjustedPremium(policy_fv,perils,exposure,policyExposurePerils,factors)
{
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let type_constant = ratingConstants.tableKeyConstants.water;
    let state = exposure_fv.property_state;
    let otherPerilLimits = ratingHelpers.getOtherPerilLimits(policyExposurePerils,perils);
    let cov_a_limit = otherPerilLimits.cov_a_limit;
    let deductible_limit = otherPerilLimits.aop_deductible;
    let ordinance_law_percentage = otherPerilLimits.ordinance_law_percentage;
    let water_base_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.base_rate_table),ratingConstants.tableKeyConstants.water));
    let water_territory_key = ratingConstants.tableKeyConstants.water + ratingConstants.tableKeyConstants.pipe + factors.territory_code;
    let water_territory_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.territory_factor_table),water_territory_key));
    water_territory_factor = !isNaN(water_territory_factor) ? water_territory_factor : ratingConstants.numberConstants.one;  ///saftey check so that premium is not zero.
    let water_nb_homebuyer_factor = ratingConstants.numberConstants.one;
    if(policy_fv.nb_homebuyer == ratingConstants.binaryConstants.yes)
    {
        water_nb_homebuyer_factor_key = policy_fv.months_owned + ratingConstants.tableKeyConstants.pipe + ratingConstants.exposureFieldValueConstants.water;
        water_nb_homebuyer_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.nb_home_buyer_rate_table),water_nb_homebuyer_factor_key));
    }
    let water_base_class_premium = (water_base_rate * water_territory_factor).round(2);
    let water_base_premium = water_base_class_premium * factors.form_factor; 
    let water_cov_a_ded_factor = ratingHelpers.interpolate(state,cov_a_limit,ratingConstants.tableNameConsts.water_cov_a_ded_factor_table,deductible_limit,type_constant);
        water_base_premium = parseFloat(water_base_premium * water_cov_a_ded_factor).round(2); 
        water_base_premium = parseFloat(water_base_premium * factors.num_of_families_factor).round(2);
        console.log("🚀 ~ file: adjustedBasePremium.js ~ line 102 ~ water_base_premium", water_base_premium)
    let water_adj_base_premium = parseFloat(water_base_premium * factors.ext_replacement_cost).round(2);  
    let water_extended_replacement_cost_disc = water_base_premium - water_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 114 ~ water_extended_replacement_cost_disc", water_extended_replacement_cost_disc)
        water_adj_base_premium = parseFloat(water_adj_base_premium * water_nb_homebuyer_factor).round(2);
        let water_nb_homebuyer_disc = parseFloat(water_base_premium * factors.ext_replacement_cost).round(2) - water_adj_base_premium;
        console.log("🚀 ~ file: adjustedBasePremium.js ~ line 104 ~ water_nb_homebuyer_disc", water_nb_homebuyer_disc)
    let water_mitigation_credit_factor = Math.max(factors.secondary_water_resistance_factor,ratingConstants.numberConstants.point_eight);
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 119 ~ water_mitigation_credit_factor", water_mitigation_credit_factor)
    // if(water_mitigation_credit_factor > ratingConstants.numberConstants.point_eight)
    // {
    //  socotraApi.setAuxData("MitigationCreditFactor","flag","Yes","normal");
    // }
    water_adj_base_premium = parseFloat(water_adj_base_premium * water_mitigation_credit_factor).round(2);
    let premium_with_mitigation_credit = water_adj_base_premium;
    let water_mitigation_credit_disc = parseFloat((water_base_premium * factors.ext_replacement_cost).round(2)* water_nb_homebuyer_factor).round(2) - water_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 112 ~ water_mitigation_credit_disc", water_mitigation_credit_disc)
    water_adj_base_premium = parseFloat(water_adj_base_premium * factors.Uw_tier_factor).round(2);
    let premium_with_Uw_tier = water_adj_base_premium;
    let water_uw_tier = premium_with_mitigation_credit - premium_with_Uw_tier;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 128 ~ water_uw_tier", water_uw_tier)
    water_adj_base_premium = parseFloat(water_adj_base_premium * factors.claims_free_discount_factor).round(2);
    let water_claims_free_disc = premium_with_Uw_tier - water_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 116 ~ water_claims_free_disc", water_claims_free_disc)
    let  water_ordinane_law_premium = ratingConstants.numberConstants.zero;
    let tableName = ratingConstants.tableNameConsts.ordinance_law_coverage_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let ordinance_law_factor = parseFloat(socotraApi.tableLookup(tableName, ordinance_law_percentage));
    water_ordinane_law_premium = water_base_premium;
    water_ordinane_law_premium = (parseFloat(ordinance_law_factor - 1) * water_ordinane_law_premium).round(2); 
    water_ordinane_law_premium = !isNaN(water_ordinane_law_premium) ? water_ordinane_law_premium : ratingConstants.numberConstants.zero;   
    water_adj_base_premium = (+water_adj_base_premium) + (+water_ordinane_law_premium);
    return {
        water_base_premium,
        water_adj_base_premium,
        water_nb_homebuyer_disc,
        water_mitigation_credit_disc,
        water_claims_free_disc,
        water_uw_tier,
        water_extended_replacement_cost_disc
    }
}
function getfireAdjustedPremium(policy_fv,perils,exposure,policyExposurePerils,factors)
{

    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 117 ~ exposure_fv", JSON.stringify(exposure_fv));
    
    let type_constant = ratingConstants.tableKeyConstants.fire;
    let state = exposure_fv.property_state;
    let otherPerilLimits = ratingHelpers.getOtherPerilLimits(policyExposurePerils,perils);
    let cov_a_limit = otherPerilLimits.cov_a_limit;
    let deductible_limit = otherPerilLimits.aop_deductible;
    let ordinance_law_percentage = otherPerilLimits.ordinance_law_percentage;
    let fire_base_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.base_rate_table),ratingConstants.tableKeyConstants.fire));
    let fire_territory_key = ratingConstants.tableKeyConstants.fire + ratingConstants.tableKeyConstants.pipe + factors.territory_code;
    let fire_territory_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.territory_factor_table),fire_territory_key));
    fire_territory_factor = !isNaN(fire_territory_factor) ? fire_territory_factor : ratingConstants.numberConstants.one;  ///saftey check so that premium is not zero.
    let fire_nb_homebuyer_factor = ratingConstants.numberConstants.one;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 150 ~ fire_territory_factor", fire_territory_factor)
    if(policy_fv.nb_homebuyer == ratingConstants.binaryConstants.yes)
    {
        fire_nb_homebuyer_factor_key = policy_fv.months_owned + ratingConstants.tableKeyConstants.pipe + ratingConstants.exposureFieldValueConstants.fire;
        fire_nb_homebuyer_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.nb_home_buyer_rate_table),fire_nb_homebuyer_factor_key));
        console.log("🚀 ~ file: adjustedBasePremium.js ~ line 155 ~ fire_nb_homebuyer_factor", fire_nb_homebuyer_factor)
    }
    let fire_base_class_premium = (fire_base_rate * fire_territory_factor).round(2);
    let fire_base_premium = (fire_base_class_premium * factors.form_factor).round(2); 
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 159 ~ fire_base_premium", fire_base_premium)
    let protection_Class = exposure_fv.protection_class;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 139 ~ protection_Class", protection_Class)
    let fire_prot_constr_factor_key = exposure_fv.protection_class + ratingConstants.tableKeyConstants.pipe + exposure_fv.contruction_type;  
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 136 ~ fire_prot_constr_factor_key", fire_prot_constr_factor_key)
    let fire_prot_constr_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.fire_prot_constr_factor_table),fire_prot_constr_factor_key));
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 137 ~ fire_prot_constr_factor", fire_prot_constr_factor)
    let fire_dpt_tax_credit_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.fire_department_tax_credit_factor_table),exposure_fv.property_city));
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 139 ~ fire_dpt_tax_credit_factor", fire_dpt_tax_credit_factor)
    fire_dpt_tax_credit_factor = !isNaN(fire_dpt_tax_credit_factor) ? fire_dpt_tax_credit_factor : ratingConstants.numberConstants.one;  //saftey check so that premium is not zero.
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 142 ~ fire_dpt_tax_credit_factor", fire_dpt_tax_credit_factor)
    fire_prot_constr_factor = fire_prot_constr_factor * fire_dpt_tax_credit_factor;
        console.log("🚀 ~ file: adjustedBasePremium.js ~ line 142 ~ fire_prot_constr_factor", fire_prot_constr_factor)
        fire_base_premium = parseFloat(fire_base_premium * fire_prot_constr_factor).round(2);
        let fire_dept_tax_credit_disc =  (fire_base_class_premium * factors.form_factor).round(2) - fire_base_premium;
        console.log("🚀 ~ file: adjustedBasePremium.js ~ line 147 ~ fire_base_premium", fire_base_premium)
    let fire_cov_a_ded_factor = ratingHelpers.interpolate(state,cov_a_limit,ratingConstants.tableNameConsts.fire_cov_a_ded_factor_table,deductible_limit,type_constant);
        fire_base_premium = parseFloat(fire_base_premium * fire_cov_a_ded_factor).round(2); 
        fire_base_premium = parseFloat(fire_base_premium * factors.num_of_families_factor).round(2);
    let fire_adj_base_premium = parseFloat(fire_base_premium * factors.ext_replacement_cost).round(2); 
    let fire_extended_replacement_cost_disc = fire_base_premium - fire_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 199 ~ fire_extended_replacement_cost_disc", fire_extended_replacement_cost_disc)
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 178 ~ fire_adj_base_premium", fire_adj_base_premium)
        fire_adj_base_premium = parseFloat(fire_adj_base_premium*fire_nb_homebuyer_factor).round(2);
        console.log("🚀 ~ file: adjustedBasePremium.js ~ line 194 ~ fire_adj_base_premium", fire_adj_base_premium)
    let fire_nb_homebuyer_disc =  parseFloat(fire_base_premium * factors.ext_replacement_cost).round(2) - fire_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 179 ~ fire_nb_homebuyer_disc", fire_nb_homebuyer_disc)
    let fire_mitigation_credit_factor = Math.max(factors.fortified_construction_factor,0.8);
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 197 ~ fire_mitigation_credit_factor", fire_mitigation_credit_factor)
    // if(fire_mitigation_credit_factor > ratingConstants.numberConstants.point_eight)
    // {
    //  socotraApi.setAuxData("MitigationCreditFactor","flag","Yes","normal");
    // }
    fire_adj_base_premium = parseFloat(fire_adj_base_premium * fire_mitigation_credit_factor).round(2);
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 203 ~ fire_adj_base_premium", fire_adj_base_premium)
    let premium_with_mitigation_credit = fire_adj_base_premium;
    let fire_mitigation_credit_disc =  parseFloat((fire_base_premium * factors.ext_replacement_cost).round(2) *fire_nb_homebuyer_factor).round(2) - fire_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 187 ~ fire_mitigation_credit_disc", fire_mitigation_credit_disc)
    fire_adj_base_premium = parseFloat(fire_adj_base_premium * factors.Uw_tier_factor).round(2);
    let premium_with_Uw_tier = fire_adj_base_premium;
    let fire_uw_tier = premium_with_mitigation_credit - fire_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 216 ~ fire_uw_tier", fire_uw_tier)
    fire_adj_base_premium = parseFloat(fire_adj_base_premium * factors.claims_free_discount_factor).round(2);
    let fire_claims_free_disc = premium_with_Uw_tier - fire_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 190 ~ fire_claims_free_disc", fire_claims_free_disc)
    let fire_ordinane_law_premium  = ratingConstants.numberConstants.zero;
    let tableName = ratingConstants.tableNameConsts.ordinance_law_coverage_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let ordinance_law_factor = parseFloat(socotraApi.tableLookup(tableName, ordinance_law_percentage));
    fire_ordinane_law_premium = fire_base_premium;
    fire_ordinane_law_premium = (parseFloat((ordinance_law_factor - 1) * fire_ordinane_law_premium)).round(2);
    fire_ordinane_law_premium = !isNaN(fire_ordinane_law_premium) ? fire_ordinane_law_premium : ratingConstants.numberConstants.zero;   
    fire_adj_base_premium = (+fire_adj_base_premium) + (+fire_ordinane_law_premium);
    return {
        fire_base_premium,
        fire_adj_base_premium,
        fire_nb_homebuyer_disc,
        fire_mitigation_credit_disc,
        fire_dept_tax_credit_disc,
        fire_claims_free_disc,
        fire_uw_tier,
        fire_extended_replacement_cost_disc
    }
}

function getTheftAdjustedPremium(policy_fv,perils,exposure,policyExposurePerils,factors)
{
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let type_constant = ratingConstants.tableKeyConstants.theft;
    let state = exposure_fv.property_state;
    let otherPerilLimits = ratingHelpers.getOtherPerilLimits(policyExposurePerils,perils);
    let cov_a_limit = otherPerilLimits.cov_a_limit;
    let deductible_limit = otherPerilLimits.aop_deductible;
    let theft_base_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.base_rate_table),ratingConstants.tableKeyConstants.theft));
    let theft_territory_key = ratingConstants.tableKeyConstants.theft + ratingConstants.tableKeyConstants.pipe + factors.territory_code;
    let theft_territory_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.territory_factor_table),theft_territory_key));
    theft_territory_factor = !isNaN(theft_territory_factor) ? theft_territory_factor : ratingConstants.numberConstants.one;  ///saftey check so that premium is not zero.
    let theft_nb_homebuyer_factor = ratingConstants.numberConstants.one;
    if(policy_fv.nb_homebuyer == ratingConstants.binaryConstants.yes)
    {
        theft_nb_homebuyer_factor_key = policy_fv.months_owned + ratingConstants.tableKeyConstants.pipe + ratingConstants.exposureFieldValueConstants.theft;
        theft_nb_homebuyer_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.nb_home_buyer_rate_table),theft_nb_homebuyer_factor_key));
    }
    let theft_base_class_premium = (theft_base_rate * theft_territory_factor).round(2);
    let theft_base_premium = theft_base_class_premium * factors.form_factor ; 
    let theft_cov_a_ded_factor = ratingHelpers.interpolate(state,cov_a_limit,ratingConstants.tableNameConsts.theft_cov_a_ded_factor_table,deductible_limit,type_constant);
        theft_base_premium = parseFloat(theft_base_premium * theft_cov_a_ded_factor).round(2);  
        theft_base_premium = parseFloat(theft_base_premium * factors.num_of_families_factor).round(2);
        console.log("🚀 ~ file: adjustedBasePremium.js ~ line 236 ~ theft_base_premium", theft_base_premium)
    let theft_adj_base_premium = parseFloat(theft_base_premium * theft_nb_homebuyer_factor).round(2);
    let premium_with_nb_homebuyer = theft_adj_base_premium;
    let theft_nb_homebuyer_disc =    theft_base_premium -  theft_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 234 ~ theft_nb_homebuyer_disc", theft_nb_homebuyer_disc)
    theft_adj_base_premium = parseFloat(theft_adj_base_premium * factors.Uw_tier_factor).round(2);
    let premium_with_Uw_tier = theft_adj_base_premium;
    theft_adj_base_premium = parseFloat(theft_adj_base_premium * factors.claims_free_discount_factor).round(2);
    let theft_claims_free_disc =   premium_with_Uw_tier - theft_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 238 ~ theft_claims_free_disc", theft_claims_free_disc)
    let theft_uw_tier = premium_with_nb_homebuyer - premium_with_Uw_tier;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 274 ~ theft_uw_tier", theft_uw_tier)
    return {
        theft_base_premium,
        theft_adj_base_premium,
        theft_nb_homebuyer_disc,
        theft_claims_free_disc,
        theft_uw_tier
    }
}

function getOtherAdjustedPremium(policy_fv,perils,exposure,policyExposurePerils,factors)
{
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let type_constant = ratingConstants.tableKeyConstants.other;
    let state = exposure_fv.property_state;
    let otherPerilLimits = ratingHelpers.getOtherPerilLimits(policyExposurePerils,perils);
    let cov_a_limit = otherPerilLimits.cov_a_limit;
    let deductible_limit = otherPerilLimits.aop_deductible;
    let ordinance_law_percentage = otherPerilLimits.ordinance_law_percentage;
    let other_base_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.base_rate_table),ratingConstants.tableKeyConstants.other));
    let other_territory_key = ratingConstants.tableKeyConstants.other + ratingConstants.tableKeyConstants.pipe + factors.territory_code;
    let other_territory_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.territory_factor_table),other_territory_key));
    other_territory_factor = !isNaN(other_territory_factor) ? other_territory_factor : ratingConstants.numberConstants.one;  ///saftey check so that premium is not zero.
    let other_nb_homebuyer_factor = ratingConstants.numberConstants.one;
    if(policy_fv.nb_homebuyer == ratingConstants.binaryConstants.yes)
    {
        other_nb_homebuyer_factor_key = policy_fv.months_owned + ratingConstants.tableKeyConstants.pipe + ratingConstants.exposureFieldValueConstants.other;
        other_nb_homebuyer_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.nb_home_buyer_rate_table),other_nb_homebuyer_factor_key));
    }
    let other_base_class_premium = (other_base_rate * other_territory_factor).round(2);
    let other_base_premium = other_base_class_premium * factors.form_factor ; 
    let other_cov_a_ded_factor = ratingHelpers.interpolate(state,cov_a_limit,ratingConstants.tableNameConsts.other_cov_a_ded_factor_table,deductible_limit,type_constant);
        other_base_premium = parseFloat(other_base_premium * other_cov_a_ded_factor).round(2);
        other_base_premium = parseFloat(other_base_premium * factors.num_of_families_factor).round(2);
        console.log("🚀 ~ file: adjustedBasePremium.js ~ line 276 ~ other_base_premium", other_base_premium)
    let other_adj_base_premium = parseFloat(other_base_premium * factors.ext_replacement_cost).round(2); 
    let other_extended_replacement_cost_disc = other_base_premium - other_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 314 ~ other_extended_replacement_cost_disc", other_extended_replacement_cost_disc)
        other_adj_base_premium = parseFloat(other_adj_base_premium* other_nb_homebuyer_factor).round(2);
        let other_nb_homebuyer_disc = parseFloat(other_base_premium * factors.ext_replacement_cost).round(2) - other_adj_base_premium;
        console.log("🚀 ~ file: adjustedBasePremium.js ~ line 274 ~ other_nb_homebuyer_disc", other_nb_homebuyer_disc)
    let other_mitigation_credit_factor = Math.max(factors.fortified_construction_factor,0.8);
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 320 ~ other_mitigation_credit_factor", other_mitigation_credit_factor)
    // if(other_mitigation_credit_factor > ratingConstants.numberConstants.point_eight)
    // {
    //  socotraApi.setAuxData("MitigationCreditFactor","flag","Yes","normal");
    // }
    other_adj_base_premium = parseFloat(other_adj_base_premium * other_mitigation_credit_factor).round(2);
    let premium_with_mitigation_credit = other_adj_base_premium;
    let other_mitigation_credit_disc = parseFloat((other_base_premium * factors.ext_replacement_cost).round(2)* other_nb_homebuyer_factor).round(2) - other_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 282 ~ other_mitigation_credit_disc", other_mitigation_credit_disc)
    other_adj_base_premium = parseFloat(other_adj_base_premium * factors.Uw_tier_factor).round(2);
    let premium_with_Uw_tier = other_adj_base_premium;
    let other_uw_tier =  premium_with_mitigation_credit -  premium_with_Uw_tier;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 326 ~ other_uw_tier", other_uw_tier)
    other_adj_base_premium = parseFloat(other_adj_base_premium * factors.claims_free_discount_factor).round(2);
    let other_claims_free_disc = premium_with_Uw_tier - other_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 286 ~ other_claims_free_disc", other_claims_free_disc)
    let other_ordinance_law_premium = ratingConstants.numberConstants.zero;
    let tableName = ratingConstants.tableNameConsts.ordinance_law_coverage_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let ordinance_law_factor = parseFloat(socotraApi.tableLookup(tableName, ordinance_law_percentage));
    other_ordinance_law_premium = other_base_premium;
    other_ordinance_law_premium = (parseFloat((ordinance_law_factor - 1) * other_ordinance_law_premium)).round(2);
    other_ordinance_law_premium = !isNaN(other_ordinance_law_premium) ? other_ordinance_law_premium : ratingConstants.numberConstants.zero;   
    other_adj_base_premium = (+other_adj_base_premium) + (+other_ordinance_law_premium);
    return {
        other_base_premium,
        other_adj_base_premium,
        other_nb_homebuyer_disc,
        other_mitigation_credit_disc,
        other_claims_free_disc,
        other_uw_tier,
        other_extended_replacement_cost_disc
    }
}

function getLiabilityAdjustedPremium(policy_fv,exposure,factors)
{
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let state = exposure_fv.property_state;
    let liability_base_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.base_rate_table),ratingConstants.tableKeyConstants.liability));
    let liability_territory_key = ratingConstants.tableKeyConstants.liability + ratingConstants.tableKeyConstants.pipe + factors.territory_code;
    let liability_territory_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.territory_factor_table),liability_territory_key));
    liability_territory_factor = !isNaN(liability_territory_factor) ? liability_territory_factor : ratingConstants.numberConstants.one;  ///saftey check so that premium is not zero.  
    let liability_nb_homebuyer_factor = ratingConstants.numberConstants.one;
    if(policy_fv.nb_homebuyer == ratingConstants.binaryConstants.yes)
    {
        liability_nb_homebuyer_factor_key = policy_fv.months_owned + ratingConstants.tableKeyConstants.pipe + ratingConstants.exposureFieldValueConstants.liability;
        liability_nb_homebuyer_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state,ratingConstants.tableNameConsts.nb_home_buyer_rate_table),liability_nb_homebuyer_factor_key));
    }
    let liability_base_class_premium = parseFloat(liability_base_rate * liability_territory_factor).round(2);
    let liability_base_premium = parseFloat(liability_base_class_premium * factors.num_of_families_factor).round(2) ; 
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 325 ~ liability_base_premium", liability_base_premium)
    let liability_adj_base_premium = parseFloat(liability_base_premium * factors.inc_cov_e_f_factor).round(2); 
    let increase_coverage_e_f = liability_base_premium - parseFloat(liability_base_premium * factors.inc_cov_e_f_factor).round(2);
    liability_adj_base_premium = parseFloat(liability_adj_base_premium * liability_nb_homebuyer_factor).round(2);
    let premium_with_nb_homebuyer = liability_adj_base_premium;
    let liability_nb_homebuyer_disc = liability_base_premium - liability_adj_base_premium
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 322 ~ liability_nb_homebuyer_disc", liability_nb_homebuyer_disc)
    liability_adj_base_premium = parseFloat(liability_adj_base_premium * factors.Uw_tier_factor).round(2);
    let premium_with_Uw_tier = liability_adj_base_premium;
    let liability_uw_tier =  premium_with_nb_homebuyer - premium_with_Uw_tier;
    liability_adj_base_premium = parseFloat(liability_adj_base_premium * factors.claims_free_discount_factor).round(2);
    let liability_claims_free_disc = premium_with_Uw_tier - liability_adj_base_premium;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 326 ~ liability_claims_free_disc", liability_claims_free_disc)
    return {
    liability_base_premium,
    liability_adj_base_premium,
    liability_nb_homebuyer_disc,
    liability_claims_free_disc,
    liability_uw_tier,
    increase_coverage_e_f
    }
}

function getAdjustedBasePremium(data,factors,policyLocator)
{
    let exposures = data.policy.exposures;
    let perils = exposures.flatMap((ex) => ex.perils);
    let exposure = exposures.find((e) => e.name == ratingConstants.exposureFieldValueConstants.dwelling);
    let policyExposurePerils = data.policyExposurePerils;
    let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
    let transactionLocator;
    let transactionType = data.operation;
    if(transactionType == "endorsement")
    {
        transactionLocator = data.endorsementLocator;
    }
    else if(transactionType == "renewal")
    {
        transactionLocator = data.renewalLocator;
    }

    let  windPremiums =  getWindAdjustedPremium(policy_fv,perils,exposure,policyExposurePerils,factors);
    let  waterPremiums = getwaterAdjustedPremium(policy_fv,perils,exposure,policyExposurePerils,factors);
    let  firePremiums  = getfireAdjustedPremium(policy_fv,perils,exposure,policyExposurePerils,factors);
    let  theftPremiums = getTheftAdjustedPremium(policy_fv,perils,exposure,policyExposurePerils,factors);
    let  otherPremiums = getOtherAdjustedPremium(policy_fv,perils,exposure,policyExposurePerils,factors);
    let  liabilityPremiums = getLiabilityAdjustedPremium(policy_fv,exposure,factors);

    let  windBasePremium =  windPremiums.wind_base_premium;
    let  waterBasePremium = waterPremiums.water_base_premium;
    let  fireBasePremium  = firePremiums.fire_base_premium;
    let  theftBasePremium = theftPremiums.theft_base_premium;
    let  otherBasePremium = otherPremiums.other_base_premium
    let  liabilityBasePremium = liabilityPremiums.liability_base_premium;

    let  wind_nb_homebuyer_disc = windPremiums.wind_nb_homebuyer_disc;
    let  water_nb_homebuyer_disc = waterPremiums.water_nb_homebuyer_disc;
    let  fire_nb_homebuyer_disc  = firePremiums.fire_nb_homebuyer_disc;
    let  theft_nb_homebuyer_disc = theftPremiums.theft_nb_homebuyer_disc;
    let  other_nb_homebuyer_disc = otherPremiums.other_nb_homebuyer_disc;
    let  liability_nb_homebuyer_disc =liabilityPremiums.liability_nb_homebuyer_disc;
    let  total_nb_homebuyer_disc = (wind_nb_homebuyer_disc + water_nb_homebuyer_disc + fire_nb_homebuyer_disc + theft_nb_homebuyer_disc + other_nb_homebuyer_disc + liability_nb_homebuyer_disc).round(2);
    if(data.operation == ratingConstants.operationConstants.new_business)
    {
      socotraApi.setAuxData(policyLocator, ratingConstants.auxDataConstants.nb_home_buyer, (total_nb_homebuyer_disc*-1) , ratingConstants.auxDataConstants.ui_type);
    }
    else
    {
       socotraApi.setAuxData(transactionLocator, ratingConstants.auxDataConstants.nb_home_buyer, (total_nb_homebuyer_disc*-1) , ratingConstants.auxDataConstants.ui_type);
    }

    let wind_mitigation_credit_disc = windPremiums.wind_mitigation_credit_disc;
    let water_mitigation_credit_disc = waterPremiums.water_mitigation_credit_disc;
    let fire_mitigation_credit_disc = firePremiums.fire_mitigation_credit_disc;
    let other_mitigation_credit_disc = otherPremiums.other_mitigation_credit_disc;
    let total_mitigation_credit_disc = (wind_mitigation_credit_disc + water_mitigation_credit_disc + fire_mitigation_credit_disc + other_mitigation_credit_disc).round(2);    
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 373 ~ total_mitigation_credit_disc", total_mitigation_credit_disc)
    if(data.operation == ratingConstants.operationConstants.new_business)
    {
        socotraApi.setAuxData(policyLocator, ratingConstants.auxDataConstants.mitigation_credit, (total_mitigation_credit_disc*-1) , ratingConstants.auxDataConstants.ui_type);
    }
    else
    {
        socotraApi.setAuxData(transactionLocator, ratingConstants.auxDataConstants.mitigation_credit, (total_mitigation_credit_disc*-1) , ratingConstants.auxDataConstants.ui_type);
    }

    let total_fire_dept_tax_credit_disc = (firePremiums.fire_dept_tax_credit_disc).round(2);
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 376 ~ total_fire_dept_tax_credit_disc", total_fire_dept_tax_credit_disc)
    if(data.operation == ratingConstants.operationConstants.new_business)
    {
        socotraApi.setAuxData(policyLocator, ratingConstants.auxDataConstants.fire_dept_tax_credit, (total_fire_dept_tax_credit_disc*-1) , ratingConstants.auxDataConstants.ui_type);
    }
    else
    {
        socotraApi.setAuxData(transactionLocator, ratingConstants.auxDataConstants.fire_dept_tax_credit, (total_fire_dept_tax_credit_disc*-1) , ratingConstants.auxDataConstants.ui_type);
    }

    let wind_claims_free_disc = windPremiums.wind_claims_free_disc;
    let water_claims_free_disc = waterPremiums.water_claims_free_disc;
    let fire_claims_free_disc = firePremiums.fire_claims_free_disc;
    let theft_claims_free_disc = theftPremiums.theft_claims_free_disc;
    let other_claims_free_disc = otherPremiums.other_claims_free_disc;
    let liability_claims_free_disc = liabilityPremiums.liability_claims_free_disc;
    let total_claims_free_discount_factor_disc = (wind_claims_free_disc + water_claims_free_disc + fire_claims_free_disc + theft_claims_free_disc + other_claims_free_disc + liability_claims_free_disc).round(2) ;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 386 ~ total_claims_free_discount_factor_disc", total_claims_free_discount_factor_disc)
    if(data.operation == ratingConstants.operationConstants.new_business)
    {
        socotraApi.setAuxData(policyLocator, ratingConstants.auxDataConstants.claims_free_discount, (total_claims_free_discount_factor_disc*-1) , ratingConstants.auxDataConstants.ui_type);
    }
    else
    {
        socotraApi.setAuxData(transactionLocator, ratingConstants.auxDataConstants.claims_free_discount, (total_claims_free_discount_factor_disc*-1) , ratingConstants.auxDataConstants.ui_type);
    }


    let wind_uw_tier = windPremiums.wind_uwTier;
    let water_uw_tier = waterPremiums.water_uw_tier;
    let fire_uw_tier = firePremiums.fire_uw_tier;
    let theft_uw_tier = theftPremiums.theft_uw_tier;
    let other_uw_tier = otherPremiums.other_uw_tier;
    let liability_uw_tier = liabilityPremiums.liability_uw_tier;
    let total_uw_tier = (wind_uw_tier + water_uw_tier +  fire_uw_tier + theft_uw_tier + other_uw_tier + liability_uw_tier).round(2);
    if(data.operation == ratingConstants.operationConstants.new_business)
    {
    socotraApi.setAuxData(policyLocator, ratingConstants.auxDataConstants.uw_tier, (total_uw_tier*-1) , ratingConstants.auxDataConstants.ui_type);
    }
    else
    {
    socotraApi.setAuxData(transactionLocator, ratingConstants.auxDataConstants.uw_tier, (total_nb_homebuyer_disc*-1) , ratingConstants.auxDataConstants.ui_type);
    }

    let wind_extended_replacement_cost_disc = windPremiums.wind_extended_replacement_cost_disc;
    let water_extended_replacement_cost_disc = waterPremiums.water_extended_replacement_cost_disc;
    let fire_extended_replacement_cost_disc = firePremiums.fire_extended_replacement_cost_disc;
    let other_extended_replacement_cost_disc = otherPremiums.other_extended_replacement_cost_disc;
    let total_ext_replacement_cost = (wind_extended_replacement_cost_disc + water_extended_replacement_cost_disc + fire_extended_replacement_cost_disc + other_extended_replacement_cost_disc).round(2);
    if(data.operation == ratingConstants.operationConstants.new_business)
    {
        socotraApi.setAuxData(policyLocator, ratingConstants.auxDataConstants.ext_replacement_cost, total_ext_replacement_cost , ratingConstants.auxDataConstants.ui_type);
    }
    else
    {
        socotraApi.setAuxData(transactionLocator, ratingConstants.auxDataConstants.ext_replacement_cost, total_ext_replacement_cost , ratingConstants.auxDataConstants.ui_type);
    }

    let total_base_premiums = windBasePremium + waterBasePremium + fireBasePremium + theftBasePremium + otherBasePremium + liabilityBasePremium ;
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 406 ~ total_base_premiums",  JSON.stringify(total_base_premiums))
    if(data.operation == ratingConstants.operationConstants.new_business)
    {
        socotraApi.setAuxData(policyLocator, ratingConstants.auxDataConstants.base_premium, total_base_premiums, ratingConstants.auxDataConstants.ui_type);
    }
    else
    {
        socotraApi.setAuxData(transactionLocator, ratingConstants.auxDataConstants.base_premium, total_base_premiums , ratingConstants.auxDataConstants.ui_type);
    }

    let increase_coverage_e_f = (liabilityPremiums.increase_coverage_e_f).round(2);
    if(data.operation == ratingConstants.operationConstants.new_business)
    {
        socotraApi.setAuxData(policyLocator, ratingConstants.auxDataConstants.increase_cov_e_f, increase_coverage_e_f , ratingConstants.auxDataConstants.ui_type);
    }
    else
    {
        socotraApi.setAuxData(transactionLocator, ratingConstants.auxDataConstants.increase_cov_e_f, increase_coverage_e_f , ratingConstants.auxDataConstants.ui_type);
    }

    let  windAdjPremium = windPremiums.wind_adj_base_premium;
    let  waterAdjPremium = waterPremiums.water_adj_base_premium;
    let  fireAdjPremium = firePremiums.fire_adj_base_premium;
    let  theftAdjPremium = theftPremiums.theft_adj_base_premium;
    let  otherAdjPremium = otherPremiums.other_adj_base_premium;
    let  liabilityAdjPremium = liabilityPremiums.liability_adj_base_premium;

    let total_adjusted_based_premium = (+windAdjPremium) + (+waterAdjPremium) + (+fireAdjPremium) + (+theftAdjPremium) + (+otherAdjPremium) + (+liabilityAdjPremium);
    let consoleLogArray = [
        "windAdjPremium:" +windAdjPremium,
        "waterAdjPremium:" +waterAdjPremium,
        "fireAdjPremium:"  +fireAdjPremium,
        "theftAdjPremium:" +theftAdjPremium,
        "otherAdjPremium:" +otherAdjPremium,
        "liabilityAdjPremium:" +liabilityAdjPremium,
        "windBasePremium:" +windBasePremium,
        "waterBasePremium:" +waterBasePremium,
        "fireBasePremium:" +fireBasePremium,
        "theftBasePremium:" +theftBasePremium,
        "otherBasePremium:" +otherBasePremium,
        "liabilityBasePremium:" +liabilityBasePremium,
        "total_adjusted_based_premium:" +total_adjusted_based_premium 
        
    ]
    console.log("🚀 ~ file: adjustedBasePremium.js ~ line 199 ~ consoleLogArray", consoleLogArray)
    return {
        windAdjPremium,
        waterAdjPremium,
        fireAdjPremium,
        theftAdjPremium,
        otherAdjPremium,
        liabilityAdjPremium,
        total_adjusted_based_premium,
        windBasePremium,
        waterBasePremium,
        fireBasePremium,
        theftBasePremium,
        otherBasePremium,
        liabilityBasePremium,
        
    };
}

exports.getAdjustedBasePremium = getAdjustedBasePremium;
exports.getLiabilityAdjustedPremium = getLiabilityAdjustedPremium;
exports.getOtherAdjustedPremium = getOtherAdjustedPremium;
exports.getTheftAdjustedPremium = getTheftAdjustedPremium;
exports.getfireAdjustedPremium = getfireAdjustedPremium;
exports.getwaterAdjustedPremium = getwaterAdjustedPremium;
exports.getWindAdjustedPremium = getWindAdjustedPremium;