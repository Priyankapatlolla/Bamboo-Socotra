let constantValues = require("../../ratingConstants.js");
let ratingHelpers = require("../../helpersRating.js");
let ratingCalculations = require("../../ratingCalculations.js")
ratingHelpers.roundToDecimalPlaces();
function getPremiumForPolicyTransitionCredit(policy_fv, peril, exposures, Premiums,FactorForPremium) {
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 5 ~ getPremiumForPolicyTransitionCredit ~ FactorForPremium", JSON.stringify(FactorForPremium));
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 5 ~ getPremiumForPolicyTransitionCredit ~ Premiums", JSON.stringify(Premiums));
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.policy_transaction_credit;
    tableName = ratingHelpers.getTableName(state, tableName);

    let wind_sub_total = FactorForPremium.wind_sub_total;
    let wind_pspt = wind_sub_total;

    let water_sub_total = FactorForPremium.water_sub_total;
    let water_backup_premium = Premiums.water_backup_sump_discharge_premium;
    let water_pspt = water_sub_total + water_backup_premium;
    
    let fire_sub_total = FactorForPremium.fire_sub_total;
    let fire_pspt = fire_sub_total;
    
    let theft_sub_total = FactorForPremium.theft_sub_total;
    let theft_pspt = theft_sub_total;
    
    let liability_sub_total = FactorForPremium.liability_sub_total; 

    let animal_liability_premium = parseFloat(Premiums.animal_liability_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 28 ~ getPremiumForPolicyTransitionCredit ~ animal_liability_premium", animal_liability_premium)
    let residence_held_in_trust_premium = parseFloat(Premiums.residence_held_in_trust_premium);  
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 30 ~ getPremiumForPolicyTransitionCredit ~ residence_held_in_trust_premium", residence_held_in_trust_premium)
    let student_away_from_home_premium = parseFloat(Premiums.student_away_from_home_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 32 ~ getPremiumForPolicyTransitionCredit ~ student_away_from_home_premium", student_away_from_home_premium)
    let other_locations_occupied_by_insured_premium = parseFloat(Premiums.other_locations_occupied_by_insured_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 34 ~ getPremiumForPolicyTransitionCredit ~ other_locations_occupied_by_insured_premium", other_locations_occupied_by_insured_premium)
    let liability_home_day_care_premium = parseFloat(Premiums.liability_home_day_care_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 36 ~ getPremiumForPolicyTransitionCredit ~ liability_home_day_care_premium", liability_home_day_care_premium)
    let personal_injury_premium= parseFloat(Premiums.personal_injury_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 38 ~ getPremiumForPolicyTransitionCredit ~ personal_injury_premium", personal_injury_premium)
    let liability_pspt = (liability_sub_total + animal_liability_premium + residence_held_in_trust_premium + student_away_from_home_premium + other_locations_occupied_by_insured_premium + liability_home_day_care_premium + personal_injury_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 34 ~ getPremiumForPolicyTransitionCredit ~ liability_pspt", liability_pspt)



    let other_sub_total = FactorForPremium.other_sub_total; 
    let other_pspt = other_sub_total;

    let misc_sub_total = FactorForPremium.misc_sub_total; 

    let service_line_coverage_premium = parseFloat(Premiums.service_line_coverage_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 44 ~ getPremiumForPolicyTransitionCredit ~ service_line_coverage_premium", service_line_coverage_premium)
    let equipment_breakdown_coverage_premium = parseFloat(Premiums.equipment_breakdown_coverage_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 45 ~ getPremiumForPolicyTransitionCredit ~ equipment_breakdown_coverage_premium", equipment_breakdown_coverage_premium)
    let business_property_premium = parseFloat(Premiums.business_property_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 48 ~ getPremiumForPolicyTransitionCredit ~ business_property_premium", business_property_premium)
    let loss_assessment_premium = parseFloat(Premiums.loss_assessment_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 50 ~ getPremiumForPolicyTransitionCredit ~ loss_assessment_premium", loss_assessment_premium)
    let specific_other_structure_premium = parseFloat(Premiums.specific_other_structure_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 52 ~ getPremiumForPolicyTransitionCredit ~ specific_other_structure_premium", specific_other_structure_premium)
    let unscheduled_fridge_property_premium  = parseFloat(Premiums.unscheduled_fridge_property_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 54 ~ getPremiumForPolicyTransitionCredit ~ unscheduled_fridge_property_premium", unscheduled_fridge_property_premium)
    let limited_special_computer_equipment_premium = parseFloat(Premiums.limited_special_computer_equipment_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 56 ~ getPremiumForPolicyTransitionCredit ~ limited_special_computer_equipment_premium", limited_special_computer_equipment_premium)
    let landlord_furnishings_premium = parseFloat(Premiums.landlord_furnishings_premium);  
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 58 ~ getPremiumForPolicyTransitionCredit ~ landlord_furnishings_premium", landlord_furnishings_premium)
    let assisted_living_care_premium  = parseFloat(Premiums.assisted_living_care_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 60 ~ getPremiumForPolicyTransitionCredit ~ assisted_living_care_premium", assisted_living_care_premium)
    let scheduled_golf_cart_premium = parseFloat(Premiums.scheduled_golf_cart_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 62 ~ getPremiumForPolicyTransitionCredit ~ scheduled_golf_cart_premium", scheduled_golf_cart_premium)
    let green_upgrades_premium = parseFloat(Premiums.green_upgrades_premium);  
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 64 ~ getPremiumForPolicyTransitionCredit ~ green_upgrades_premium", green_upgrades_premium)
    let misc_home_day_care_premium   = parseFloat(Premiums.misc_home_day_care_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 66 ~ getPremiumForPolicyTransitionCredit ~ misc_home_day_care_premium", misc_home_day_care_premium)
    let gold_package_credit = parseFloat(Premiums.gold_package_credit); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 68 ~ getPremiumForPolicyTransitionCredit ~ gold_package_credit", gold_package_credit)
    let platinum_package_credit   = parseFloat(Premiums.platinum_package_credit); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 70 ~ getPremiumForPolicyTransitionCredit ~ platinum_package_credit", platinum_package_credit)
    let personal_property_scheduled_premium = parseFloat(Premiums.personal_property_scheduled_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 79 ~ getPremiumForPolicyTransitionCredit ~ personal_property_scheduled_premium", personal_property_scheduled_premium)
    let inc_limits_of_liability_premium = parseFloat(Premiums.inc_limits_of_liability_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 81 ~ getPremiumForPolicyTransitionCredit ~ inc_limits_of_liability_premium", inc_limits_of_liability_premium)
    let misc_pspt = parseFloat(misc_sub_total + personal_property_scheduled_premium + business_property_premium + loss_assessment_premium + specific_other_structure_premium + inc_limits_of_liability_premium + unscheduled_fridge_property_premium + limited_special_computer_equipment_premium + landlord_furnishings_premium +
    assisted_living_care_premium + scheduled_golf_cart_premium + green_upgrades_premium + misc_home_day_care_premium + gold_package_credit + 
    platinum_package_credit);

    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 59 ~ getPremiumForPolicyTransitionCredit ~ misc_pspt", misc_pspt)



    let wind_pept = constantValues.numberConstants.zero;
    let water_pept = constantValues.numberConstants.zero;
    let fire_pept = constantValues.numberConstants.zero;
    let theft_pept = constantValues.numberConstants.zero;
    let liability_pept = constantValues.numberConstants.zero;
    let other_pept = constantValues.numberConstants.zero;

    let device_protection_premium = Premiums.device_protection_premium;
    let family_cyber_protection_premium = Premiums.family_cyber_protection_premium; 
    let misc_pept	=	parseFloat(service_line_coverage_premium + equipment_breakdown_coverage_premium + device_protection_premium + family_cyber_protection_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 74 ~ getPremiumForPolicyTransitionCredit ~ misc_pept", misc_pept)
    let term_after_transition = (policy_fv.term_after_transition >= 3) ? constantValues.tableKeyConstants.greater_than_equal_three : policy_fv.term_after_transition;
    let policy_transition_credit_lookup_key = term_after_transition + constantValues.tableKeyConstants.pipe + policy_fv.policy_transition;
    let policy_transition_credit_factor = parseFloat(socotraApi.tableLookup(tableName,policy_transition_credit_lookup_key ))

    let Wind_policy_transition_credit	=	parseFloat((wind_pspt * policy_transition_credit_factor ) - wind_pspt);

    let water_policy_transition_credit	=	parseFloat((water_pspt * policy_transition_credit_factor ) - water_pspt);
    
    let fire_policy_transition_credit	=	parseFloat((fire_pspt * policy_transition_credit_factor ) - fire_pspt);
    
    let theft_policy_transition_credit	=	parseFloat((theft_pspt * policy_transition_credit_factor ) - theft_pspt);
    
    let liability_policy_transition_credit	= parseFloat((liability_pspt * policy_transition_credit_factor ) - liability_pspt);
    
    let other_policy_transition_credit	=	parseFloat((other_pspt * policy_transition_credit_factor ) - other_pspt);
    
    let misc_policy_transition_credit	=	parseFloat((misc_pspt * policy_transition_credit_factor ) - misc_pspt);
    
    let total_policy_transition_premium	=	parseFloat(Wind_policy_transition_credit + water_policy_transition_credit + fire_policy_transition_credit +theft_policy_transition_credit +
    liability_policy_transition_credit + other_policy_transition_credit + misc_policy_transition_credit + wind_pept + water_pept + fire_pept + theft_pept + liability_pept + other_pept + misc_pept);

    let wind_total_premium = (parseFloat((wind_pspt * policy_transition_credit_factor) + wind_pept)).round(2);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 96 ~ getPremiumForPolicyTransitionCredit ~ wind_total_premium", wind_total_premium)
    let water_total_premium = (parseFloat((water_pspt * policy_transition_credit_factor) + water_pept)).round(2);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 98 ~ getPremiumForPolicyTransitionCredit ~ water_total_premium", water_total_premium)
    let fire_total_premium = (parseFloat((fire_pspt * policy_transition_credit_factor) + fire_pept)).round(2);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 100 ~ getPremiumForPolicyTransitionCredit ~ fire_total_premium", fire_total_premium)
    let theft_total_premium = (parseFloat((theft_pspt * policy_transition_credit_factor) + theft_pept)).round(2);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 102 ~ getPremiumForPolicyTransitionCredit ~ theft_total_premium", theft_total_premium)
    let liability_total_premium = (parseFloat((liability_pspt * policy_transition_credit_factor) + liability_pept)).round(2);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 104 ~ getPremiumForPolicyTransitionCredit ~ liability_total_premium", liability_total_premium)
    let other_total_premium = (parseFloat((other_pspt * policy_transition_credit_factor) + other_pept)).round(2);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 106 ~ getPremiumForPolicyTransitionCredit ~ other_total_premium", other_total_premium)
    let misc_total_premium = (parseFloat((misc_pspt * policy_transition_credit_factor) + misc_pept)).round(2);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 108 ~ getPremiumForPolicyTransitionCredit ~ misc_total_premium", misc_total_premium)

    let total_premium = (wind_total_premium + water_total_premium + fire_total_premium + theft_total_premium + liability_total_premium + other_total_premium + misc_total_premium).round(2);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 128 ~ getPremiumForPolicyTransitionCredit ~ total_premium", total_premium)
    return total_policy_transition_premium;
}
    


function getPremiumForDiscountsAndMinPremium(peril, exposures, policy_fv, Premiums, FactorForPremium , adjustedBasePremiums ,policyLocator, transactionType, transactionLocator) {

    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.multi_policy_discount_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let multi_policy_type = policy_fv.multi_policy_type;
    let all_electronic = policy_fv.all_electronic;



    let wind_adjusted_base_premium = adjustedBasePremiums.windAdjPremium;
    let wind_age_of_home_remodeled_premium =   parseFloat(FactorForPremium.wind_age_of_home_remoulded_premium); 
    let acv_wind_hail_roof_loss_preimum =  parseFloat(Premiums.wind_hail_roof_loss_premium); 
    let wind_secondary_home_charge  =  parseFloat(FactorForPremium.wind_secondary_home_charge); 
    let test = FactorForPremium.wind_personal_prop_rcv_premium
    let wind_personal_prop_replacement_cost_premium =  parseFloat(FactorForPremium.wind_personal_prop_rcv_premium); 
    let acv_roof_premium =  parseFloat(Premiums.actual_cash_value_roof_premium); 
    let wind_replacement_cost_nonbldg_struct_premium =  parseFloat(FactorForPremium.wind_replace_cost_nonbldg_struct_premium); 
    let wind_sub_total	= (wind_adjusted_base_premium + wind_age_of_home_remodeled_premium + acv_wind_hail_roof_loss_preimum + wind_secondary_home_charge  + wind_personal_prop_replacement_cost_premium +  acv_roof_premium + wind_replacement_cost_nonbldg_struct_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 161 ~ getPremiumForDiscountsAndMinPremium ~ wind_sub_total", wind_sub_total)

    let water_adjusted_base_premium = parseFloat(adjustedBasePremiums.waterAdjPremium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 162 ~ getPremiumForDiscountsAndMinPremium ~ water_adjusted_base_premium", water_adjusted_base_premium)
    let water_credits_on_abp = parseFloat(FactorForPremium.water_credits_on_abp);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 164 ~ getPremiumForDiscountsAndMinPremium ~ water_credits_on_abp", water_credits_on_abp)
    let water_age_of_home_remodeled_premium = parseFloat(FactorForPremium.water_age_of_home_remoulded_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 166 ~ getPremiumForDiscountsAndMinPremium ~ water_age_of_home_remodeled_premium", water_age_of_home_remodeled_premium)
    let limited_fungi_premium = parseFloat(Premiums.limited_fungi_microbes_coverage_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 168 ~ getPremiumForDiscountsAndMinPremium ~ limited_fungi_premium", limited_fungi_premium)
    let water_secondary_home_charge =  parseFloat(FactorForPremium.water_secondary_home_charge); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 170 ~ getPremiumForDiscountsAndMinPremium ~ water_secondary_home_charge", water_secondary_home_charge)
    let water_personal_prop_replacement_cost_premium = parseFloat(FactorForPremium.water_personal_prop_rcv_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 172 ~ getPremiumForDiscountsAndMinPremium ~ water_personal_prop_replacement_cost_premium", water_personal_prop_replacement_cost_premium)
    let water_replacement_cost_nonBldg_struct_premium = parseFloat(FactorForPremium.water_replace_cost_nonbldg_struct_premium); 
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 174 ~ getPremiumForDiscountsAndMinPremium ~ water_replacement_cost_nonBldg_struct_premium", water_replacement_cost_nonBldg_struct_premium)
    let water_sub_total	=	(water_adjusted_base_premium + water_credits_on_abp + water_age_of_home_remodeled_premium + limited_fungi_premium + water_secondary_home_charge +  water_personal_prop_replacement_cost_premium + water_replacement_cost_nonBldg_struct_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 176 ~ getPremiumForDiscountsAndMinPremium ~ water_sub_total", water_sub_total)

    let fire_adjusted_base_premium = parseFloat(adjustedBasePremiums.fireAdjPremium); 
    let fire_credits_on_abp = parseFloat(FactorForPremium.fire_credits_on_abp); 
    let fire_Age_of_home_remodeled_premium = parseFloat(FactorForPremium.fire_age_of_home_remoulded_premium); 
    let fire_secondary_home_charge = parseFloat(FactorForPremium.fire_secondary_home_charge); 
    let townhouse_premium = parseFloat(Premiums.townhouse_row_house_premium);
    let fire_Personal_prop_replacement_cost_premium = parseFloat(FactorForPremium.fire_personal_prop_rcv_premium); 
    let fire_replacement_cost_nonBldg_struct_premium = parseFloat(FactorForPremium.fire_replace_cost_nonbldg_struct_premium); 
    let fire_sub_total = (fire_adjusted_base_premium + fire_credits_on_abp  +  fire_Age_of_home_remodeled_premium + fire_secondary_home_charge + townhouse_premium  + fire_Personal_prop_replacement_cost_premium + fire_replacement_cost_nonBldg_struct_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 187 ~ getPremiumForDiscountsAndMinPremium ~ fire_sub_total", fire_sub_total)

    let theft_adjusted_base_premium = parseFloat(adjustedBasePremiums.theftAdjPremium); 
    let theft_credits_on_abp = parseFloat(FactorForPremium.theft_credits_on_abp); 
    let theft_age_of_home_remodeled_premium = parseFloat(FactorForPremium.theft_age_of_home_remoulded_premium);
    let theft_secondary_home_charge = parseFloat(FactorForPremium.theft_secondary_home_charge); 
    let theft_personal_prop_replacement_cost_premium = parseFloat(FactorForPremium.theft_personal_prop_rcv_premium); 
    let theft_replacement_cost_nonbldg_struct_premium = parseFloat(FactorForPremium.theft_replace_cost_nonbldg_struct_premium); 
    let theft_sub_total	=	(theft_adjusted_base_premium + theft_credits_on_abp + theft_age_of_home_remodeled_premium + theft_secondary_home_charge + theft_personal_prop_replacement_cost_premium + theft_replacement_cost_nonbldg_struct_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 196 ~ getPremiumForDiscountsAndMinPremium ~ theft_sub_total", theft_sub_total)

    let liability_adjusted_base_premium = parseFloat(adjustedBasePremiums.liabilityAdjPremium); 
    let liability_age_of_home_remodeled_premium = parseFloat(FactorForPremium.liability_age_of_home_remoulded_premium); 
    let liability_secondary_home_charge= parseFloat(FactorForPremium.liability_secondary_home_charge); 
    let liability_sub_total	=	(liability_adjusted_base_premium + liability_age_of_home_remodeled_premium + liability_secondary_home_charge);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 185 ~ getPremiumForDiscountsAndMinPremium ~ liability_sub_total", liability_sub_total)

    let other_adjusted_base_premium= parseFloat(adjustedBasePremiums.otherAdjPremium); 
    let other_age_of_home_remodeled_premium = parseFloat(FactorForPremium.other_age_of_home_remoulded_premium); 
    let other_secondary_home_charge = parseFloat(FactorForPremium.other_secondary_home_charge);
    let other_personal_prop_replacement_cost_premium = parseFloat(FactorForPremium.other_personal_prop_rcv_premium); 
    let other_replacement_cost_nonbldg_struct_premium = parseFloat(FactorForPremium.other_replace_cost_nonbldg_struct_premium); 
    let other_sub_total	=	(other_adjusted_base_premium + other_age_of_home_remodeled_premium + other_secondary_home_charge + other_personal_prop_replacement_cost_premium + other_replacement_cost_nonbldg_struct_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 210 ~ getPremiumForDiscountsAndMinPremium ~ other_sub_total", other_sub_total)

    let increase_decrease_cov_b_premium = parseFloat(Premiums.increase_decrease_coverage_B_Premium);   
    let increase_decrease_cov_c_premium = parseFloat(Premiums.increase_decrease_coverage_C_premium);
    let increase_decrease_cov_d_premium = parseFloat(Premiums.increase_decrease_coverage_D_premium);
    let misc_sub_total	=	(increase_decrease_cov_b_premium + increase_decrease_cov_c_premium + increase_decrease_cov_d_premium);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 216 ~ getPremiumForDiscountsAndMinPremium ~ misc_sub_total", misc_sub_total)

    let multi_policy_discount_factor = parseFloat(socotraApi.tableLookup(tableName,multi_policy_type))
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 200 ~ getPremiumForDiscountsAndMinPremium ~ multi_policy_discount_factor", multi_policy_discount_factor)
    let wind_multi_policy_discount	=	((parseFloat((multi_policy_discount_factor) * wind_sub_total)).round(constantValues.numberConstants.two))*-1;
    let water_multi_policy_discount	=	((parseFloat((multi_policy_discount_factor) * water_sub_total)).round(constantValues.numberConstants.two))*-1;
    let fire_multi_policy_discount	=	((parseFloat((multi_policy_discount_factor) * fire_sub_total)).round(constantValues.numberConstants.two))*-1;
    let theft_multi_policy_discount	=	((parseFloat((multi_policy_discount_factor) * theft_sub_total)).round(constantValues.numberConstants.two))*-1;
    let liability_multi_policy_discount	=	(parseFloat((multi_policy_discount_factor) * liability_sub_total).round(constantValues.numberConstants.two))*-1;
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 206 ~ getPremiumForDiscountsAndMinPremium ~ liability_multi_policy_discount", liability_multi_policy_discount)
    let other_multi_policy_discount	=	((parseFloat((multi_policy_discount_factor) * other_sub_total)).round(constantValues.numberConstants.two))*-1;
    let misc_multi_policy_discount	=	((parseFloat((multi_policy_discount_factor) * misc_sub_total)).round(constantValues.numberConstants.two))*-1;
    let total_multi_policy_discount	=	 parseFloat(wind_multi_policy_discount + water_multi_policy_discount + fire_multi_policy_discount + theft_multi_policy_discount + liability_multi_policy_discount + other_multi_policy_discount + misc_multi_policy_discount)
    if(transactionType == constantValues.operationConstants.new_business)
    socotraApi.setAuxData(policyLocator, "TotalMultiPolicyDiscount", total_multi_policy_discount.round(2) , constantValues.auxDataConstants.ui_type);
    else
    socotraApi.setAuxData(transactionLocator, "TotalMultiPolicyDiscount", total_multi_policy_discount.round(2) , constantValues.auxDataConstants.ui_type);
    let electronic_discount_factor_table_name = constantValues.tableNameConsts.all_electronic_discount_table;
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 227 ~ getPremiumForDiscountsAndMinPremium ~ electronic_discount_factor_table_name", electronic_discount_factor_table_name)
    electronic_discount_factor_table_name = ratingHelpers.getTableName(state, electronic_discount_factor_table_name);

    let all_electronic_discount_factor  = parseFloat(socotraApi.tableLookup(electronic_discount_factor_table_name,all_electronic))
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 213 ~ getPremiumForDiscountsAndMinPremium ~ all_electronic_discount_factor", all_electronic_discount_factor)
    let wind_all_electronic_discount	=	(parseFloat((all_electronic_discount_factor)* wind_sub_total).round(constantValues.numberConstants.two))*-1;
    let water_all_electronic_discount	=	(parseFloat((all_electronic_discount_factor)* water_sub_total).round(constantValues.numberConstants.two))*-1;
    let Fire_all_electronic_discount	=	(parseFloat((all_electronic_discount_factor)* fire_sub_total).round(constantValues.numberConstants.two))*-1;
    let theft_all_electronic_discount	=	(parseFloat((all_electronic_discount_factor)* theft_sub_total).round(constantValues.numberConstants.two))*-1;
    let liability_all_electronic_discount	=	(parseFloat((all_electronic_discount_factor)* liability_sub_total).round(constantValues.numberConstants.two))*-1;
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 221 ~ getPremiumForDiscountsAndMinPremium ~ liability_all_electronic_discount", liability_all_electronic_discount)
    let other_all_electronic_discount	=	(parseFloat((all_electronic_discount_factor)* other_sub_total).round(constantValues.numberConstants.two))*-1;
    let Misc_all_electronic_discount	=	(parseFloat((all_electronic_discount_factor)* misc_sub_total).round(constantValues.numberConstants.two))*-1;
    let total_all_electronic_discount	=	 parseFloat(wind_all_electronic_discount + water_all_electronic_discount + Fire_all_electronic_discount + theft_all_electronic_discount + liability_all_electronic_discount + other_all_electronic_discount + Misc_all_electronic_discount)
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 240 ~ getPremiumForDiscountsAndMinPremium ~ total_all_electronic_discount", total_all_electronic_discount)
    if(transactionType == constantValues.operationConstants.new_business)
    socotraApi.setAuxData(policyLocator, "TotalAllElectronicDiscount", total_all_electronic_discount.round(2) , constantValues.auxDataConstants.ui_type);
    else
    socotraApi.setAuxData(transactionLocator, "TotalAllElectronicDiscount", total_all_electronic_discount.round(2) , constantValues.auxDataConstants.ui_type);
   
   
    wind_sub_total	=  (+wind_sub_total) + (+wind_multi_policy_discount) + (+wind_all_electronic_discount);
    water_sub_total	=  (+water_sub_total) + (+water_multi_policy_discount) + (+water_all_electronic_discount);
    fire_sub_total	=  (+fire_sub_total) + (+fire_multi_policy_discount) + (+Fire_all_electronic_discount);
    theft_sub_total	=  (+theft_sub_total) + (+theft_multi_policy_discount) + (+theft_all_electronic_discount);
    liability_sub_total	=  (+liability_sub_total) + (+liability_multi_policy_discount) + (+liability_all_electronic_discount);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 226 ~ getPremiumForDiscountsAndMinPremium ~ liability_sub_total", liability_sub_total)
    other_sub_total	=   (+other_sub_total) + (+other_multi_policy_discount) + (+other_all_electronic_discount);
    misc_sub_total	=   (+misc_sub_total) + (+misc_multi_policy_discount) + (+Misc_all_electronic_discount);
    let sub_total	=	parseFloat(wind_sub_total + water_sub_total + fire_sub_total +  theft_sub_total +  liability_sub_total +  other_sub_total +  misc_sub_total);

    let min_prem_table_name = constantValues.tableNameConsts.min_prem_table;
    min_prem_table_name = ratingHelpers.getTableName(state, min_prem_table_name);

    let wind_min_prem = parseFloat(socotraApi.tableLookup(min_prem_table_name,constantValues.tableKeyConstants.wind))
    let water_min_prem = parseFloat(socotraApi.tableLookup(min_prem_table_name,constantValues.tableKeyConstants.water))
    let Fire_min_prem = parseFloat(socotraApi.tableLookup(min_prem_table_name,constantValues.tableKeyConstants.fire))
    let theft_min_prem = parseFloat(socotraApi.tableLookup(min_prem_table_name,constantValues.tableKeyConstants.theft))
    let liability_min_prem = parseFloat(socotraApi.tableLookup(min_prem_table_name,constantValues.tableKeyConstants.liability))
    let other_min_prem = parseFloat(socotraApi.tableLookup(min_prem_table_name,constantValues.tableKeyConstants.other))
    let Misc_min_prem = 0 ;// parseFloat(socotraApi.tableLookup(min_prem_table_name,constantValues.tableKeyConstants.misc))   // updated key as 0
    let wind_min_prem_adjustment	= parseFloat(Math.max(wind_sub_total,wind_min_prem)- wind_sub_total)
    let water_min_prem_adjustment	= parseFloat(Math.max(water_sub_total,water_min_prem)- water_sub_total)
    let Fire_min_prem_adjustment	= parseFloat(Math.max(fire_sub_total,Fire_min_prem) - fire_sub_total)
    let theft_min_prem_adjustment	= parseFloat(Math.max( theft_sub_total,theft_min_prem)- theft_sub_total)
    let liability_min_prem_adjustment	=  parseFloat(Math.max( liability_sub_total,liability_min_prem)- liability_sub_total)
    let other_min_prem_adjustment	=	parseFloat(Math.max( other_sub_total,other_min_prem)- other_sub_total)
    let Misc_min_prem_adjustment	= parseFloat(Math.max( misc_sub_total,Misc_min_prem)- misc_sub_total)
    let total_min_prem_adjustment	= parseFloat(wind_min_prem_adjustment + water_min_prem_adjustment + Fire_min_prem_adjustment + theft_min_prem_adjustment + liability_min_prem_adjustment + other_min_prem_adjustment + Misc_min_prem_adjustment)
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 248 ~ getPremiumForDiscountsAndMinPremium ~ total_min_prem_adjustment", total_min_prem_adjustment)
    
    let wind_annual_basic_premium	= parseFloat(+wind_sub_total + wind_min_prem_adjustment)
    let water_annual_basic_premium	= parseFloat(water_sub_total + water_min_prem_adjustment)
    let Fire_annual_basic_premium	= parseFloat(fire_sub_total + Fire_min_prem_adjustment)
    let theft_annual_basic_premium	= parseFloat(theft_sub_total + theft_min_prem_adjustment)
    let liability_annual_basic_premium	= parseFloat(liability_sub_total + liability_min_prem_adjustment)
    let other_annual_basic_premium	= parseFloat(other_sub_total + other_min_prem_adjustment)
    let Misc_annual_basic_premium	= parseFloat(misc_sub_total + Misc_min_prem_adjustment)
    let total_annual_basic_premium	= (wind_annual_basic_premium + water_annual_basic_premium + Fire_annual_basic_premium + theft_annual_basic_premium + liability_annual_basic_premium + other_annual_basic_premium + Misc_annual_basic_premium).round(2);
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 257 ~ getPremiumForDiscountsAndMinPremium ~ total_annual_basic_premium", total_annual_basic_premium)
    

    let consoleLogArray = [
        "wind_sub_total:"+wind_sub_total,
        "water_sub_total:"+water_sub_total,
        "fire_sub_total:"+fire_sub_total,
        "theft_sub_total:"+theft_sub_total,
        "liability_sub_total:"+liability_sub_total,
        "other_sub_total"+other_sub_total,
        "misc_sub_total"+misc_sub_total,
        "total_min_prem_adjustment"+total_min_prem_adjustment,
        "total_annual_basic_premium"+total_annual_basic_premium,
        "wind_annual_basic_premium"+wind_annual_basic_premium,
        "water_annual_basic_premium"+water_annual_basic_premium,
        "Fire_annual_basic_premium"+Fire_annual_basic_premium,
        "theft_annual_basic_premium"+theft_annual_basic_premium,
        "liability_annual_basic_premium"+liability_annual_basic_premium,
        "other_annual_basic_premium"+other_annual_basic_premium,
        "Misc_annual_basic_premium"+Misc_annual_basic_premium,     
    ]
    console.log("🚀 ~ file: plcPremiumComputations2.js ~ line 254 ~ getPremiumForDiscountsAndMinPremium ~ consoleLogArray", consoleLogArray)
    return{
        wind_sub_total,
        water_sub_total,
        fire_sub_total,
        theft_sub_total,
        liability_sub_total,
        other_sub_total,
        misc_sub_total,
        total_min_prem_adjustment,
        total_annual_basic_premium
    } ;
}

exports.getPremiumForPolicyTransitionCredit = getPremiumForPolicyTransitionCredit;
exports.getPremiumForDiscountsAndMinPremium = getPremiumForDiscountsAndMinPremium;