let ratingHelpers = require("../../helpersRating.js");
let constantValues = require("../../ratingConstants.js");
let dwellingCoverages1 = require("../../exposures/dwelling/dwellingCoverages1.js")
let dwellingCoverages2 = require("../../exposures/dwelling/dwellingCoverages2.js")
ratingHelpers.roundToDecimalPlaces();

function getPremiumForSchedulePersonalProperty(peril, exposures,policyLocator, transactionType, transactionLocator) {
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.scheduled_pp_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let agreedtableName = constantValues.tableNameConsts.scheduled_pp_agreed_value_table;
    agreedtableName = ratingHelpers.getTableName(state, agreedtableName);
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    let peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;
    let schedule_personal_property_groups = peril_fv.scheduled_personal_property;
    let cameras_premium = constantValues.numberConstants.zero;
    let coins_premium = constantValues.numberConstants.zero;
    let fine_arts_premium = constantValues.numberConstants.zero;
    let fine_arts_breakage_premium = constantValues.numberConstants.zero;
    let furs_premium = constantValues.numberConstants.zero;
    let golf_equipment_premium = constantValues.numberConstants.zero;
    let jewelry_premium = constantValues.numberConstants.zero;
    let musical_instruments_premium = constantValues.numberConstants.zero;
    let silverware_premium = constantValues.numberConstants.zero;
    let stamps_premium = constantValues.numberConstants.zero;
    let cameras_agreed_value_factor = constantValues.numberConstants.one;
    let coins_agreed_value_factor = constantValues.numberConstants.one;
    let fine_arts_value_factor = constantValues.numberConstants.one;
    let fine_arts_breakage_value_factor = constantValues.numberConstants.one;
    let furs_agreed_value_factor = constantValues.numberConstants.one;
    let golf_equip_agreed_value_factor = constantValues.numberConstants.one;
    let jewelry_agreed_value_factor = constantValues.numberConstants.one;
    let musical_instruments_agreed_value_factor = constantValues.numberConstants.one;
    let silverware_agreed_value_factor = constantValues.numberConstants.one;
    let stamps_agreed_value_factor = constantValues.numberConstants.one;
    let scheduled_personal_property_table_value;
    let total_standard_sum = constantValues.numberConstants.zero;
    let total_agreed_sum = constantValues.numberConstants.zero;

    let standard_cameras_premium = constantValues.numberConstants.zero;
    let standard_coins_premium = constantValues.numberConstants.zero;
    let standard_fine_arts_premium = constantValues.numberConstants.zero;
    let standard_fine_arts_breakage_premium= constantValues.numberConstants.zero;
    let standard_furs_premium= constantValues.numberConstants.zero;
    let standard_golf_equipment_premium= constantValues.numberConstants.zero;
    let standard_jewelry_premium= constantValues.numberConstants.zero;
    let standard_musical_instruments_premium = constantValues.numberConstants.zero;
    let standard_silverware_premium = constantValues.numberConstants.zero;
    let standard_stamps_premium = constantValues.numberConstants.zero;
    let agreed_value_cameras_premium = constantValues.numberConstants.zero;
    let agreed_value_coins_premium = constantValues.numberConstants.zero;
    let agreed_value_fine_arts_premium = constantValues.numberConstants.zero;
    let agreed_value_fine_arts_breakage_premium = constantValues.numberConstants.zero;
    let agreed_value_furs_premium = constantValues.numberConstants.zero;
    let agreed_value_golf_equipment_premium = constantValues.numberConstants.zero;
    let agreed_value_jewelry_premium = constantValues.numberConstants.zero;
    let agreed_value_musical_instruments_premium = constantValues.numberConstants.zero;
    let agreed_value_silverware_premium = constantValues.numberConstants.zero;
    let agreed_value_stamps_premium = constantValues.numberConstants.zero;
    let Locator;
    if(transactionType == constantValues.operationConstants.new_business)
    {
        Locator = policyLocator;
    }
    else
    {
        Locator = transactionLocator;
    }
    for (let schedule_personal_property_group of schedule_personal_property_groups) {
        let scheduled_personal_property_type = peril_fgv[schedule_personal_property_group].scheduled_personal_property_type;
        let scheduled_personal_property_limit = parseFloat(ratingHelpers.removeSpecialCharacters(peril_fgv[schedule_personal_property_group].scheduled_personal_property_limit));
        let scheduled_personal_property_agreed_value = peril_fgv[schedule_personal_property_group].scheduled_personal_property_agreed_value;
        if (scheduled_personal_property_type == constantValues.perilValueConstansts.cameras) {
            scheduled_personal_property_table_value = parseFloat(socotraApi.tableLookup(tableName, scheduled_personal_property_type));
            cameras_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            standard_cameras_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            total_standard_sum += standard_cameras_premium;
            if (scheduled_personal_property_agreed_value == constantValues.binaryConstants.yes) {
                cameras_agreed_value_factor = parseFloat(socotraApi.tableLookup(agreedtableName, scheduled_personal_property_type));
                cameras_premium = cameras_premium * cameras_agreed_value_factor;
                agreed_value_cameras_premium += (cameras_agreed_value_factor * scheduled_personal_property_limit)/constantValues.numberConstants.one_thousand;
                total_agreed_sum += agreed_value_cameras_premium;
            }
        }
        else if (scheduled_personal_property_type == constantValues.perilValueConstansts.coins) {
            scheduled_personal_property_table_value = parseFloat(socotraApi.tableLookup(tableName, scheduled_personal_property_type));
            coins_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            standard_coins_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;   
            total_standard_sum += standard_coins_premium;
            if (scheduled_personal_property_agreed_value == constantValues.binaryConstants.yes) {
                coins_agreed_value_factor = parseFloat(socotraApi.tableLookup(agreedtableName, scheduled_personal_property_type));
                console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 94 ~ getPremiumForSchedulePersonalProperty ~ coins_agreed_value_factor", coins_agreed_value_factor)
                console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 97 ~ getPremiumForSchedulePersonalProperty ~ scheduled_personal_property_limit", scheduled_personal_property_limit)
                coins_premium = coins_premium * coins_agreed_value_factor;
                agreed_value_coins_premium += (coins_agreed_value_factor * scheduled_personal_property_limit)/constantValues.numberConstants.one_thousand;
                total_agreed_sum+= agreed_value_coins_premium;
            }
        }
        else if (scheduled_personal_property_type == constantValues.perilValueConstansts.fine_arts) {
            scheduled_personal_property_table_value = parseFloat(socotraApi.tableLookup(tableName, scheduled_personal_property_type));
            fine_arts_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            standard_fine_arts_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            total_standard_sum += standard_fine_arts_premium;
            if (scheduled_personal_property_agreed_value == constantValues.binaryConstants.yes) {
                fine_arts_value_factor = parseFloat(socotraApi.tableLookup(agreedtableName, scheduled_personal_property_type));
                fine_arts_premium = fine_arts_premium * fine_arts_value_factor;
                agreed_value_fine_arts_premium += (fine_arts_value_factor * scheduled_personal_property_limit)/constantValues.numberConstants.one_thousand;
                total_agreed_sum += agreed_value_fine_arts_premium;
            } 
        }
        else if (scheduled_personal_property_type == constantValues.perilValueConstansts.fine_arts_brekage) {
            scheduled_personal_property_table_value = parseFloat(socotraApi.tableLookup(tableName, scheduled_personal_property_type));
            fine_arts_breakage_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            standard_fine_arts_breakage_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            total_standard_sum += standard_fine_arts_breakage_premium;
            if (scheduled_personal_property_agreed_value == constantValues.binaryConstants.yes) {
                fine_arts_breakage_value_factor = parseFloat(socotraApi.tableLookup(agreedtableName, scheduled_personal_property_type));
                fine_arts_breakage_premium = fine_arts_breakage_premium * fine_arts_breakage_value_factor;
                agreed_value_fine_arts_breakage_premium += (fine_arts_breakage_value_factor * scheduled_personal_property_limit)/constantValues.numberConstants.one_thousand;
                total_agreed_sum += agreed_value_fine_arts_breakage_premium;
            }
        }
        else if (scheduled_personal_property_type == constantValues.perilValueConstansts.furs) {
            scheduled_personal_property_table_value = parseFloat(socotraApi.tableLookup(tableName, scheduled_personal_property_type));
            furs_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            standard_furs_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand; 
            total_standard_sum += standard_furs_premium;
            if (scheduled_personal_property_agreed_value == constantValues.binaryConstants.yes) {
                furs_agreed_value_factor = parseFloat(socotraApi.tableLookup(agreedtableName, scheduled_personal_property_type));
                furs_premium = furs_premium * furs_agreed_value_factor;
                agreed_value_furs_premium += (furs_agreed_value_factor * scheduled_personal_property_limit)/constantValues.numberConstants.one_thousand;
                total_agreed_sum += agreed_value_furs_premium;
            }
        }
        else if (scheduled_personal_property_type == constantValues.perilValueConstansts.golf_equipment) {
            scheduled_personal_property_table_value = parseFloat(socotraApi.tableLookup(tableName, scheduled_personal_property_type));
            golf_equipment_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            standard_golf_equipment_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            total_standard_sum += standard_golf_equipment_premium;
            if (scheduled_personal_property_agreed_value == constantValues.binaryConstants.yes) {
                golf_equip_agreed_value_factor = parseFloat(socotraApi.tableLookup(agreedtableName, scheduled_personal_property_type));
                golf_equipment_premium = golf_equipment_premium * golf_equip_agreed_value_factor;
                agreed_value_golf_equipment_premium += (golf_equip_agreed_value_factor * scheduled_personal_property_limit)/constantValues.numberConstants.one_thousand;
                total_agreed_sum += agreed_value_golf_equipment_premium;
            }
        }
        else if (scheduled_personal_property_type == constantValues.perilValueConstansts.jewelry) {
            scheduled_personal_property_table_value = parseFloat(socotraApi.tableLookup(tableName, scheduled_personal_property_type));
            jewelry_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            standard_jewelry_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            total_standard_sum += standard_jewelry_premium;
            if (scheduled_personal_property_agreed_value == constantValues.binaryConstants.yes) {
                jewelry_agreed_value_factor = parseFloat(socotraApi.tableLookup(agreedtableName, scheduled_personal_property_type));
                jewelry_premium = jewelry_premium * jewelry_agreed_value_factor;
                agreed_value_jewelry_premium += (jewelry_agreed_value_factor * scheduled_personal_property_limit)/constantValues.numberConstants.one_thousand;
                total_agreed_sum += agreed_value_jewelry_premium;
            }
        }
        else if (scheduled_personal_property_type == constantValues.perilValueConstansts.musical_instruments) {
            scheduled_personal_property_table_value = parseFloat(socotraApi.tableLookup(tableName, scheduled_personal_property_type));
            musical_instruments_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            standard_musical_instruments_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            total_standard_sum += standard_musical_instruments_premium;
            if (scheduled_personal_property_agreed_value == constantValues.binaryConstants.yes) {
                musical_instruments_agreed_value_factor = parseFloat(socotraApi.tableLookup(agreedtableName, scheduled_personal_property_type));
                musical_instruments_premium = musical_instruments_premium * musical_instruments_agreed_value_factor;
                agreed_value_musical_instruments_premium += (musical_instruments_agreed_value_factor * scheduled_personal_property_limit)/constantValues.numberConstants.one_thousand;
                total_agreed_sum += agreed_value_musical_instruments_premium;
            }
        }
        else if (scheduled_personal_property_type == constantValues.perilValueConstansts.silverware) {
            scheduled_personal_property_table_value = parseFloat(socotraApi.tableLookup(tableName, scheduled_personal_property_type));
            silverware_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            standard_silverware_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            total_standard_sum += standard_silverware_premium;
            if (scheduled_personal_property_agreed_value == constantValues.binaryConstants.yes) {
                silverware_agreed_value_factor = parseFloat(socotraApi.tableLookup(agreedtableName, scheduled_personal_property_type));
                silverware_premium = silverware_premium * silverware_agreed_value_factor;
                agreed_value_silverware_premium += (silverware_agreed_value_factor * scheduled_personal_property_limit)/constantValues.numberConstants.one_thousand;
                total_agreed_sum += agreed_value_silverware_premium;
            }
        }
        else if (scheduled_personal_property_type == constantValues.perilValueConstansts.stamps) {
            scheduled_personal_property_table_value = parseFloat(socotraApi.tableLookup(tableName, scheduled_personal_property_type));
            stamps_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            standard_stamps_premium += (scheduled_personal_property_table_value * scheduled_personal_property_limit) / constantValues.numberConstants.one_thousand;
            total_standard_sum += standard_stamps_premium;
            if (scheduled_personal_property_agreed_value == constantValues.binaryConstants.yes) {
                stamps_agreed_value_factor = parseFloat(socotraApi.tableLookup(agreedtableName, scheduled_personal_property_type));
                stamps_premium = stamps_premium * stamps_agreed_value_factor;
                agreed_value_stamps_premium += (stamps_agreed_value_factor * scheduled_personal_property_limit)/constantValues.numberConstants.one_thousand;
                total_agreed_sum += agreed_value_stamps_premium;
            }
        }
    }
   
    socotraApi.setAuxData(Locator, "agreedValueCamerasPremium", agreed_value_cameras_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "agreedValueCoinsPremium", agreed_value_coins_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "agreedValueFineArtsPremium", agreed_value_fine_arts_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "agreedValueFineArtsBreakagePremium", agreed_value_fine_arts_breakage_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "agreedValueFursPremium", agreed_value_furs_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "agreedValueGolfEquipmentPremium", agreed_value_golf_equipment_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "agreedValueJewelryPremium", agreed_value_jewelry_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "agreedValueMusicalInstrumentsPremium", agreed_value_musical_instruments_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "agreedValueSilverwarePremium", agreed_value_silverware_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "agreedValueStampsPremium", agreed_value_stamps_premium.round(2), constantValues.auxDataConstants.ui_type);

    socotraApi.setAuxData(Locator, "standardCamerasPremium", standard_cameras_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "standardCoinsPremium", standard_coins_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "standardFineArtsPremium", standard_fine_arts_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "standardFineArtsBreakagePremium", standard_fine_arts_breakage_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "standardFursPremium", standard_furs_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "standardGolfEquipmentPremium", standard_golf_equipment_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "standardJewelryPremium", standard_jewelry_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "standardMusicalInstrumentsPremium", standard_musical_instruments_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "standardSilverwarePremium", standard_silverware_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "standardStampsPremium", standard_stamps_premium.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "totalAgreedSum", total_agreed_sum.round(2), constantValues.auxDataConstants.ui_type);
    socotraApi.setAuxData(Locator, "totalStandardSum", total_standard_sum.round(2), constantValues.auxDataConstants.ui_type);

    let scheduled_personal_property_premium = cameras_premium + coins_premium + fine_arts_premium + fine_arts_breakage_premium + furs_premium + golf_equipment_premium +
        jewelry_premium + musical_instruments_premium + silverware_premium + stamps_premium;
    scheduled_personal_property_premium = scheduled_personal_property_premium.round(constantValues.numberConstants.two);

    return scheduled_personal_property_premium;

}

function getPremiumForGoldPackageCredit(perils, peril, exposures, policyExposurePerils,adjustedBasePremiums) {
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.package_calculation_factors;
    tableName = ratingHelpers.getTableName(state, tableName);
    let wind_key = constantValues.numberConstants.oneTwoFive_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.wind;
    let wind_erc = parseFloat(socotraApi.tableLookup(tableName, wind_key));

    let water_key = constantValues.numberConstants.oneTwoFive_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.water;
    let water_erc = parseFloat(socotraApi.tableLookup(tableName, water_key));

    let fire_key = constantValues.numberConstants.oneTwoFive_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.fire;
    let fire_erc = parseFloat(socotraApi.tableLookup(tableName, fire_key));

    let theft_key = constantValues.numberConstants.oneTwoFive_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.theft;
    let theft_erc = parseFloat(socotraApi.tableLookup(tableName, theft_key));

    let liability_key = constantValues.numberConstants.oneTwoFive_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.liability;
    let liability_erc = parseFloat(socotraApi.tableLookup(tableName, liability_key));

    let other_key = constantValues.numberConstants.oneTwoFive_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.other;
    let other_erc = parseFloat(socotraApi.tableLookup(tableName, other_key));

    let hurricane_key = constantValues.numberConstants.oneTwoFive_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.hurricane;
    let hurricane_erc = parseFloat(socotraApi.tableLookup(tableName, hurricane_key));

    let wind_base_premium = adjustedBasePremiums.windBasePremium; 
    let water_base_premium = adjustedBasePremiums.waterBasePremium;
    let fire_base_premium = adjustedBasePremiums.fireBasePremium;
    let theft_base_premium = adjustedBasePremiums.theftBasePremium;
    let liability_base_premium = adjustedBasePremiums.liabilityBasePremium;
    let other_base_premium = adjustedBasePremiums.otherBasePremium;
    let hurricane_base_premium = 1 //Need to update the dependent method ( Hurricane Base Premium) **Dont have Hurricane Base Premium**
   let wind = (wind_erc * wind_base_premium).round(2);
   let water = (water_erc * water_base_premium).round(2);
   let fire = (fire_erc * fire_base_premium).round(2);
   let theft = (theft_erc * theft_base_premium).round(2);
   let liability = (liability_erc * liability_base_premium).round(2);
   let other = (other_erc * other_base_premium).round(2);
   
   let total_base_premium = parseFloat((+wind_base_premium) + (+water_base_premium) + (+fire_base_premium) + (+theft_base_premium) + (+liability_base_premium) + (+other_base_premium));
   console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 183 ~ getPremiumForGoldPackageCredit ~ total_base_premium", total_base_premium)
    // let oneTwoFive_erc = (((wind_erc * wind_base_premium) + (water_erc * water_base_premium) + (fire_erc * fire_base_premium) +
    //     (theft_erc * theft_base_premium) + (liability_erc * liability_base_premium) + (other_erc * other_base_premium) +
    //     (hurricane_erc * hurricane_base_premium)).round(2)) - total_base_premium;

        let oneTwoFive_erc = parseFloat(((+wind)+(+water)+(+fire)+(+theft)+(+liability)+(+other)) - total_base_premium);
        console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 171 ~ getPremiumForGoldPackageCredit ~ oneTwoFive_erc", oneTwoFive_erc)

    let personal_property_rcv = dwellingCoverages1.getPremiumForPersonalPropertyRCV(perils, peril, exposures, policyExposurePerils,adjustedBasePremiums)
    let rc_pp = personal_property_rcv.personal_prop_replacement_cost_premium;
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 178 ~ getPremiumForGoldPackageCredit ~ rc_pp", rc_pp)

    tableName = constantValues.tableNameConsts.water_backup_package_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let water_backup_key = constantValues.exposureFieldValueConstants.gold
    let water_backup_gold = parseFloat(socotraApi.tableLookup(tableName, water_backup_key));
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 195 ~ getPremiumForGoldPackageCredit ~ water_backup_gold", water_backup_gold)

    oneTwoFive_erc = (parseFloat(oneTwoFive_erc * constantValues.numberConstants.point_one)).round(2);
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 198 ~ getPremiumForGoldPackageCredit ~ oneTwoFive_erc", oneTwoFive_erc)
    rc_pp = (parseFloat(rc_pp * constantValues.numberConstants.point_one)).round(2);
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 200 ~ getPremiumForGoldPackageCredit ~ rc_pp", rc_pp)
    water_backup_gold = (parseFloat(water_backup_gold * constantValues.numberConstants.point_one)).round(2);
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 202 ~ getPremiumForGoldPackageCredit ~ water_backup_gold", water_backup_gold)

    let gold_package_credit = parseFloat(((+oneTwoFive_erc) + (+rc_pp) + (+water_backup_gold)) * -1); ///should be negative
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 191 ~ getPremiumForGoldPackageCredit ~ gold_package_credit", gold_package_credit)

    return gold_package_credit;
}

function getPremiumForPlatinumPackageCredit(perils, peril, exposures, policyExposurePerils,adjustedBasePremiums) {

    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let state = exposure_fv.property_state;
    let tableName = constantValues.tableNameConsts.package_calculation_factors;
    tableName = ratingHelpers.getTableName(state, tableName);
    let wind_key = constantValues.numberConstants.oneFiveZero_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.wind;
    let wind_erc = parseFloat(socotraApi.tableLookup(tableName, wind_key));

    let water_key = constantValues.numberConstants.oneFiveZero_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.water;
    let water_erc = parseFloat(socotraApi.tableLookup(tableName, water_key));

    let fire_key = constantValues.numberConstants.oneFiveZero_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.fire;
    let fire_erc = parseFloat(socotraApi.tableLookup(tableName, fire_key));

    let theft_key = constantValues.numberConstants.oneFiveZero_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.theft;
    let theft_erc = parseFloat(socotraApi.tableLookup(tableName, theft_key));

    let liability_key = constantValues.numberConstants.oneFiveZero_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.liability;
    let liability_erc = parseFloat(socotraApi.tableLookup(tableName, liability_key));

    let other_key = constantValues.numberConstants.oneFiveZero_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.other;
    let other_erc = parseFloat(socotraApi.tableLookup(tableName, other_key));

    let hurricane_key = constantValues.numberConstants.oneFiveZero_erc + constantValues.tableKeyConstants.pipe + constantValues.exposureFieldValueConstants.hurricane;
    let hurricane_erc = parseFloat(socotraApi.tableLookup(tableName, hurricane_key));

    let wind_base_premium = adjustedBasePremiums.windBasePremium;
    let water_base_premium = adjustedBasePremiums.waterBasePremium;
    let fire_base_premium = adjustedBasePremiums.fireBasePremium; 
    let theft_base_premium = adjustedBasePremiums.theftBasePremium;
    let liability_base_premium = adjustedBasePremiums.liabilityBasePremium;
    let other_base_premium = adjustedBasePremiums.otherBasePremium;
    let hurricane_base_premium = 1;//Need to update the dependent method ( Hurricane Base Premium)  **Dont have Hurricane Base Premium**

    let total_base_premium = parseFloat((+wind_base_premium) + (+water_base_premium) + (+fire_base_premium) + (+theft_base_premium) + (+liability_base_premium) + (+other_base_premium));

    let wind = (wind_erc * wind_base_premium).round(2);
    let water = (water_erc * water_base_premium).round(2);
    let fire = (fire_erc * fire_base_premium).round(2);
    let theft = (theft_erc * theft_base_premium).round(2);
    let liability = (liability_erc * liability_base_premium).round(2);
    let other = (other_erc * other_base_premium).round(2);

    let oneFiveZero_erc = parseFloat(((+wind)+(+water)+(+fire)+(+theft)+(+liability)+(+other)) - total_base_premium);
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 260 ~ getPremiumForPlatinumPackageCredit ~ oneFiveZero_erc", oneFiveZero_erc)

    // let oneFiveZero_erc = parseFloat((wind_erc * wind_base_premium) + (water_erc * water_base_premium) + (fire_erc * fire_base_premium) +
    //     (theft_erc * theft_base_premium) + (liability_erc * liability_base_premium) + (other_erc * other_base_premium) +
    //     (hurricane_erc * hurricane_base_premium));

    let personal_property_rcv = dwellingCoverages1.getPremiumForPersonalPropertyRCV(perils, peril, exposures, policyExposurePerils,adjustedBasePremiums)
    let rc_pp = personal_property_rcv.personal_prop_replacement_cost_premium;
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 270 ~ getPremiumForPlatinumPackageCredit ~ rc_pp", rc_pp)


    let replace_cost_nonbldg_struct = dwellingCoverages2.getPremiumForCertainNonBuilding(perils, exposures,adjustedBasePremiums);
    let rc_for_Nnon_structures = parseFloat((+replace_cost_nonbldg_struct.wind_replace_cost_nonbldg_struct_premium) + (+replace_cost_nonbldg_struct.water_replace_cost_nonbldg_struct_premium) + (+replace_cost_nonbldg_struct.fire_replace_cost_nonbldg_struct_premium) + (+replace_cost_nonbldg_struct.theft_replace_cost_nonbldg_struct_premium) +(+replace_cost_nonbldg_struct.other_replace_cost_nonbldg_struct_premium));
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 275 ~ getPremiumForPlatinumPackageCredit ~ rc_for_Nnon_structures", rc_for_Nnon_structures)

    tableName = constantValues.tableNameConsts.water_backup_package_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let water_backup_key = constantValues.exposureFieldValueConstants.platinum
    let water_backup_platinum = parseFloat(socotraApi.tableLookup(tableName, water_backup_key));

    tableName = constantValues.tableNameConsts.refrigerated_contents_increase_table;
    tableName = ratingHelpers.getTableName(state, tableName);
    let refrigerated_contents_key = constantValues.tableKeyConstants.rate
    let refrigerated_contents_increase_limit = parseFloat(socotraApi.tableLookup(tableName, refrigerated_contents_key));
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 285 ~ getPremiumForPlatinumPackageCredit ~ refrigerated_contents_increase_limit", refrigerated_contents_increase_limit)
    let electrical_power_backup = exposure_fv.electrical_power_backup;
    if (electrical_power_backup == constantValues.binaryConstants.yes) {
        refrigerated_contents_increase_limit = parseFloat(refrigerated_contents_increase_limit * constantValues.numberConstants.point_eight);
        console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 288 ~ getPremiumForPlatinumPackageCredit ~ refrigerated_contents_increase_limit", refrigerated_contents_increase_limit)
    }
    else {
        refrigerated_contents_increase_limit = refrigerated_contents_increase_limit * constantValues.numberConstants.one;
    }
    oneFiveZero_erc = (oneFiveZero_erc * constantValues.numberConstants.point_one).round(constantValues.numberConstants.two);
    rc_pp = (rc_pp * constantValues.numberConstants.point_one).round(constantValues.numberConstants.two);
    rc_for_Nnon_structures = (rc_for_Nnon_structures * constantValues.numberConstants.point_one).round(constantValues.numberConstants.two);
    water_backup_platinum = (water_backup_platinum * constantValues.numberConstants.point_one).round(constantValues.numberConstants.two);
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 298 ~ getPremiumForPlatinumPackageCredit ~ water_backup_platinum", water_backup_platinum)
    refrigerated_contents_increase_limit = (parseFloat(refrigerated_contents_increase_limit * constantValues.numberConstants.point_one)).round(constantValues.numberConstants.two);
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 298 ~ getPremiumForPlatinumPackageCredit ~ refrigerated_contents_increase_limit", refrigerated_contents_increase_limit)

    let platinum_package_credit = parseFloat((((+oneFiveZero_erc) + (+rc_pp) + (+water_backup_platinum) + (+refrigerated_contents_increase_limit) + (+rc_for_Nnon_structures))) * -1);//should be negative
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 302 ~ getPremiumForPlatinumPackageCredit ~ platinum_package_credit", platinum_package_credit)

    return platinum_package_credit;

}

function getPremiumForCreditsOnABP(peril, exposures, adjustedBasePremiums , policyLocator, transactionType, transactionLocator) {
    let exposure_fv = ratingHelpers.getExposureFieldValues(peril, exposures);
    let electrical_power_backup = exposure_fv.electrical_power_backup;
    let temp_monitoring = exposure_fv.temp_monitoring
    let water_leak_detection = exposure_fv.water_leak_detection
    let fire_alarm = exposure_fv.fire_alarm
    let sprinklers = exposure_fv.sprinklers
    let lightning_protection = exposure_fv.lightning_protection
    let superior_construction = exposure_fv.superior_construction
    let burglar_alarm = exposure_fv.burglar_alarm
    let gas_leak_detection = exposure_fv.gas_leak_detection;
    let state = exposure_fv.property_state;

    let electrical_power_backup_factor = 1 - parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, constantValues.tableNameConsts.electrical_power_backup_factor_table), electrical_power_backup));
    let temp_monitoring_factor = 1 - parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, constantValues.tableNameConsts.temp_monitoring_factor_table), temp_monitoring));
    let water_leak_detection_factor = 1 - parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, constantValues.tableNameConsts.water_leak_detection_factor_table), water_leak_detection));
    let water_adjusted_base_premium = adjustedBasePremiums.waterAdjPremium;
    let water_credits_on_abp = (-Math.min(electrical_power_backup_factor + temp_monitoring_factor + water_leak_detection_factor, constantValues.numberConstants.point_three_five)) * water_adjusted_base_premium;
    water_credits_on_abp = water_credits_on_abp.round(constantValues.numberConstants.two);
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 288 ~ getPremiumForCreditsOnABP ~ water_credits_on_abp", water_credits_on_abp)

    let gas_leak_detection_factor = 1 - parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, constantValues.tableNameConsts.gas_detection_factor_table), ratingHelpers.removeCommaAndSpace(gas_leak_detection)));
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 324 ~ getPremiumForCreditsOnABP ~ gas_leak_detection_factor", gas_leak_detection_factor)
    let lightning_protection_factor = 1 - parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, constantValues.tableNameConsts.lightning_protection_factor_table), lightning_protection));
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 326 ~ getPremiumForCreditsOnABP ~ lightning_protection_factor", lightning_protection_factor)
    let superior_construction_factor = 1 - parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, constantValues.tableNameConsts.sup_const_factor_table), superior_construction));
    let superior_construction_disc = (lightning_protection_factor -  superior_construction_factor).round(2);
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 330 ~ getPremiumForCreditsOnABP ~ superior_construction_disc", superior_construction_disc)
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 328 ~ getPremiumForCreditsOnABP ~ superior_construction_factor", superior_construction_factor)
    let sprinklers_factor = 1 - parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, constantValues.tableNameConsts.sprinklers_factor_table), sprinklers));
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 330 ~ getPremiumForCreditsOnABP ~ sprinklers_factor", sprinklers_factor)
    let fire_alarm_factor = 1 - parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, constantValues.tableNameConsts.fire_alarm_factor_table), ratingHelpers.removeCommaAndSpace(fire_alarm)));
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 332 ~ getPremiumForCreditsOnABP ~ fire_alarm_factor", fire_alarm_factor)
    let fire_adjusted_base_premium = adjustedBasePremiums.fireAdjPremium;
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 334 ~ getPremiumForCreditsOnABP ~ fire_adjusted_base_premium", fire_adjusted_base_premium)
    let fire_credits_on_abp = (-Math.min(parseFloat(gas_leak_detection_factor + lightning_protection_factor + superior_construction_factor + sprinklers_factor + fire_alarm_factor), constantValues.numberConstants.point_three_five)) * fire_adjusted_base_premium;
    fire_credits_on_abp = fire_credits_on_abp;
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 298 ~ getPremiumForCreditsOnABP ~ fire_credits_on_abp", fire_credits_on_abp)

    let burglar_alarm_factor = 1 - parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, constantValues.tableNameConsts.burglar_alarm_factor_table), ratingHelpers.removeCommaAndSpace(burglar_alarm)));
    let theft_adjusted_base_premium = adjustedBasePremiums.theftAdjPremium;
    let theft_credits_on_abp = (-Math.min(burglar_alarm_factor, constantValues.numberConstants.point_three_five)) * theft_adjusted_base_premium;
    theft_credits_on_abp = theft_credits_on_abp.round(constantValues.numberConstants.two);
    console.log("🚀 ~ file: plcPremiumComputations1.js ~ line 304 ~ getPremiumForCreditsOnABP ~ theft_credits_on_abp", theft_credits_on_abp)
    if(transactionType == constantValues.operationConstants.new_business)
    socotraApi.setAuxData(policyLocator, "superiorConstruction", superior_construction_disc , constantValues.auxDataConstants.ui_type);
    else
    socotraApi.setAuxData(transactionLocator, "superiorConstruction", superior_construction_disc , constantValues.auxDataConstants.ui_type);
    let credits_on_abp_premium = (+water_credits_on_abp) + (+fire_credits_on_abp) + (+theft_credits_on_abp);
    return{
    credits_on_abp_premium,
    water_credits_on_abp,
    fire_credits_on_abp,
    theft_credits_on_abp
    }
}

exports.getPremiumForSchedulePersonalProperty = getPremiumForSchedulePersonalProperty;
exports.getPremiumForGoldPackageCredit = getPremiumForGoldPackageCredit;
exports.getPremiumForPlatinumPackageCredit = getPremiumForPlatinumPackageCredit;
exports.getPremiumForCreditsOnABP = getPremiumForCreditsOnABP;