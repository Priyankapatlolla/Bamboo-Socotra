let ratingConstants = require("./ratingConstants.js")
let moment = require("../libraries/moment-with-locales.js")

function getTableObject(tableName, tableKey)
{
  let valueFromTable;
  let valuesArray;
  valueFromTable = socotraApi.tableLookup(tableName, tableKey);
  valuesArray = valueFromTable.split(ratingConstants.tableKeyConstants.pipe);
  let keyValuePairs = [];
  for (let prop of valuesArray)
  {
    let keyValue = prop.split(ratingConstants.tableKeyConstants.hash);
    keyValuePairs.push(keyValue);
  }
  var obj = Object.assign(...keyValuePairs.map(([key, val]) => (
  {
    [key]: val
  })));
  return obj;
}

function getTableName(state, tableName)
{
  if(state == ratingConstants.stateConstants.az)
  {

    tableName = "AZ-" + tableName;
    return  tableName;
  }
}

function getExposureFieldValues(peril,exposures)
{
    //let exposureLocator = peril.exposureLocator;
    //let exposure = exposures.find((e) => e.locator == exposureLocator);
    let exposure = exposures.find((e) => e.name == "Dwelling");
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    return exposure_fv;
}

function getRoofOrHomeAge(year, policy_start_timestamp)
{
  let effective_year = new Date(+policy_start_timestamp).getFullYear();
  let age = Math.abs(effective_year - year);
  return age;
}

function removeSpecialCharacters(limit)
{
  if(limit != undefined)
  {
    return limit.toString().replace(/[$,]/g, '');
  }
  else
  {
    return limit;
  }
}

function removeCommaAndSpace(str)
{
  let result = str.toString().replace(/[, ]+/g, "").trim();
  return result;
}
function getYearsDiff(dt2,dt1) 
{
  let year_diff = Math.abs(moment(new Date(dt2)).diff(new Date(dt1), 'year', true));
  return Math.floor(year_diff);
}

function findRange(value){
  let rangeTable = [0, 15, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190, 200, 
     210, 220, 230, 240, 250, 260, 270, 280, 290, 300, 310, 320, 330, 340, 350, 360, 370, 380, 390, 400, 410, 
     420, 430, 440, 450, 460, 470, 480, 490, 500, 550, 600, 650, 700, 750, 800, 850, 900, 950, 1000, 1100, 1200, 1300, 
     1400, 1500, 1750, 2000, 2250, 2500, 2750, 3000];
  for(let i = 0; i < rangeTable.length; i++){
     if(value <= rangeTable[i]){
        let upperLimit = rangeTable[i];
        let lowerLimit = rangeTable[i-1];
        return {
           lowerLimit, upperLimit
        }
     }
  }
}

function interpolate(state,limit,deductible_factor_table,deductible,type_constant)
{
  let ded_factor;
  let upper_limit;
  let lower_limit;
  coverage_a_limit_per_mill = limit/1000;
  console.log("🚀 ~ file: helpersRating.js ~ line 94 ~ coverage_a_limit_per_mill", coverage_a_limit_per_mill)
  if(coverage_a_limit_per_mill <= 3000)
  {
    upper_limit =  findRange(coverage_a_limit_per_mill).upperLimit;        
    lower_limit =  findRange(coverage_a_limit_per_mill).lowerLimit;  
  
   let upper_ded_factor_table_key = upper_limit + ratingConstants.tableKeyConstants.pipe + deductible;
   let upper_limit_rate = parseFloat(socotraApi.tableLookup(getTableName(state,deductible_factor_table),upper_ded_factor_table_key));
   let lower_ded_factor_table_key = lower_limit + ratingConstants.tableKeyConstants.pipe + deductible;
   let lower_limit_rate = parseFloat(socotraApi.tableLookup(getTableName(state,deductible_factor_table),lower_ded_factor_table_key));
   lower_limit_rate = !isNaN(lower_limit_rate) ? lower_limit_rate : ratingConstants.numberConstants.zero;
   if(coverage_a_limit_per_mill == lower_limit || coverage_a_limit_per_mill == upper_limit)
   {
     ded_factor_key = coverage_a_limit_per_mill + ratingConstants.tableKeyConstants.pipe + deductible;
     ded_factor = parseFloat(socotraApi.tableLookup(getTableName(state,deductible_factor_table),ded_factor_key));
   }
   else if(coverage_a_limit_per_mill != lower_limit || coverage_a_limit_per_mill != upper_limit)
   {
    ded_factor = lower_limit_rate + ((upper_limit_rate - lower_limit_rate)/(upper_limit - lower_limit)) * (coverage_a_limit_per_mill - lower_limit)
   }
   else
   {
    ded_factor = ratingConstants.numberConstants.one;
   }

  }
  else if(coverage_a_limit_per_mill > 3000)
  {
    let base_ded_factor_key = ratingConstants.numberConstants.three_thousand + ratingConstants.getTableObjectConstants.pipe + deductible;
    let base_ded_factor = parseFloat(socotraApi.tableLookup(deductible_factor_table,base_ded_factor_key));
    let add_cov_a_per_mill = (limit - 3000000)/1000;
    let add_ded_factor = add_cov_a_per_mill * parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConsts.additional_1000_for_cov_a,type_constant));
    ded_factor = base_ded_factor + add_ded_factor;
  }
  else
  {
    ded_factor = ratingConstants.numberConstants.one;
  }

  return ded_factor;
}
function getDecimalFromPercentage(percent)
{
  return parseInt(percent) / 100.0;
}

function getOtherPerilLimits(policyExposurePerils,perils)
{
  let  aop_deductible;
  let  windhail_deductible;
  let  cov_a_limit;
  let  cov_e_limit;
  let  cov_f_limit;
  let  ordinance_law_percentage;
  let  extended_rcv = ratingConstants.numberConstants.one;
  for (let policy_exposure_peril of policyExposurePerils) 
  { 
    let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;  
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_a) {    
         cov_a_limit = removeSpecialCharacters(otherPeril_fv.coverage_a_limit);
        if(otherPeril_fv.extended_rcv_percent != undefined)
        {
          extended_rcv = removeSpecialCharacters(otherPeril_fv.extended_rcv_percent);
        }
    }  
    if (otherPeril.name == ratingConstants.perilNameConstants.deductibles) {
        aop_deductible = removeSpecialCharacters(otherPeril_fv.aop_deductible);
        windhail_deductible = getDecimalFromPercentage(otherPeril_fv.wind_hail_deductible);
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_e) {    
       cov_e_limit = removeSpecialCharacters(otherPeril_fv.coverage_e_personal_liability_limit);      
    }  
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_f) {
      cov_f_limit = removeSpecialCharacters(otherPeril_fv.medical_payments_limit);
    }
    if(otherPeril.name == ratingConstants.perilNameConstants.ordinance_law_coverage){
       ordinance_law_percentage = otherPeril_fv.ordinance_law_percent;
    }
  }

  return {
    cov_a_limit,
    aop_deductible,
    windhail_deductible,
    cov_e_limit,
    cov_f_limit,
    extended_rcv,
    ordinance_law_percentage
  }

}

// function getAttractScoreRange(attract_score)
// {
//   let rangeTable = [200,571,572,615,616,647,648,674,675,699,700,724,725,751,752,783,784,827,828,997];
//   for(let i = 0; i < rangeTable.length; i++){
//     if(value <= rangeTable[i]){
//        let upperLimit = rangeTable[i];
//        let lowerLimit = rangeTable[i-1];
//        return {
//           lowerLimit, upperLimit
//        }
//     }
//  }
// }

function getAttractScoreRange(attract_score)
{
  if(attract_score < 200)
  {
    return "No Score";
  }
  if(attract_score >= 200 && attract_score <= 571)
  {
    return "200-571";
  }
  else if (attract_score >= 572 && attract_score <= 615)
  {
    return "572-615";
  }
  else if (attract_score >= 572 && attract_score <= 615)
  {
    return "572-615";
  }
  else if (attract_score >= 616 && attract_score <= 647)
  {
    return "616-647";
  }
  else if (attract_score >= 648 && attract_score <= 674)
  {
    return "648-674";
  }
  else if (attract_score >= 675 && attract_score <= 699)
  {
    return "675-699";
  }
  else if (attract_score >= 700 && attract_score <= 724)
  {
    return "700-724";
  }
  else if (attract_score >= 725 && attract_score <= 751)
  {
    return "725-751";
  }
  else if (attract_score >= 752 && attract_score <= 783)
  {
    return "752-783";
  }
  else if (attract_score >= 784 && attract_score <= 827)
  {
    return "784-827";
  }
  else if (attract_score >= 828 && attract_score <= 997)
  {
    return "828-997";
  }
  else
  {
    return "No Hit";
  }

}

var dates = {
  convert:function(d) {
      return (
          d.constructor === Date ? d :
          d.constructor === Array ? new Date(d[0],d[1],d[2]) :
          d.constructor === Number ? new Date(d) :
          d.constructor === String ? new Date(d) :
          typeof d === "object" ? new Date(d.year,d.month,d.date) :
          NaN
      );
  },
  compare:function(a,b) {
      return (
          isFinite(a=this.convert(a).valueOf()) &&
          isFinite(b=this.convert(b).valueOf()) ?
          (a>b)-(a<b) :
          NaN
      );
  }
}

function roundToDecimalPlaces() {
  Number.prototype.round = function(n) {
    const d = Math.pow(10, n);
    return Math.round((this + Number.EPSILON) * d) / d;
  }
}

exports.roundToDecimalPlaces = roundToDecimalPlaces;
exports.dates = dates;
exports.removeCommaAndSpace = removeCommaAndSpace;
exports.getDecimalFromPercentage = getDecimalFromPercentage;
exports.getAttractScoreRange = getAttractScoreRange;
exports.getYearsDiff = getYearsDiff;
exports.getOtherPerilLimits = getOtherPerilLimits;
exports.findRange = findRange;
exports.interpolate = interpolate;
exports.getTableObject = getTableObject;
exports.getTableName = getTableName;
exports.getExposureFieldValues = getExposureFieldValues;
exports.getRoofOrHomeAge = getRoofOrHomeAge;
exports.removeSpecialCharacters = removeSpecialCharacters;
