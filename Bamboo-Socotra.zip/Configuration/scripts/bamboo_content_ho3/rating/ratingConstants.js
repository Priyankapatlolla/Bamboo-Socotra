const perilNameConstants = {
  ordinance_law_coverage:"Ordinance or Law Coverage",
  credits_on_abp:"Credits on ABP",
  age_of_home_rem:"Age of Home Remodeled",
  acv_wind_hail_roof_loss:"ACV Wind Hail Roof Loss",
  secondary_home_charge:"Secondary Home Charge",
  personal_propety_replacement_cost:"Personal Property Replacement Cost",
  rcv_ls_certain_non_building:"Replacement Cost Loss Settlement For Certain Non-Building Structures On The Residence Premises",
  gold_package_credit:"Gold Package Credit",
  Platinum_package_credit:"Platinum Package Credit",
  other_structures_increased_limit:"Other Structures Increased Limits",
  increase_decrease_coverage_C:"Increase Decrease Coverage C",
  increase_decrease_coverage_D:"Increase Decrease Coverage D",
  coverage_c:"Coverage C - Personal Property",
  coverage_a:"Coverage A - Dwelling",
  coverage_b:"Coverage B - Other Structures",
  coverage_d:"Coverage D - Loss of Use",
  coverage_e:"Coverage E - Personal Liability",
  coverage_f:"Coverage F - Medical Payments",
  adjusted_base_premium: "Adjusted Base Premium",
  device_protection:"Device Protection",
  personal_injury_coverage:"Personal Injury Coverage",
  other_locations_occupied_by_insured:"Other Locations Occupied by Insured",
  green_home_additional_coverage:"Green Home Additional Coverage",
  student_away_from_home:"Student away from home",
  residence_held_in_trust:"Residence Held in Trust",
  golf_cart_physical_loss:"Golf Cart Physical Loss Coverage",
  assisted_living_care_coverage:"Assisted Living Care Coverage",
  landlord_furnishings:"Landlords Furnishings - Increased Limit",
  water_backup_sump_discharge:"Water Back Up and Sump Discharge or Overflow",
  limited_special_computer_equipment_coverage:"Limited Special Computer Equipment Coverage",
  refrigerated_Personal_property:"Refrigerated Personal Property",
  specific_other_structures_coverage:"Specific Other Structures Coverage",
  business_property_increased_limits:"Business Property Increased Limits",
  limited_animal_liability_coverage:"Limited Animal Liability Coverage",
  equipment_breakdown_coverage:"Equipment Breakdown Coverage",
  service_line_coverage:"Service Line Coverage",
  actual_cash_value_roof:"Actual Cash Value Roof",
  townhouse_row_house:"Townhouse or Row House",
  limited_fungi_microbes_coverage:"Limited Fungi or Microbes Coverage",
  family_cyber_protection:"Family Cyber Protection",
  personal_property_scheduled:"Personal Property - Scheduled",
  policy_transaction_credit:"Policy Transition Credit",
  discounts_and_min_premium:"Discounts and Min Premium",
  home_day_care_coverage:"Home Day Care Coverage",
  increased_special_limits:"Coverage C Increased Special Limits of Liability",
  supplement_loss_assessment_cov:"Supplemental Loss Assessment Coverage",
  deductibles:"Deductibles",
  discounts_and_min_prem: "Discounts and Min Premium",
  policy_transition_credit: "Policy Transition Credit"
}

const numberConstants = {
  ten:10,
  point_three_five:0.35,
  one:1,
  two:2,
  oneTwoFive_erc:"125% ERC",
  oneFiveZero_erc:"150% ERC",
  point_one:0.1,
  point_eight:0.8,
  one_hundred:100,
  one_thousand:1000,
  five_thousand:5000,
  zero:0,
  point_five:0.5,
  point_three:0.3,
  eight:8,
  four:4,
  five_hundred:500,
  twenty_five_hundred:2500,
  three_thousand:3000,
  point_zero_four_five:0.045,
  ten_thousand:10000,
  three:3,
  four:4,
  five:5
}

const tableNameConsts = {
  ordinance_law_coverage_table :"Ordinance_Law_Factor_Table",
  electrical_power_backup_factor_table:"Electrical_Power_Backup_Factor_Table",
  temp_monitoring_factor_table:"Temp_Monitoring_Factor_Table",
  water_leak_detection_factor_table:"Water_Leak_Detection_Factor_Table",
  gas_detection_factor_table:"Gas_Detection_Factor_Table",
  sprinklers_factor_table:"Sprinklers_Factor_Table",
  lightning_protection_factor_table:"Lightning_Protection_Factor_Table",
  sup_const_factor_table:"Sup_Const_Factor_Table",
  fire_alarm_factor_table:"Fire_Alarm_Factor_Table",
  burglar_alarm_factor_table:"Burglar_Alarm_Factor_Table",
  age_of_home_remoulded_factor_table:"Age_of_Home_Remodeled_Factor_Table",
  acv_wind_hail_roof_loss_factor_table:"ACV_Wind_Hail_Roof_Loss_Factor_Table",
  secondary_home_charge_factor_table:"Secondary_Home_Charge_Factor_Table",
  replacement_cost_factor_table:"Replacement_Cost_Factor_Table",
  replacement_cost_nonbldg_factor_table:"Replacement_Cost_NonBldg_Struct_Factor_Table",
  package_calculation_factors:"Package_Calculation_Factors",
  water_backup_package_table:"Water_Backup_Package_Table",
  refrigerated_contents_increase_table:"Refrigerated_Contents_Increase_Table",
  increase_decrease_cov_b_table:"Increase_Decrease_Cov_B_Table",
  increase_decrease_cov_c_table:"Increase_Decrease_Cov_C_Table",
  increase_decrease_cov_d_table:"Increase_Decrease_Cov_D_Table",
  unscheduled_fridge_property_rate_table:"Unscheduled_Fridge_Property_Rate_table",
  specific_other_structure_table:"Specific_Other_Structure_table",
  loss_assessment_table:"Loss_Assessment_table",
  loss_assessment_ded_rate:"Loss_Assessment_Ded_Rate",
  business_property_table:"Business_Property_table",
  animal_liability_table:"Animal_Liability_Table",
  equipment_breakdown_coverage_premium_table:"Equipment_Breakdown_Coverage_Premium_table",
  service_line_coverage_premium_table:"Service_Line_Coverage_Premium_table",
  limited_fungi_premium_table:"Limited_Fugi_Premium_Table",
  townhouse_factor_table:"Townhouse_Factor_Table",
  acv_roof_factor_table:"ACV_Roof_Factor_Table",
  city_code_table: "City_Code_Table",
  county_code_table: "County_Code_Table",
  terr_code_on_zip_code_table: "Terr_Code_on_Zip_Code_Table",
  form_factor_table: "Form_Factor_Table",
  number_of_families_factor_table: "Number_of_Families_Factor_Table",
  erc_Table: "ERC_table",
  nb_home_buyer_rate_table: "NB_Home_Buyer_Rate_Table",
  opening_protection_factor_table: "Opening_Protection_Factor_Table",
  roof_deck_attachment_factor_table: "Roof_Deck_Attachment_Factor_Table",
  roof_to_wall_connection_factor_table: "Roof_to_Wall_Connection_Factor_Table",
  secondary_water_resistance_factor_table: "Secondary_Water_Resistance_Factor_Table",
  reinforced_exterior_doors_factor_table: "Reinforced_Exterior_Doors_Factor_Table",
  fortified_construction_factor_table: "Fortified_Construction_Factor_Table",
  Iso_cat_codes_table: "ISO_CAT_Codes_Table",
  prior_claims_factor_table: "Prior_Claims_Factor_Table",
  exp_claims_factor_table: "Exp_Claims_Factor_Table",
  payment_history_factor_table: "Payment_History_Factor_Table",
  attract_score_factor_table: "Attract_Score_Factor_Table",
  increase_coverage_e_f_factor: "Increase_Coverage_E_F_Factor_Table",
  base_rate_table: "Base_Rate_Table",
  territory_factor_table: "Territory_Factor_Table",
  additional_1000_for_cov_a: "Additional_1000_for_Cov_A",
  wind_cov_a_ded_factor_table: "Wind_Cov_A_Ded_Factor_Table",
  water_cov_a_ded_factor_table: "Water_Cov_A_Ded_Factor_Table",
  fire_cov_a_ded_factor_table: "Fire_Cov_A_Ded_Factor_Table",
  fire_prot_constr_factor_table: "Fire_Prot_Constr_Factor",
  fire_department_tax_credit_factor_table: "Fire_Department_Tax_Credit_Factor_Table",
  theft_cov_a_ded_factor_table: "Theft_Cov_A_Ded_Factor_Table",
  other_cov_a_ded_factor_table: "Other_Cov_A_Ded_Factor_Table",
  claims_free_discount_factor_table: "Claims_Free_Discount_Factor_Table",
  scheduled_golf_cart_rate_table:"Scheduled_Golf_Cart_Rate_Table",
  water_backup_rate_table:"Water_Backup_Rate_Table",
  landlord_furnishings_rate_table:"Landlord_Furnishings_Rate_Table",
  personal_injury_rate_table:"Personal_Injury_Rate_Table",
  other_loc_rate_table:"Other_Loc_Rate_Table",
  student_away_from_home_rate_table:"Student_Away_From_Home_Rate_Table",
  limited_special_computer_equipment_table:"Limited_Special_Computer_Equipment_Table",
  assisted_living_care_rate_table:"Assisted_Living_Care_Rate_Table",
  assisted_living_increase__cov_c_rate_table:"Assisted_Living_Increase__Cov_C_Rate_Table",
  assisted_living_increase_cov_e_rate_table:"Assisted_Living_Increase_Cov_E_Rate_Table",
  residence_held_in_trust_rate_table:"Residence_Held_in_Trust_Rate_Table",
  scheduled_pp_table:"Scheduled_PP_Table",
  scheduled_pp_agreed_value_table:"Scheduled_PP_Agreed_Value_Table",
  jwelery_ded_factor_table:"Jwelery_Ded_Factor_Table",
  home_day_care_rate_table:"Home_Day_Care_Rate_Table",
  home_day_misc_care_rate_table:"Home_Day_Misc_Care_Rate_Table",
  max_limit:"Max_Limit",
  rate_division:"Rate_Division",
  ppis_rate:"PPIS_Rate",
  policy_transaction_credit:"Policy_Transition_Credit",
  nb_home_buyer_rate_table: "NB_Home_Buyer_Rate_Table",
  payment_history_factor_table: "Payment_History_Factor_Table",
  multi_policy_discount_table:"Multi_Policy_Discount_Table",
  all_electronic_discount_table:"All_Electronic_Discount_Table",
  min_prem_table:"Min_Prem_Table",
  col_cat_mapping_table:"COL_CAT_Mapping_Table"

}

const tableKeyConstants={
  pipe:" | ",
  rate:"Rate",
  decrease:"Decrease",
  increase:"Increase",
  included:"Included",
  HO3:"HO 3",
  multiplication:"*",
  greater_than_equal_two:">=2",
  greater_than_equal_three:">=3",
  greater_than_equal_four:">=4",
  greater_than_four:">4",
  greater_than_equal_six: ">=6",
  less_than_equal_eight:"<=8",
  greater_than_one_hundred_one: "> 101",
  fire: "Fire",
  water: "Water",
  wind: "Wind",
  theft: "Theft",
  liability: "Liability",
  other: "Other",
  rate: "Rate",
  cov_f:"Cov F",
  cov_e:"Cov E",
  misc:"Misc"

}

const exposureFieldValueConstants = {
  wind:"Wind",
  water:"Water",
  theft:"Theft",
  fire:"Fire",
  liability:"Liability",
  other:"Other",
  hurricane:"Hurricane",
  gold:"Gold",
  platinum:"Platinum",
  dwelling: "Dwelling"

}

const perilValueConstansts = {
  actual_cash_value:"Actual Cash Value",
  replacement_cost:"Replacement Cost",
  cameras:"Cameras",
  coins:"Coins",
  fine_arts:"Fine Arts",
  fine_arts_brekage:"Fine Arts Breakage",
  furs:"Furs",
  golf_equipment:"Golf Equipment",
  jewelry:"Jewelry",
  musical_instruments:"Musical Instruments",
  silverware:"Silverware",
  stamps:"Stamps",
  jewelery_watches_furs:"Jewelry Watches Furs",
  money:"Money",
  securites:"Securities",
  silverware:"Silverware",
  firearms:"Firearms",
  portable_electronic_equipment:"Portable Electronic Equipment in or upon a motor vehicle",
  non_bldg :"Inground or semi-inground swimming pools/therapeutic baths or hot tubs"
}

const stateConstants = {
  az:"AZ"
}

const binaryConstants = {
  yes:"Yes",
  no:"No"
}

let claimStatusConstants = {
  open: "Open",
  closed: "Closed",
  disputed: "Disputed"
}

let operationConstants = {
  new_business: "new_business"
}
 
let auxDataConstants = {
  key : "amount",
  ui_type: "normal",
  increase_cov_e_f: "increaseCoverageEF",
  base_premium: "basePremium",
  ext_replacement_cost: "extendedReplacementCost",
  uw_tier: "uwTier",
  claims_free_discount: "claimsFreeDiscount",
  fire_dept_tax_credit: "fireDeptTaxCredit",
  mitigation_credit: "mitigationCredit",
  nb_home_buyer: "nbHomeBuyer"
}

exports.operationConstants = operationConstants;
exports.auxDataConstants = auxDataConstants;
exports.claimStatusConstants = claimStatusConstants;
exports.perilNameConstants = perilNameConstants;
exports.numberConstants = numberConstants;
exports.tableNameConsts = tableNameConsts;
exports.tableKeyConstants =tableKeyConstants;
exports.exposureFieldValueConstants = exposureFieldValueConstants;
exports.perilValueConstansts = perilValueConstansts;
exports.stateConstants = stateConstants;
exports.binaryConstants = binaryConstants;