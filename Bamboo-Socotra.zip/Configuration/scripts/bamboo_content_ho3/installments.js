let installmentConstants = require("./constants/constants.js");
let newBusinessInstallments = require("./installments/newBusinessInstallments.js");
let postNewBusinessInstallments = require("./installments/postNewBusinessInstallments.js");

function createInstallments(data)
{
  let installments;
  if (data.operation == installmentConstants.operationConstants.new_business || data.operation == installmentConstants.operationConstants.fee_assessment ||
     data.operation == installmentConstants.operationConstants.renewal)
  {
    installments = newBusinessInstallments.createNewBusinessInstallments(data, installments);
  }
  else if (data.operation == installmentConstants.operationConstants.cancellation )
  {
    installments = postNewBusinessInstallments.getUpfrontForCancellation(data);
  }
  else if (data.operation == installmentConstants.operationConstants.endorsement || data.operation == installmentConstants.operationConstants.reinstatement)
  {
    installments = postNewBusinessInstallments.createPostNewBusinessInstallments(data, installments);
  }
  return {
    installments
  };
}

exports.createInstallments = createInstallments;