let constantValues = require("../underwritingConstants.js")
let helpers = require("../helpersUW.js")

function getPerilUWDecision(allExposures) {
  let property_state;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    if (exposure.name == constantValues.exposureNameConstants.dwelling) {
      property_state = exposure_fv.property_state;
    }
  }
  if (property_state == constantValues.stateConstants.az) {
    getCoveragesUWDecision(allExposures);
    getPeril1UWDecision(allExposures);
    creditsApplied();
  }

}

function getCoveragesUWDecision(allExposures) {
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let rcv = exposure_fv.rcv;
    for (let peril of exposure.perils) {
      let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
      if (exposure.name == constantValues.exposureNameConstants.dwelling) {
        if (peril.name == constantValues.perilNameConstants.coverage_a) {
          let coverage_a_limit = parseFloat(helpers.removeSpecialCharacters(peril_fv.coverage_a_limit));
          if (coverage_a_limit > constantValues.numberConstants.fifteen_lakh || rcv > constantValues.numberConstants.fifteen_lakh) {
            helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.message10);
          }
        }
      }
    }
  }
}

function getPeril1UWDecision(allExposures) {
  for (let exposure of allExposures) {
    let other_b_limit = constantValues.numberConstants.zero;
    let home_day_care_structure_limit_value = constantValues.numberConstants.zero;
    let coverage_a_limit = constantValues.numberConstants.zero;

    for (let peril of exposure.perils) {
      let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
      let peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;
      if (exposure.name == constantValues.exposureNameConstants.dwelling) {
        if (peril.name == constantValues.perilNameConstants.home_day_care_coverage) {
          let no_of_persons = peril_fv.no_of_persons;
          if (no_of_persons != constantValues.numberConstants.zero) {
            helpers.setUWDecision(constantValues.decisions.uw_none, constantValues.messageConstants.message15);
          }
        }
        if (peril.name == constantValues.perilNameConstants.coverage_b_other_structures) {
          other_b_limit = parseFloat(helpers.removeSpecialCharacters(peril_fv.other_b_limit));
        }
        if (peril.name == constantValues.perilNameConstants.coverage_a) {
          coverage_a_limit = parseFloat(helpers.removeSpecialCharacters(peril_fv.coverage_a_limit));
        }
        if (peril.name == constantValues.perilNameConstants.home_day_care_coverage) {
          let home_day_details_groups = peril_fv.home_day_details;
          if (home_day_details_groups != undefined) {
            for (let home_day_details_group of home_day_details_groups) {
              home_day_care_structure_limit = parseFloat(helpers.removeSpecialCharacters(peril_fgv[home_day_details_group].home_day_care_structure_limit));
              if (home_day_care_structure_limit != undefined) {
                home_day_care_structure_limit_value = parseInt(home_day_care_structure_limit_value) + parseInt(home_day_care_structure_limit);
              }
            }
          }
        }
      }
    }

    if (exposure.name == constantValues.exposureNameConstants.dwelling) {
      if (parseInt(other_b_limit) + parseInt(home_day_care_structure_limit_value) >= constantValues.numberConstants.point_two * coverage_a_limit) {
        helpers.setUWDecision(constantValues.decisions.uw_none,
          constantValues.messageConstants.message13);
      }
    }
  }
}

function creditsApplied()
{
  let roof_credits_applied = socotraApi.getAuxData("RoofCoveringCreditsAreApplied", "flag");
  if(roof_credits_applied == constantValues.binaryConstants.uw_yes)
  {
    helpers.setUWDecision(constantValues.decisions.uw_none,
      constantValues.messageConstants.message18);
  }
}





exports.getPerilUWDecision = getPerilUWDecision;