let constantValues = require("../underwritingConstants.js")
let helpers = require("../helpersUW.js")

function getPLCPerilUWDecision(allExposures) {
    let property_state;
    for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    if (exposure.name == constantValues.exposureNameConstants.dwelling) {
    property_state = exposure_fv.property_state;
     }
     }
    if (property_state == constantValues.stateConstants.az) {
    getSchedulesUWDecision(allExposures)
    }

}

function getSchedulesUWDecision(allExposures) {
    for (let exposure of allExposures) {
        for (let peril of exposure.perils) {
            let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
            let peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;

            if (exposure.name == constantValues.exposureNameConstants.policy_level_coverages) {
                if (peril.name == constantValues.perilNameConstants.schedule_personal_property) {
                    let schedule_personal_property_groups = peril_fv.scheduled_personal_property;
                     let total_schedule_personal_property = helpers.getTotalSchedulePersonalProperty(schedule_personal_property_groups, peril_fgv);
                    if (total_schedule_personal_property > constantValues.numberConstants.zero) {
                        helpers.setUWDecision(constantValues.decisions.uw_none,
                            constantValues.messageConstants.message14);
                    }

                }
            }
        }

    }
}


exports.getPLCPerilUWDecision = getPLCPerilUWDecision;