let constantValues = require("./underwritingConstants.js");

let uw_result = {
  uw_notes: [] = [],
  uw_decisions: ""
}

function setUWDecision(decisions, notes) {
  if (uw_result.uw_decisions != constantValues.decisions.uw_reject) {
    if (decisions == constantValues.decisions.uw_reject) {
      uw_result.uw_decisions = constantValues.decisions.uw_reject;
    } else if (decisions == constantValues.decisions.uw_none) {
      uw_result.uw_decisions = constantValues.decisions.uw_none;
    } else if (decisions == constantValues.decisions.uw_accept) {
      if (uw_result.uw_decisions != constantValues.decisions.uw_none) {
        uw_result.uw_decisions = constantValues.decisions.uw_accept;
      }
    }
  }
  if (decisions != constantValues.decisions.uw_accept) {
    uw_result.uw_notes.push(notes);
  }
  return uw_result;

}
function getRoofOrHomeAge(year, policy_start_timestamp)
{
  let effective_year = new Date(+policy_start_timestamp).getFullYear();
  let age = Math.abs(effective_year - year);
  return age;
}

function getTotalSchedulePersonalProperty(schedule_personal_property_groups, peril_fgv)
{
 let total_schedule_personal_property = constantValues.numberConstants.zero;
  for(let schedule_personal_property_group of schedule_personal_property_groups)
  {
    let scheduled_personal_property_limit = parseInt(removeSpecialCharacters(peril_fgv[schedule_personal_property_group].scheduled_personal_property_limit));
    total_schedule_personal_property += scheduled_personal_property_limit;
  }
  return total_schedule_personal_property;
}

function getTableName(state, tableName)
{
  if(state == constantValues.stateConstants.az)
  {

    tableName = "AZ-" + tableName;
    return  tableName;
  }
}

var dates = {
  convert:function(d) {
      return (
          d.constructor === Date ? d :
          d.constructor === Array ? new Date(d[0],d[1],d[2]) :
          d.constructor === Number ? new Date(d) :
          d.constructor === String ? new Date(d) :
          typeof d === "object" ? new Date(d.year,d.month,d.date) :
          NaN
      );
  },
  compare:function(a,b) {
      return (
          isFinite(a=this.convert(a).valueOf()) &&
          isFinite(b=this.convert(b).valueOf()) ?
          (a>b)-(a<b) :
          NaN
      );
  }
}
function removeDuplicateUWResults(arr) {
 
}

function removeSpecialCharacters(limit)
{
  if(limit != undefined)
  {
    return limit.toString().replace(/[$,]/g, '');
  }
  else
  {
    return limit;
  }
}

function addDays(date, days) {
  var result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
}

exports.addDays = addDays;
exports.removeSpecialCharacters = removeSpecialCharacters;
exports.dates =dates;
exports.uw_result = uw_result;
exports.removeDuplicateUWResults = removeDuplicateUWResults;
exports.setUWDecision = setUWDecision;
exports.getTotalSchedulePersonalProperty = getTotalSchedulePersonalProperty;
exports.getTableName = getTableName;
exports.getRoofOrHomeAge = getRoofOrHomeAge;