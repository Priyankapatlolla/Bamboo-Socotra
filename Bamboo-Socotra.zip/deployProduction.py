import argparse
import json
import requests
import shutil

# base url for sandbox.

API_URL = 'https://api.<>.socotra.com'


def parse_args():
    parser = argparse.ArgumentParser()
    # Arguments that are to be passed when running this file. 
    # example: py deploy.py -z \export.zip -u <username> -p <password> -n <only tenant name(not whole hostname)>
    # path of export.zip is usually the path where the deploy.py is run from.

    parser.add_argument('--zipfile', '-z', help='The path to the zipfile containing configuration')
    parser.add_argument('--username', '-u', help='Your Socotra username')
    parser.add_argument('--password', '-p', help='Your Socotra password')
    parser.add_argument('--hostname', '-n', help='The hostname is a combination of your account '
                                                 'name and the suffix specified here. Not Required')
    return parser.parse_args()


def main():
    # Archiving the folder to zip. shutil.make_archive('output_file_name','format_of_output','source_folder_path')
    shutil.make_archive('export', 'zip', '/home/vsts/work/1/s/Configuration')
    args = parse_args()
    client = SocotraClient(API_URL)
    client.authenticate(args.username, args.password)
    response = client.load_configuration_for_testing(args.zipfile, args.hostname)
    if response['success']:
        print ('Tenant loaded at %s' % response['hostname'])
    else:
        print ('Tenant failed to load at %s' % response)
        exit(-1)

class SocotraClient(object):
    def __init__(self, api_url):
        self.api_url = api_url
        self.session = requests.Session()

    def _post(self, *args, **kwargs):
        response = self.session.post(*args, **kwargs)
        response_json = json.loads(response.text)
        if response.status_code != 200:
            message = "POST request to %s failed with status %s and message: %s"
            message = message % (response.url, response.status_code, response_json.get('message'))
            raise Exception(message)
        else:
            return response_json

    def authenticate(self, username, password):
        endpoint = self.api_url + '/account/authenticate'
        json_body = {'username': username,
                     'password': password}
        response = self._post(endpoint, json=json_body)
        token = response['authorizationToken']
        return self.session.headers.update({'Authorization': token})

    def load_configuration_for_testing(self, zipfile_location, tenant_suffix):
        endpoint = 'https://<>/assets/v1/deploy'
        multipart_form_data = {
            'zipFile': open(zipfile_location, 'rb')
        }
        return self._post(endpoint, files=multipart_form_data,
                          data={'tenantName': tenant_suffix})

if __name__ == "__main__":
    main()
